<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-07 22:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 106
ERROR - 2020-07-07 22:32:32 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-07 22:32:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:05 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:14 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:25 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:36:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:50:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:50:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:50:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:52:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:52:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:56:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:56:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:56:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:56:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:56:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:56:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:56:36 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:58:36 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:58:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:59:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 22:59:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 23:02:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 23:02:19 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-07 23:03:08 --> 404 Page Not Found: Assets/img
