<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-28 12:24:02 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 60
ERROR - 2018-12-28 12:24:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 60
ERROR - 2018-12-28 12:24:02 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 103
ERROR - 2018-12-28 12:24:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 103
ERROR - 2018-12-28 12:24:50 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 59
ERROR - 2018-12-28 12:24:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 59
ERROR - 2018-12-28 12:24:50 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 102
ERROR - 2018-12-28 12:24:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 102
ERROR - 2018-12-28 12:27:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-28 14:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-28 16:30:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-28 16:31:08 --> Query error: Unknown column 'credit' in 'field list' - Invalid query: SELECT `credit`, `creditPaid`, `company`
FROM `travel_booking`
WHERE `company` = 'ThrssrOne Company'
ERROR - 2018-12-28 16:31:28 --> Query error: Unknown column 'creditPrice' in 'field list' - Invalid query: SELECT `creditPrice`, `creditPaid`, `company`
FROM `travel_booking`
WHERE `company` = 'ThrssrOne Company'
ERROR - 2018-12-28 16:31:49 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:31:49 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:31:49 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:31:49 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:31:49 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:32:13 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:32:13 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:32:13 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:32:13 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:32:13 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-28 16:47:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
