<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-29 14:13:09 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-03-29 14:13:09 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-03-29 14:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-03-29 14:13:09 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-03-29 14:13:09 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-03-29 14:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-03-29 14:13:09 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-03-29 14:13:09 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-03-29 14:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-03-29 14:13:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:13:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\total_booking_graph.php 166
ERROR - 2020-03-29 14:13:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:13:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:14:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:22:45 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-03-29 14:22:45 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-03-29 14:22:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-03-29 14:22:45 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-03-29 14:22:45 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-03-29 14:22:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-03-29 14:22:45 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-03-29 14:22:45 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-03-29 14:22:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-03-29 14:22:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:23:42 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\assignment\application\views\admin\profile.php 52
ERROR - 2020-03-29 14:23:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:25:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:43:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:43:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:43:40 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:43:48 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:45:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:45:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:46:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:46:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:46:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:57:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:57:52 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\assignment\application\controllers\Welcome.php 695
ERROR - 2020-03-29 14:57:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` in()
ERROR - 2020-03-29 14:57:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-29 14:58:01 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\assignment\application\models\Admin_model.php 118
ERROR - 2020-03-29 14:58:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2020-03-29 14:58:12 --> 404 Page Not Found: Assets/img
