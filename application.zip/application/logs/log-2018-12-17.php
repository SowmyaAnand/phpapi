<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-17 09:20:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 09:23:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 09:23:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 09:24:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 09:24:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 09:24:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 09:24:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 09:27:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 09:27:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 09:28:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 09:28:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 09:33:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 09:33:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 09:53:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 09:53:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 09:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 09:56:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 10:13:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 10:13:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 10:13:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 10:13:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 10:13:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 10:14:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 10:14:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 10:14:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 10:14:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 10:15:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 10:15:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 10:15:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 10:15:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 10:15:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 10:19:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 10:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 10:19:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 10:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 10:23:37 --> 404 Page Not Found: Admin/add_company
ERROR - 2018-12-17 10:23:46 --> 404 Page Not Found: Admin/add_company
ERROR - 2018-12-17 10:24:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 10:40:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 10:43:46 --> Query error: Duplicate entry '987' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('Pkd Company', '1234', '987', '9517530000', 'new@gmail.com', 'uploads/banner 3.jpg')
ERROR - 2018-12-17 11:11:41 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 859
ERROR - 2018-12-17 11:17:19 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 859
ERROR - 2018-12-17 11:41:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 11:41:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 11:42:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 11:43:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 11:44:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 11:45:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 11:50:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 11:51:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 12:05:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 12:08:06 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 871
ERROR - 2018-12-17 12:14:26 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 871
ERROR - 2018-12-17 12:16:20 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 871
ERROR - 2018-12-17 12:19:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 12:19:52 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 871
ERROR - 2018-12-17 12:21:03 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 871
ERROR - 2018-12-17 12:21:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 12:25:52 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 871
ERROR - 2018-12-17 12:26:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 12:29:30 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 871
ERROR - 2018-12-17 12:29:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 12:31:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 13:06:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 13:07:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 13:09:48 --> Query error: Duplicate entry '987' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('Pkd Company', '1234', '987', '9517530000', 'new1@gmail.com', 'uploads/Advertisement bhimtalk.jpg')
ERROR - 2018-12-17 13:59:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:01:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:03:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:09:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:09:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:09:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:12:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:14:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:14:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 14:14:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:17:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:17:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:17:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:17:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 14:17:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:18:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:18:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:18:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:30:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:30:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:30:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:31:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:31:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:31:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:33:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:33:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:33:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:34:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:34:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:35:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:35:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:36:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:36:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:37:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:37:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:37:33 --> Severity: Notice --> Undefined variable: target_file /var/www/travel_app/application/controllers/Welcome.php 877
ERROR - 2018-12-17 14:37:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:38:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 14:38:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:38:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:38:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:38:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:38:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:40:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:40:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:40:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:40:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 14:50:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 14:55:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 14:56:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:00:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:03:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:08:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:10:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:14:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:19:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:20:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:21:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:23:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 15:28:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:28:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:28:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-17 15:28:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-17 15:30:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-17 15:34:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-17 15:35:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-17 15:37:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-17 15:37:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-17 15:41:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:41:50 --> 404 Page Not Found: Admin/add_company
ERROR - 2018-12-17 15:41:58 --> 404 Page Not Found: Admin/add_company
ERROR - 2018-12-17 15:44:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:49:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:51:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 15:51:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-17 15:56:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:57:33 --> Query error: Duplicate entry '111' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('Pkd Company', '1234', '111', '1234567890', 'PkdCompany@gmai.com', 'uploads/Advertisement bhimtalk.jpg')
ERROR - 2018-12-17 15:57:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 15:57:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 15:58:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 15:58:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 16:00:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 16:02:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 16:04:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 16:04:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 16:23:33 --> 404 Page Not Found: Uploads/female1023250788788.jpg
ERROR - 2018-12-17 16:24:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:24:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 16:24:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:27:38 --> Severity: Warning --> getimagesize(): Filename cannot be empty /var/www/travel_app/application/controllers/Welcome.php 837
ERROR - 2018-12-17 16:27:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:27:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 16:27:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:28:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:28:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:28:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:29:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:29:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:30:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:30:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:31:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:31:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:31:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-17 16:35:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-17 16:35:28 --> Severity: Warning --> getimagesize(): Filename cannot be empty /var/www/travel_app/application/controllers/Welcome.php 838
ERROR - 2018-12-17 16:36:49 --> Severity: Warning --> getimagesize(): Filename cannot be empty /var/www/travel_app/application/controllers/Welcome.php 839
ERROR - 2018-12-17 16:38:01 --> Severity: Warning --> getimagesize(): Filename cannot be empty /var/www/travel_app/application/controllers/Welcome.php 839
ERROR - 2018-12-17 16:43:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-17 16:44:56 --> 404 Page Not Found: Admin/add_company
