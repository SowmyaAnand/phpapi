<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-21 09:25:30 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 09:25:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 09:25:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-21 09:25:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-21 09:32:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 09:33:12 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/edit_income.php 269
ERROR - 2018-12-21 09:34:07 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/edit_income.php 269
ERROR - 2018-12-21 09:34:09 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/edit_income.php 269
ERROR - 2018-12-21 09:34:44 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/edit_income.php 269
ERROR - 2018-12-21 09:41:00 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 09:41:44 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 09:42:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 09:42:50 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 09:47:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:22 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:47:29 --> Query error: Unknown column 'expenseType' in 'field list' - Invalid query: UPDATE `income` SET `approved_by` = '2', `customerId` = '2', `companyId` = '130', `receipt_no` = 'IN1269264132', `incomeDate` = '2018-12-20', `incomId` = '10', `incomeType` = '1', `expenseType` = '', `cash_from` = 'robert partners', `phone` = '1234567890', `credit` = '8000', `payment_type` = 'cash', `bank_name` = '', `chequeno` = '', `dd_date` = '', `description` = 'robert'
WHERE `incomId` = '10'
ERROR - 2018-12-21 09:51:38 --> Query error: Unknown column 'expenseType' in 'field list' - Invalid query: UPDATE `income` SET `approved_by` = '2', `customerId` = '2', `companyId` = '130', `receipt_no` = 'IN1269264132', `incomeDate` = '2018-12-20', `incomId` = '10', `incomeType` = '1', `expenseType` = '', `cash_from` = 'robert partners', `phone` = '1234567890', `credit` = '8000', `payment_type` = 'cash', `bank_name` = '', `chequeno` = '', `dd_date` = '', `description` = 'robert'
WHERE `incomId` = '10'
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:51:40 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:52:36 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/admin/edit_income.php 140
ERROR - 2018-12-21 09:53:25 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-21 10:21:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:21:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-21 10:48:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 10:56:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 11:02:10 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 80
ERROR - 2018-12-21 11:02:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/list_account_details.php 80
ERROR - 2018-12-21 11:02:10 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 133
ERROR - 2018-12-21 11:02:10 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 149
ERROR - 2018-12-21 11:02:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 11:02:23 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 80
ERROR - 2018-12-21 11:02:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/list_account_details.php 80
ERROR - 2018-12-21 11:02:23 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 133
ERROR - 2018-12-21 11:02:23 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 149
ERROR - 2018-12-21 11:20:16 --> Severity: Error --> Call to undefined method Banking_model::get_companies() /var/www/travel_app/application/models/Banking_model.php 37
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 100
ERROR - 2018-12-21 11:22:02 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 116
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 100
ERROR - 2018-12-21 11:23:12 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/list_account_details.php 116
ERROR - 2018-12-21 11:23:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 11:25:06 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:06 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:06 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:06 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:06 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:06 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:06 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:06 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:28 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:28 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:28 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:28 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:28 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:28 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:28 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:28 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:35 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:35 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:35 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:35 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:35 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:35 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:35 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:35 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/list_account_details.php 93
ERROR - 2018-12-21 11:25:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 12:31:01 --> Severity: Notice --> Undefined variable: customerId /var/www/travel_app/application/controllers/Banking.php 283
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'customerId' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'customerId' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'customerId' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'customerId' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'customerId' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'customerId' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'customerId' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:31:01 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:13 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:34:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:35:50 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:35:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:36:21 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/travel_app/application/views/admin/edit_account.php 32
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:05 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankName' /var/www/travel_app/application/views/admin/edit_account.php 43
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:37:40 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'id' /var/www/travel_app/application/views/admin/edit_account.php 37
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'branch' /var/www/travel_app/application/views/admin/edit_account.php 53
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'bankAddress' /var/www/travel_app/application/views/admin/edit_account.php 64
ERROR - 2018-12-21 12:40:52 --> Severity: Warning --> Illegal string offset 'accountNmber' /var/www/travel_app/application/views/admin/edit_account.php 76
ERROR - 2018-12-21 12:41:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Banking.php 248
ERROR - 2018-12-21 12:41:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 12:47:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 12:47:24 --> 404 Page Not Found: Booking/edit_account_details
ERROR - 2018-12-21 12:51:13 --> Severity: Notice --> Undefined variable: customerId /var/www/travel_app/application/controllers/Banking.php 240
ERROR - 2018-12-21 12:53:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 12:54:09 --> 404 Page Not Found: Booking/edit_account_details
ERROR - 2018-12-21 12:56:10 --> 404 Page Not Found: Booking/edit_account_details
ERROR - 2018-12-21 12:56:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 12:59:33 --> Severity: Notice --> Undefined property: Banking::$bank_model /var/www/travel_app/application/controllers/Banking.php 262
ERROR - 2018-12-21 12:59:33 --> Severity: Error --> Call to a member function edit_account_details() on null /var/www/travel_app/application/controllers/Banking.php 262
ERROR - 2018-12-21 13:01:09 --> Severity: Notice --> Undefined variable: edit_customer /var/www/travel_app/application/controllers/Banking.php 263
ERROR - 2018-12-21 13:06:49 --> Query error: Unknown column 'acc_id' in 'field list' - Invalid query: UPDATE `bank_details` SET `acc_id` = '1', `bankName` = 'SBT', `branch` = 'palakkad', `bankAddress` = 'SBT Palakkad', `accountNmber` = '012345678900', `companyId` = '130', `id` = ''
WHERE `id` = ''
ERROR - 2018-12-21 13:08:45 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/models/Banking_model.php 47
ERROR - 2018-12-21 13:08:45 --> Query error: Unknown column 'acc_id' in 'field list' - Invalid query: UPDATE `bank_details` SET `acc_id` = '1', `bankName` = 'SBT', `branch` = 'palakkad', `bankAddress` = 'SBT Palakkad', `accountNmber` = '012345678900', `companyId` = '130'
WHERE `id` IS NULL
ERROR - 2018-12-21 13:44:55 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/models/Banking_model.php 47
ERROR - 2018-12-21 13:44:55 --> Query error: Unknown column 'acc_id' in 'field list' - Invalid query: UPDATE `bank_details` SET `acc_id` = '1', `bankName` = 'SBT', `branch` = 'palakkad', `bankAddress` = 'SBT Palakkad', `accountNmber` = '012345678900', `companyId` = '130'
WHERE `id` IS NULL
ERROR - 2018-12-21 13:46:42 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/models/Banking_model.php 47
ERROR - 2018-12-21 13:46:42 --> Query error: Unknown column 'acc_id' in 'field list' - Invalid query: UPDATE `bank_details` SET `acc_id` = '3', `bankName` = 'CANARA', `branch` = 'Thrissur', `bankAddress` = 'CANARA Thrissur', `accountNmber` = '11111111222', `companyId` = '103'
WHERE `id` IS NULL
ERROR - 2018-12-21 13:47:49 --> Query error: Unknown column 'acc_id' in 'field list' - Invalid query: UPDATE `bank_details` SET `acc_id` = '2', `bankName` = 'HDFC', `branch` = 'palakkad', `bankAddress` = 'HDFC Palakkad', `accountNmber` = '99999999900', `companyId` = '102', `id` = '2'
WHERE `id` = '2'
ERROR - 2018-12-21 13:49:26 --> Query error: Unknown column 'acc_id' in 'field list' - Invalid query: UPDATE `bank_details` SET `acc_id` = '2', `bankName` = 'HDFC', `branch` = 'palakkad', `bankAddress` = 'HDFC Palakkad', `accountNmber` = '99999999900', `companyId` = '102'
WHERE `id` = ''
ERROR - 2018-12-21 13:59:30 --> Query error: Unknown column 'acc_id' in 'field list' - Invalid query: UPDATE `bank_details` SET `acc_id` = '1', `bankName` = 'SBT', `branch` = 'palakkad', `bankAddress` = 'SBT Palakkad', `accountNmber` = '012345678900', `usercompany` = '130'
WHERE `id` = ''
ERROR - 2018-12-21 14:00:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 14:00:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 14:00:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 14:07:03 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_account.php 31
ERROR - 2018-12-21 14:13:27 --> Severity: Notice --> Undefined variable: account_details /var/www/travel_app/application/views/admin/edit_account.php 31
ERROR - 2018-12-21 14:14:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 14:24:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 14:25:32 --> 404 Page Not Found: Booking/list_account_details
ERROR - 2018-12-21 14:39:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-21 14:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-21 14:46:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-21 14:51:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-21 14:52:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-21 14:57:30 --> Severity: Notice --> Undefined variable: company_id /var/www/travel_app/application/controllers/Welcome.php 366
ERROR - 2018-12-21 14:57:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 366
ERROR - 2018-12-21 14:58:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 366
ERROR - 2018-12-21 15:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-21 15:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-21 15:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-21 15:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-21 15:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-21 15:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-21 15:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-21 15:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-21 15:26:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-21 15:26:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-21 15:26:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-21 15:26:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-21 15:26:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-21 15:26:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-21 15:26:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-21 15:26:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-21 15:27:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-21 15:27:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-21 15:27:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-21 15:27:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-21 15:27:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-21 15:27:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-21 15:27:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-21 15:27:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-21 15:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
