<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-07 09:18:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:18:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:28:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:29:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:31:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:31:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:31:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:32:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:33:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:33:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-07 09:38:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-07 09:39:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:39:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:40:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:40:33 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-07 09:41:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:41:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 09:47:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 09:47:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 09:47:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:47:53 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 116
ERROR - 2018-12-07 09:48:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:49:15 --> 404 Page Not Found: User/list_customers
ERROR - 2018-12-07 09:49:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:52:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:53:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:53:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:56:08 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 09:57:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 09:58:56 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/models/Admin_model.php 24
ERROR - 2018-12-07 09:58:56 --> Query error: Column 'companyId' cannot be null - Invalid query: INSERT INTO `travel_customer` (`customerCompany`, `customerFirstname`, `customerLastname`, `creditLimit`, `customerPhone`, `customerEmail`, `customerAddress`, `customerCity`, `customerState`, `customerCountry`, `companyId`, `createdBy`) VALUES ('jithin test from comp2', 'test', 'jithin', '2000', '4561237811', 'jithin@test.com', 'qwerty', 'qwerty', 'qwerty', 'qwerty', NULL, '103')
ERROR - 2018-12-07 10:00:20 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/models/Admin_model.php 24
ERROR - 2018-12-07 10:00:20 --> Query error: Column 'companyId' cannot be null - Invalid query: INSERT INTO `travel_customer` (`customerCompany`, `customerFirstname`, `customerLastname`, `creditLimit`, `customerPhone`, `customerEmail`, `customerAddress`, `customerCity`, `customerState`, `customerCountry`, `companyId`, `createdBy`) VALUES ('jithin test from comp2', 'test', 'jithin', '2000', '4561237811', 'jithin@test.com', 'qwerty', 'qwerty', 'qwerty', 'qwerty', NULL, '103')
ERROR - 2018-12-07 10:03:46 --> Severity: Notice --> Undefined index: gender /var/www/travel_app/application/models/User_model.php 13
ERROR - 2018-12-07 10:03:46 --> Severity: Notice --> Undefined index: age /var/www/travel_app/application/models/User_model.php 14
ERROR - 2018-12-07 10:03:46 --> Query error: Column 'customerGender' cannot be null - Invalid query: INSERT INTO `travel_customer` (`customerFirstname`, `customerLastname`, `customerGender`, `customerAge`, `customerPhone`, `customerEmail`, `customerAddress`, `customerCity`, `customerState`, `customerCountry`, `companyId`, `createdBy`) VALUES ('test', 'test', NULL, NULL, '7894561231', 'test@user.comp', 'test user comp2', 'testusercomp', 'testusercomp', 'testusercomp', '103', '3')
ERROR - 2018-12-07 10:03:54 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:03:54 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/edit_income.php 135
ERROR - 2018-12-07 10:03:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_income.php 135
ERROR - 2018-12-07 10:06:47 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:06:47 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/edit_income.php 135
ERROR - 2018-12-07 10:06:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_income.php 135
ERROR - 2018-12-07 10:14:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 10:16:02 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:18:35 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-07 10:19:30 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-07 10:22:44 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:25:33 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:29:54 --> 404 Page Not Found: Booking/advancepayment
ERROR - 2018-12-07 10:35:52 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:35:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 10:38:31 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:39:46 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:44:56 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:44:56 --> Severity: Notice --> Undefined index: incomeDate /var/www/travel_app/application/views/admin/edit_income.php 431
ERROR - 2018-12-07 10:46:28 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 117
ERROR - 2018-12-07 10:47:42 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 10:47:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 10:48:31 --> Severity: Notice --> Undefined variable: user /var/www/travel_app/application/models/Daybook_model.php 313
ERROR - 2018-12-07 10:48:31 --> Query error: Unknown column 'company' in 'field list' - Invalid query: UPDATE `income` SET `approved_by` = '2', `customerId` = '2', `companyId` = '102', `receipt_no` = 'IN1249150949', `incomeDate` = '2018-12-08', `incomId` = '2', `incomeType` = '9', `company` = '102', `cash_from` = 'new company', `phone` = '1234567890', `credit` = '4500', `payment_type` = 'cash', `bank_name` = '', `chequeno` = '', `dd_date` = '', `description` = 'new company'
WHERE `incomId` = '2'
ERROR - 2018-12-07 10:48:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 10:50:48 --> Query error: Unknown column 'company' in 'field list' - Invalid query: UPDATE `income` SET `approved_by` = '2', `customerId` = '2', `companyId` = '102', `receipt_no` = 'IN1249150949', `incomeDate` = '2018-12-08', `incomId` = '2', `incomeType` = '9', `company` = '102', `cash_from` = 'new company', `phone` = '1234567890', `credit` = '4500', `payment_type` = 'cash', `bank_name` = '', `chequeno` = '', `dd_date` = '', `description` = 'new company'
WHERE `incomId` = '2'
ERROR - 2018-12-07 11:00:24 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-07 11:00:30 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-07 11:00:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 11:00:34 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:00:42 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-07 11:00:44 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-07 11:00:47 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:00:50 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:01:00 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-07 11:02:20 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-07 11:02:22 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-07 11:02:25 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:02:28 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:03:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:03:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:04:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:04:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:28:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:28:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:31:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 11:31:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:31:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:34:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 11:35:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:35:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:37:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:37:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:38:34 --> Severity: Notice --> Undefined index: incomeDate /var/www/travel_app/application/views/admin/edit_expense.php 96
ERROR - 2018-12-07 11:38:34 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/edit_expense.php 147
ERROR - 2018-12-07 11:38:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_expense.php 147
ERROR - 2018-12-07 11:39:48 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/edit_expense.php 147
ERROR - 2018-12-07 11:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_expense.php 147
ERROR - 2018-12-07 11:47:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 11:47:58 --> Query error: Unknown column 'incomeDate' in 'field list' - Invalid query: UPDATE `expense` SET `approved_by` = '2', `customerId` = '2', `companyId` = '103', `voucher_no` = 'TN1357783740', `incomeDate` = '2018-12-09', `incomId` = '4', `expenseType` = '2', `pay_to` = 'new company', `phone` = '1234567890', `debit` = '4000', `payment_type` = 'cheque', `bank_name` = 'HDFC', `chequeno` = 'HDFC123', `dd_date` = '2018-12-08', `description` = 'robert'
WHERE `incomId` = '4'
ERROR - 2018-12-07 11:49:14 --> Query error: Unknown column 'incomeDate' in 'field list' - Invalid query: UPDATE `expense` SET `approved_by` = '2', `customerId` = '2', `companyId` = '103', `voucher_no` = 'TN1357783740', `incomeDate` = '2018-12-09', `incomId` = '4', `expenseType` = '2', `pay_to` = 'new company', `phone` = '1234567890', `debit` = '4000', `payment_type` = 'cheque', `bank_name` = 'HDFC', `chequeno` = 'HDFC123', `dd_date` = '2018-12-08', `description` = 'robert'
WHERE `incomId` = '4'
ERROR - 2018-12-07 11:49:20 --> Query error: Unknown column 'incomeDate' in 'field list' - Invalid query: UPDATE `expense` SET `approved_by` = '2', `customerId` = '2', `companyId` = '103', `voucher_no` = 'TN1357783740', `incomeDate` = '2018-12-09', `incomId` = '4', `expenseType` = '2', `pay_to` = 'new company', `phone` = '1234567890', `debit` = '4000', `payment_type` = 'cheque', `bank_name` = 'HDFC', `chequeno` = 'HDFC123', `dd_date` = '2018-12-08', `description` = 'robert'
WHERE `incomId` = '4'
ERROR - 2018-12-07 11:49:33 --> 404 Page Not Found: Daybook/transaction_report
ERROR - 2018-12-07 11:49:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:49:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:50:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:50:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:51:56 --> 404 Page Not Found: Daybook/transaction_report
ERROR - 2018-12-07 11:52:14 --> 404 Page Not Found: Daybook/transaction_report
ERROR - 2018-12-07 11:52:18 --> 404 Page Not Found: Daybook/transaction_report
ERROR - 2018-12-07 11:52:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:52:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:53:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:53:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:54:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:54:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 11:56:22 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:56:53 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:56:56 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:57:17 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:58:10 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:58:13 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:58:32 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 11:59:46 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 12:00:07 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 12:01:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:01:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:02:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:02:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:06:09 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:06:09 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:07:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-07 12:07:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-07 12:08:15 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-07 12:08:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:08:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:09:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:09:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:11:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:11:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-07 12:13:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IN('102,103')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` = IN('102,103')
 LIMIT 5
ERROR - 2018-12-07 12:14:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 12:19:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 12:22:36 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting identifier (T_STRING) /var/www/travel_app/application/models/Booking_model.php 118
ERROR - 2018-12-07 12:27:57 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-07 12:27:57 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` = Array
ERROR - 2018-12-07 12:28:06 --> Severity: Notice --> Undefined variable: arr_comId /var/www/travel_app/application/models/Admin_model.php 59
ERROR - 2018-12-07 12:29:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-07 12:29:09 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` = Array
ERROR - 2018-12-07 12:29:11 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-07 12:29:11 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` = Array
ERROR - 2018-12-07 12:29:38 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-07 12:29:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` = Array
ERROR - 2018-12-07 12:31:31 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-07 12:31:31 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` = Array
ERROR - 2018-12-07 12:31:32 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-07 12:31:32 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` = Array
ERROR - 2018-12-07 12:41:35 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:41:35 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:41:35 --> Query error: Table 'travel_app_db.companyName' doesn't exist - Invalid query: SELECT `travel_company`
FROM `companyName`
WHERE `companyId` IN(Array, Array)
ERROR - 2018-12-07 12:43:58 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:43:58 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:43:58 --> Query error: Table 'travel_app_db.companyName' doesn't exist - Invalid query: SELECT `travel_company`
FROM `companyName`
WHERE `companyId` IN(Array, Array)
ERROR - 2018-12-07 12:43:59 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:43:59 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:43:59 --> Query error: Table 'travel_app_db.companyName' doesn't exist - Invalid query: SELECT `travel_company`
FROM `companyName`
WHERE `companyId` IN(Array, Array)
ERROR - 2018-12-07 12:44:00 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:44:00 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:44:00 --> Query error: Table 'travel_app_db.companyName' doesn't exist - Invalid query: SELECT `travel_company`
FROM `companyName`
WHERE `companyId` IN(Array, Array)
ERROR - 2018-12-07 12:44:00 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:44:00 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:44:00 --> Query error: Table 'travel_app_db.companyName' doesn't exist - Invalid query: SELECT `travel_company`
FROM `companyName`
WHERE `companyId` IN(Array, Array)
ERROR - 2018-12-07 12:44:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:44:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:44:09 --> Query error: Table 'travel_app_db.companyName' doesn't exist - Invalid query: SELECT *
FROM `travel_company`, `companyName`
WHERE `companyId` IN(Array, Array)
ERROR - 2018-12-07 12:45:15 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 12:45:15 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` IN(Array)
ERROR - 2018-12-07 12:46:37 --> Severity: Notice --> Undefined variable: usercompany /var/www/travel_app/application/controllers/Welcome.php 362
ERROR - 2018-12-07 12:46:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 362
ERROR - 2018-12-07 12:46:50 --> Severity: Notice --> Undefined variable: usercompany /var/www/travel_app/application/controllers/Welcome.php 362
ERROR - 2018-12-07 12:46:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 362
ERROR - 2018-12-07 12:48:26 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-07 12:48:26 --> Severity: Notice --> Undefined variable:  /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-07 12:48:50 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-07 12:48:59 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/user/add_booking.php 279
ERROR - 2018-12-07 12:48:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/add_booking.php 279
ERROR - 2018-12-07 12:51:06 --> Severity: Compile Error --> Cannot use [] for reading /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-07 12:51:27 --> Severity: Notice --> Undefined index: companyName /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-07 12:51:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 12:52:11 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-07 12:52:11 --> Severity: Notice --> Undefined index:  /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-07 12:54:16 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-07 12:54:16 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` = Array
ERROR - 2018-12-07 12:58:29 --> Severity: Error --> Call to undefined method Booking::get_all_company() /var/www/travel_app/application/controllers/Booking.php 117
ERROR - 2018-12-07 12:58:33 --> Severity: Error --> Call to undefined method Booking::get_all_company() /var/www/travel_app/application/controllers/Booking.php 117
ERROR - 2018-12-07 12:58:51 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Welcome.php 340
ERROR - 2018-12-07 12:59:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/add_booking.php 282
ERROR - 2018-12-07 12:59:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/add_booking.php 282
ERROR - 2018-12-07 12:59:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/add_booking.php 282
ERROR - 2018-12-07 12:59:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/add_booking.php 282
ERROR - 2018-12-07 12:59:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 12:59:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-07 12:59:49 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Welcome.php 340
ERROR - 2018-12-07 13:00:10 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/add_booking.php 282
ERROR - 2018-12-07 13:00:10 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/add_booking.php 282
ERROR - 2018-12-07 13:00:10 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/add_booking.php 282
ERROR - 2018-12-07 13:00:10 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/add_booking.php 282
ERROR - 2018-12-07 13:00:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-07 13:00:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-07 13:03:23 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-07 13:03:23 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` = Array
ERROR - 2018-12-07 13:07:52 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 13:07:52 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 837
ERROR - 2018-12-07 13:07:52 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `companyId`
FROM `travel_company`
WHERE `companyId` IN(Array, Array)
ERROR - 2018-12-07 13:16:34 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Welcome.php 339
ERROR - 2018-12-07 13:16:34 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in(Array)
ERROR - 2018-12-07 13:22:15 --> Severity: Error --> Call to undefined method Welcome::get_companies() /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-07 13:28:16 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::row_array() /var/www/travel_app/application/controllers/Welcome.php 341
ERROR - 2018-12-07 13:28:44 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::row_array() /var/www/travel_app/application/controllers/Welcome.php 341
ERROR - 2018-12-07 13:28:45 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::row_array() /var/www/travel_app/application/controllers/Welcome.php 341
ERROR - 2018-12-07 13:29:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 341
ERROR - 2018-12-07 13:30:30 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 341
ERROR - 2018-12-07 13:30:31 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 341
ERROR - 2018-12-07 14:19:16 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::row_array() /var/www/travel_app/application/controllers/Welcome.php 354
ERROR - 2018-12-07 14:19:32 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::row() /var/www/travel_app/application/controllers/Welcome.php 354
ERROR - 2018-12-07 14:19:44 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 354
ERROR - 2018-12-07 14:20:07 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 354
ERROR - 2018-12-07 14:20:08 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 354
ERROR - 2018-12-07 14:20:09 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 354
ERROR - 2018-12-07 14:20:09 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 354
ERROR - 2018-12-07 14:23:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 14:26:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 342
ERROR - 2018-12-07 14:28:59 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/controllers/Welcome.php 350
ERROR - 2018-12-07 14:30:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 14:34:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 34
ERROR - 2018-12-07 14:34:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 51
ERROR - 2018-12-07 14:34:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 68
ERROR - 2018-12-07 14:34:56 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:34:56 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:34:56 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 52
ERROR - 2018-12-07 14:34:56 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 69
ERROR - 2018-12-07 14:35:36 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:35:36 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:35:36 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 52
ERROR - 2018-12-07 14:35:36 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 69
ERROR - 2018-12-07 14:35:58 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:35:58 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:35:58 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 52
ERROR - 2018-12-07 14:35:58 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 69
ERROR - 2018-12-07 14:36:27 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 52
ERROR - 2018-12-07 14:36:27 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 69
ERROR - 2018-12-07 14:36:33 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 52
ERROR - 2018-12-07 14:36:33 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 69
ERROR - 2018-12-07 14:38:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 14:40:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 14:40:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 14:49:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 14:52:34 --> Severity: Notice --> Undefined variable: fixed_asset /var/www/travel_app/application/views/user/balance_sheet.php 57
ERROR - 2018-12-07 14:54:34 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 36
ERROR - 2018-12-07 14:54:58 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 36
ERROR - 2018-12-07 14:54:58 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 36
ERROR - 2018-12-07 14:55:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:56:19 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:57:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:57:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 14:59:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 14:59:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 14:59:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 15:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:02:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-07 15:03:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:03:48 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/fixed_assets_modal.php 22
ERROR - 2018-12-07 15:03:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/fixed_assets_modal.php 22
ERROR - 2018-12-07 15:03:48 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/fixed_assets_modal.php 39
ERROR - 2018-12-07 15:04:33 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/fixed_assets_modal.php 22
ERROR - 2018-12-07 15:04:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/fixed_assets_modal.php 22
ERROR - 2018-12-07 15:04:33 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/fixed_assets_modal.php 39
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-07 15:08:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-07 15:10:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:22:13 --> Severity: Parsing Error --> syntax error, unexpected 'result' (T_STRING) /var/www/travel_app/application/models/First_model.php 108
ERROR - 2018-12-07 15:24:04 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/models/First_model.php 108
ERROR - 2018-12-07 15:24:25 --> Severity: Notice --> Undefined variable: arr_comId /var/www/travel_app/application/models/First_model.php 106
ERROR - 2018-12-07 15:24:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
AND date_format(createdAt,"%Y-%m-%d") = '2018-12-07'' at line 3 - Invalid query: SELECT bookingDate, COUNT(bookingDate) AS count
FROM `travel_booking`
WHERE `companyId` in()
AND date_format(createdAt,"%Y-%m-%d") = '2018-12-07'
ERROR - 2018-12-07 15:26:09 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:26:18 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:28:31 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 55
ERROR - 2018-12-07 15:28:48 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 55
ERROR - 2018-12-07 15:28:49 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 55
ERROR - 2018-12-07 15:28:51 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 55
ERROR - 2018-12-07 15:29:02 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 55
ERROR - 2018-12-07 15:29:15 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:31:41 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:32:27 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:38:07 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:39:13 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:39:43 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-07 15:40:37 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:42:33 --> Query error: Table 'travel_app_db.bookingDate' doesn't exist - Invalid query: SELECT bookingDate, COUNT(bookingDate) AS count
FROM `travel_booking`, `bookingDate`
WHERE `companyId` in(102,103)
AND date_format(createdAt,"%Y-%m-%d") = '2018-12-07'
ERROR - 2018-12-07 15:43:15 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:43:15 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-07 15:44:17 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:44:17 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-07 15:45:54 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-07 15:45:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-07 15:45:54 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 42
ERROR - 2018-12-07 15:45:54 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-07 15:45:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-07 15:45:54 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 94
ERROR - 2018-12-07 15:47:33 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:47:33 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-07 15:52:07 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 15:52:07 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-07 15:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-07 15:53:55 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-07 15:53:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-07 15:53:55 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 42
ERROR - 2018-12-07 15:53:55 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-07 15:53:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-07 15:53:55 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 94
ERROR - 2018-12-07 15:55:26 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-07 15:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-07 15:55:26 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 42
ERROR - 2018-12-07 15:55:26 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-07 15:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-07 15:55:26 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 94
ERROR - 2018-12-07 16:01:23 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 16:01:23 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 16:01:23 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-07 16:02:46 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 16:02:46 --> Severity: Notice --> Undefined index: total_booking /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 16:02:46 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-07 16:04:31 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 16:05:06 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 16:05:41 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 16:05:42 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-07 16:06:57 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-07 16:08:44 --> Severity: Parsing Error --> syntax error, unexpected '?' /var/www/travel_app/application/views/admin/dashboard.php 36
ERROR - 2018-12-07 16:09:03 --> Severity: Parsing Error --> syntax error, unexpected ':' /var/www/travel_app/application/views/admin/dashboard.php 36
ERROR - 2018-12-07 16:09:05 --> Severity: Parsing Error --> syntax error, unexpected ':' /var/www/travel_app/application/views/admin/dashboard.php 36
ERROR - 2018-12-07 16:39:35 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/models/First_model.php 120
ERROR - 2018-12-07 16:40:00 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/models/First_model.php 122
ERROR - 2018-12-07 16:40:03 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/models/First_model.php 122
ERROR - 2018-12-07 16:40:17 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/models/First_model.php 122
ERROR - 2018-12-07 16:40:22 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/models/First_model.php 122
ERROR - 2018-12-07 16:40:33 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/models/First_model.php 122
ERROR - 2018-12-07 16:40:34 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/models/First_model.php 122
ERROR - 2018-12-07 16:40:52 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:40:55 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:41:09 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:41:13 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:41:28 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:41:33 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:42:42 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:42:59 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:43:32 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:44:04 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE) /var/www/travel_app/application/models/First_model.php 123
ERROR - 2018-12-07 16:44:14 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/travel_app/application/models/First_model.php 119
ERROR - 2018-12-07 17:31:45 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/travel_app/application/models/First_model.php 131
ERROR - 2018-12-07 17:32:03 --> Query error: Unknown column 'compriceCash' in 'field list' - Invalid query: SELECT `companyId`, SUM(compriceCash) as totcash
FROM `travel_booking`
WHERE `companyId` in(102,103)
AND date_format(createdAt,"%Y-%m-%d") = '2018-12-07'
GROUP BY `companyId`
ERROR - 2018-12-07 17:56:01 --> 404 Page Not Found: Advance_payment/index
ERROR - 2018-12-07 18:16:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/advance_payment.php 103
ERROR - 2018-12-07 18:17:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/advance_payment.php 103
ERROR - 2018-12-07 18:18:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM `advance_payment`
LEFT JOIN `airlines` ON `airlines`.`id`=`advance_paymen' at line 1 - Invalid query: SELECT sum(advance_payment.amount) as amount, *
FROM `advance_payment`
LEFT JOIN `airlines` ON `airlines`.`id`=`advance_payment`.`airline_id`
GROUP BY `airlines`.`id`
ERROR - 2018-12-07 18:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/advance_payment.php 103
ERROR - 2018-12-07 18:25:05 --> Severity: Error --> Call to undefined method CI_Loader::get_balance() /var/www/travel_app/application/views/admin/advance_payment.php 122
ERROR - 2018-12-07 18:25:19 --> Severity: Error --> Call to undefined method CI_Loader::get_balance() /var/www/travel_app/application/views/admin/advance_payment.php 122
ERROR - 2018-12-07 18:25:52 --> Severity: Error --> Call to undefined method CI_Loader::get_balance() /var/www/travel_app/application/views/admin/advance_payment.php 122
ERROR - 2018-12-07 18:26:44 --> Severity: Error --> Call to undefined function getinstance() /var/www/travel_app/application/views/admin/advance_payment.php 3
ERROR - 2018-12-07 18:27:00 --> Severity: Notice --> Undefined variable: CI /var/www/travel_app/application/views/admin/advance_payment.php 3
ERROR - 2018-12-07 18:27:00 --> Severity: Notice --> Object of class Advancepayment could not be converted to int /var/www/travel_app/application/views/admin/advance_payment.php 3
ERROR - 2018-12-07 18:27:00 --> Severity: Error --> Call to a member function get_balance() on integer /var/www/travel_app/application/views/admin/advance_payment.php 127
ERROR - 2018-12-07 18:31:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as tb group by tb.airline' at line 1 - Invalid query: SELECT (sum(tb.airline_cost)+sum(tb.service_charge)+sum(tb.tax)) as charge,tb.airline FROM `travel_booking` where airline='1'  as tb group by tb.airline
ERROR - 2018-12-07 18:31:36 --> Severity: Notice --> Undefined property: stdClass::$charge /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 18:31:36 --> Severity: Notice --> Undefined property: stdClass::$charge /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 18:31:36 --> Severity: Notice --> Undefined property: stdClass::$charge /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 18:32:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::row() /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:15:25 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:18:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:18:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:19:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:19:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:27:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:27:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:28:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:28:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:28:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:28:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:29:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:29:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:29:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:29:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:29:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:29:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-07 19:33:20 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/advance_payment.php 134
ERROR - 2018-12-07 19:36:01 --> Severity: Notice --> Undefined property: CI_Loader::$daybook_model /var/www/travel_app/application/views/admin/banking.php 158
ERROR - 2018-12-07 19:36:01 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/admin/banking.php 158
ERROR - 2018-12-07 19:36:55 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/banking.php 183
ERROR - 2018-12-07 19:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/banking.php 183
ERROR - 2018-12-07 19:36:55 --> Severity: Notice --> Undefined variable: user_id /var/www/travel_app/application/views/admin/banking.php 302
ERROR - 2018-12-07 19:36:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/banking.php 302
ERROR - 2018-12-07 19:38:38 --> Severity: Notice --> Undefined variable: user_id /var/www/travel_app/application/views/admin/banking.php 288
ERROR - 2018-12-07 19:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/banking.php 288
ERROR - 2018-12-07 19:39:55 --> Severity: Notice --> Undefined variable: user_id /var/www/travel_app/application/views/admin/banking.php 308
ERROR - 2018-12-07 19:39:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/banking.php 308
ERROR - 2018-12-07 19:40:10 --> Severity: Notice --> Undefined variable: user_id /var/www/travel_app/application/views/admin/banking.php 308
ERROR - 2018-12-07 19:40:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/banking.php 308
ERROR - 2018-12-07 20:57:07 --> Query error: Unknown column 'voucher_no' in 'field list' - Invalid query: INSERT INTO `banking` (`voucher_no`, `expenseDate`, `company`, `type`, `accountnumber`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`) VALUES ('TN503544223', '2018-12-07', '102', '1', '102', '100', 'cheque', '10', '00', '2018-12-06', 'test')
ERROR - 2018-12-07 20:59:47 --> Query error: Unknown column 'expenseDate' in 'field list' - Invalid query: INSERT INTO `banking` (`expenseDate`, `company`, `type`, `accountnumber`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`) VALUES ('2018-12-07', '102', '1', '102', '100', 'cheque', '10', '00', '2018-12-06', 'test')
ERROR - 2018-12-07 21:00:46 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `banking` (`company`, `type`, `accountnumber`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`, `transactionDate`) VALUES ('102', '1', '102', '100', 'cheque', '10', '00', '2018-12-06', 'test', '2018-12-07')
ERROR - 2018-12-07 21:01:20 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `banking` (`company`, `type`, `accountnumber`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`, `transactionDate`) VALUES ('102', '1', '102', '100', 'cheque', '10', '00', '2018-12-06', 'test', '2018-12-07')
ERROR - 2018-12-07 21:01:36 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `banking` (`company`, `type`, `accountnumber`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`, `transactionDate`) VALUES ('102', '1', '102', '100', 'cheque', '10', '00', '2018-12-06', 'test', '2018-12-07')
ERROR - 2018-12-07 21:02:08 --> Query error: Unknown column 'accountnumber' in 'field list' - Invalid query: INSERT INTO `banking` (`companyId`, `type`, `accountnumber`, `debit`, `payment_type`, `bank`, `ddno`, `dd_date`, `description`, `transactionDate`) VALUES ('102', '1', '102', '123', 'cheque', 'test', '123', '2018-12-06', 'test desc', '2018-12-07')
ERROR - 2018-12-07 21:02:44 --> Query error: Unknown column 'debit' in 'field list' - Invalid query: INSERT INTO `banking` (`companyId`, `type`, `accountnumber`, `debit`, `payment_type`, `bank`, `ddno`, `dd_date`, `description`, `transactionDate`) VALUES ('102', '1', '102', '123', 'cheque', 'test', '123', '2018-12-06', 'test desc', '2018-12-07')
ERROR - 2018-12-07 21:04:03 --> Query error: Unknown column 'dd_date' in 'field list' - Invalid query: INSERT INTO `banking` (`companyId`, `type`, `accountnumber`, `payment_type`, `bank`, `ddno`, `dd_date`, `description`, `transactionDate`, `amount`) VALUES ('102', '1', '102', 'cheque', 'bnk', '2134', '2018-12-06', 'test desc', '2018-12-07', '123')
