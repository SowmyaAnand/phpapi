<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-16 09:32:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /var/www/travel_app/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-16 09:32:50 --> Unable to connect to the database
ERROR - 2018-12-16 09:32:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 09:33:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /var/www/travel_app/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-16 09:33:07 --> Unable to connect to the database
ERROR - 2018-12-16 09:33:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 09:33:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /var/www/travel_app/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-16 09:33:51 --> Unable to connect to the database
ERROR - 2018-12-16 09:33:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 09:35:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 09:36:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 09:36:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 09:53:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 09:53:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-16 09:54:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-16 10:01:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 78
ERROR - 2018-12-16 10:01:49 --> Query error: Column 'airline' cannot be null - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `travelTo`, `departureDateTime`, `arrivalDateTime`, `flightNo`, `pnr`, `priceCash`, `priceCredit`, `tax`, `bookingDate`, `paymentType`, `airline`, `airline_cost`, `service_charge`, `companyId`, `createdBy`) VALUES ('RoneCompany', 'passenger1', '1', '4', '2018-12-16 14:00', '2018-12-17 10:00', 'F1', 'pnrK02', '4500', '0', '1000', '2018-12-16', 1, NULL, '500', '1000', '102', '2')
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-16 10:06:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-16 10:45:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 10:46:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-16 10:46:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-16 10:46:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-16 10:46:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 10:46:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 10:46:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-16 10:46:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-16 10:46:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-16 11:51:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 11:51:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 12:00:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-16 12:00:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-16 12:01:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 12:06:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 12:15:22 --> Severity: Notice --> Undefined variable: compnay /var/www/travel_app/application/views/admin/list_company.php 46
ERROR - 2018-12-16 12:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/list_company.php 46
ERROR - 2018-12-16 12:17:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:17:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 12:20:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 12:20:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:20:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 12:24:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 12:24:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 12:24:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 12:24:38 --> Severity: Compile Error --> Cannot redeclare Welcome::get_companies() /var/www/travel_app/application/controllers/Welcome.php 771
ERROR - 2018-12-16 12:25:54 --> Severity: Notice --> Undefined variable: compnay /var/www/travel_app/application/views/admin/list_company.php 46
ERROR - 2018-12-16 12:25:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/list_company.php 46
ERROR - 2018-12-16 12:26:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-16 12:26:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-16 12:26:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-16 12:26:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 12:26:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 12:26:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-16 12:26:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-16 12:26:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-16 12:26:20 --> Severity: Notice --> Undefined index: userId /var/www/travel_app/application/views/admin/list_company.php 68
ERROR - 2018-12-16 12:26:20 --> Severity: Notice --> Undefined index: userId /var/www/travel_app/application/views/admin/list_company.php 68
ERROR - 2018-12-16 12:27:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:28:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:29:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:29:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 12:53:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:53:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/edit_company.php 33
ERROR - 2018-12-16 12:53:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:54:34 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Welcome.php 776
ERROR - 2018-12-16 12:54:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/edit_company.php 33
ERROR - 2018-12-16 12:54:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:55:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/edit_company.php 33
ERROR - 2018-12-16 12:55:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 12:56:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 13:05:58 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/travel_app/application/controllers/Booking.php 190
ERROR - 2018-12-16 13:09:17 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/travel_app/application/controllers/Booking.php 190
ERROR - 2018-12-16 13:13:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 13:13:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 14:04:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 14:04:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 14:06:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 14:06:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 14:07:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 14:07:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 14:39:37 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/admin/edit_company.php 47
ERROR - 2018-12-16 14:51:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 14:51:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 14:58:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 14:58:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:06:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:09:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:09:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-16 15:09:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-16 15:09:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-16 15:09:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 15:09:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 15:09:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-16 15:09:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-16 15:09:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-16 15:09:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:09:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:15:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:15:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:15:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:17:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:17:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:17:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:20:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:20:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:20:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:21:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:22:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:22:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:22:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:22:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:22:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:22:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:40:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:40:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:42:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:42:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:42:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:42:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:42:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:43:47 --> Query error: Table 'travel_app_db.proprieter' doesn't exist - Invalid query: SELECT *
FROM `proprieter`
WHERE `email` = 'test@test.com'
ERROR - 2018-12-16 15:52:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:52:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:52:26 --> Severity: Error --> Call to undefined function distinct() /var/www/travel_app/application/controllers/Advancepayment.php 80
ERROR - 2018-12-16 15:54:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:54:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:54:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:55:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:55:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:55:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:55:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:55:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:55:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:55:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 15:56:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:56:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:57:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:57:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:58:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:59:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 15:59:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 15:59:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 16:01:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 16:01:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 16:03:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-16 16:03:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-16 16:03:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-16 16:03:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 16:03:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 16:03:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-16 16:03:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-16 16:03:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-16 16:03:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-16 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-16 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-16 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-16 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-16 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-16 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-16 16:13:50 --> Severity: Error --> Cannot use object of type mysqli as array /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:27:53 --> Severity: Compile Error --> Cannot redeclare Admin::add_proprietor() /var/www/travel_app/application/controllers/Admin.php 489
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:31:21 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:31:21 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:31:21 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:31:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:31:21 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:32:21 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:32:21 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:32:21 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:32:21 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:32:21 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:34:11 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 51
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:34:11 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 54
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:34:11 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 57
ERROR - 2018-12-16 16:34:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:34:11 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 60
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:35:11 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:35:11 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:35:11 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:35:11 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:35:11 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'name' /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:36:08 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 53
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'address' /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:36:08 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 56
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'email' /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:36:08 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 59
ERROR - 2018-12-16 16:36:08 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:36:08 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:38:01 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/views/admin/list_proprietor.php 62
ERROR - 2018-12-16 16:45:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 16:45:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 16:50:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-16 16:50:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-16 16:52:47 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/travel_app/application/controllers/Admin.php 490
ERROR - 2018-12-16 16:53:22 --> 404 Page Not Found: List_proprietor/index
ERROR - 2018-12-16 17:08:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 17:08:29 --> 404 Page Not Found: Booking/trial-balance
ERROR - 2018-12-16 17:08:33 --> 404 Page Not Found: Booking/trialbalance
ERROR - 2018-12-16 17:08:37 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-16 17:08:37 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-16 17:08:37 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-16 17:08:37 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-16 17:43:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 17:50:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 17:50:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-16 17:52:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
