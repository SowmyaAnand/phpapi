<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-04 09:03:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 09:03:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 09:09:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: book_id /var/www/travel_app/application/views/user/invoice.php 13
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 86
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 86
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: cids /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 270
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 270
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 283
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 283
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 10:20:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 10:56:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 10:58:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 10:59:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 11:00:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 11:01:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 11:03:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:03:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:03:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:03:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: book_id /var/www/travel_app/application/views/user/invoice.php 13
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 86
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 86
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: cids /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 270
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 270
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 283
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 283
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 11:04:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 11:04:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:04:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:04:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:04:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: book_id /var/www/travel_app/application/views/user/invoice.php 13
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 18
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 41
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 57
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 58
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 86
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 86
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 89
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 90
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 94
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 95
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 126
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: cids /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 228
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 229
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 253
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 254
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 255
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 270
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 270
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 281
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 282
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 283
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 283
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 286
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 11:04:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 287
ERROR - 2018-12-04 11:09:22 --> Severity: Notice --> Undefined variable: book_id /var/www/travel_app/application/views/user/invoice.php 13
ERROR - 2018-12-04 11:09:22 --> Severity: Notice --> Undefined variable: cids /var/www/travel_app/application/views/user/invoice.php 19
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: book_id /var/www/travel_app/application/views/user/invoice.php 12
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 26
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 26
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 26
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 47
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 47
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 47
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 47
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 51
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 51
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 52
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 52
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 69
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 69
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 69
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 72
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 72
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 79
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 79
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 79
ERROR - 2018-12-04 11:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 79
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 49
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 49
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 52
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 52
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 72
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 72
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 76
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 76
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:13:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 49
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 49
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 52
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 52
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 72
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 72
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 76
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 76
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:13:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 27
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 29
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 30
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 48
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 49
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 49
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 52
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 52
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 70
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 71
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 72
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 72
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 73
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 74
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 75
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 76
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 76
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:15:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 80
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 28
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 32
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 32
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 32
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 36
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 36
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 36
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 40
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 60
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 60
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 60
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 60
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 61
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 61
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 64
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 64
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/user/invoice.php 65
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 65
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 82
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 82
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 82
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 83
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 83
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 83
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 84
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 85
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 86
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 86
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 87
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 87
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 88
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 88
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 92
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 92
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/views/user/invoice.php 92
ERROR - 2018-12-04 11:16:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 92
ERROR - 2018-12-04 11:18:17 --> Severity: Notice --> Undefined variable: add_booking_id /var/www/travel_app/application/controllers/Booking.php 208
ERROR - 2018-12-04 11:18:17 --> Severity: Notice --> Undefined variable: add_booking_id /var/www/travel_app/application/controllers/Booking.php 209
ERROR - 2018-12-04 11:18:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 209
ERROR - 2018-12-04 11:18:17 --> Severity: Notice --> Undefined variable: add_booking_id /var/www/travel_app/application/controllers/Booking.php 210
ERROR - 2018-12-04 11:18:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 210
ERROR - 2018-12-04 11:43:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:44:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:45:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:46:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:48:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:48:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:48:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:51:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:51:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:51:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:51:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 11:53:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:54:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:55:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:56:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:57:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:58:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:59:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:59:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 11:59:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:00:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:00:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:01:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:01:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:01:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:02:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:02:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:03:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:03:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:04:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:06:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:24:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:25:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:26:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:26:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:30:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:30:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:31:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:31:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:31:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:33:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 12:49:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 14:18:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 14:19:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 14:19:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 14:26:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 14:40:25 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/admin/list_user.php 50
ERROR - 2018-12-04 14:41:18 --> 404 Page Not Found: Booking/profit_loss
ERROR - 2018-12-04 14:41:47 --> Severity: Notice --> Undefined variable: book_id /var/www/travel_app/application/views/user/balance_sheet.php 13
ERROR - 2018-12-04 14:41:47 --> Severity: Notice --> Undefined variable: cids /var/www/travel_app/application/views/user/balance_sheet.php 18
ERROR - 2018-12-04 14:41:53 --> Severity: Notice --> Undefined variable: book_id /var/www/travel_app/application/views/user/balance_sheet.php 13
ERROR - 2018-12-04 14:41:53 --> Severity: Notice --> Undefined variable: cids /var/www/travel_app/application/views/user/balance_sheet.php 18
ERROR - 2018-12-04 14:42:12 --> Severity: Notice --> Undefined variable: cids /var/www/travel_app/application/views/user/balance_sheet.php 17
ERROR - 2018-12-04 15:09:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 15:09:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 15:19:37 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/add_user.php 56
ERROR - 2018-12-04 15:19:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/add_user.php 56
ERROR - 2018-12-04 15:20:02 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/add_user.php 56
ERROR - 2018-12-04 15:20:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/add_user.php 56
ERROR - 2018-12-04 15:20:14 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/add_user.php 56
ERROR - 2018-12-04 15:20:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/add_user.php 56
ERROR - 2018-12-04 15:20:24 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/add_user.php 56
ERROR - 2018-12-04 15:20:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/add_user.php 56
ERROR - 2018-12-04 15:21:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 15:21:18 --> Query error: Table 'travel_app_db.company' doesn't exist - Invalid query: SELECT `travel_users`.`companyId`, `company`.`companyName`
FROM `travel_users`
LEFT JOIN `company` ON `company`.`companyId`=`travel_users`.`companyId`
WHERE `userEmail` IS NULL
ERROR - 2018-12-04 15:25:50 --> Query error: Table 'travel_app_db.company' doesn't exist - Invalid query: SELECT `travel_users`.`companyId`, `company`.`companyName`
FROM `travel_users`
LEFT JOIN `company` ON `company`.`companyId`=`travel_users`.`companyId`
WHERE `userEmail` IS NULL
ERROR - 2018-12-04 15:25:52 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/admin/list_user.php 50
ERROR - 2018-12-04 15:25:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 15:26:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 15:29:13 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/admin/list_user.php 50
ERROR - 2018-12-04 15:29:16 --> Query error: Table 'travel_app_db.company' doesn't exist - Invalid query: SELECT `travel_users`.`companyId`, `company`.`companyName`
FROM `travel_users`
LEFT JOIN `company` ON `company`.`companyId`=`travel_users`.`companyId`
WHERE `userEmail` = 'Dr@dr.com'
ERROR - 2018-12-04 15:33:44 --> Severity: Notice --> Undefined index: gender /var/www/travel_app/application/models/Admin_model.php 12
ERROR - 2018-12-04 15:33:44 --> Severity: Notice --> Undefined index: age /var/www/travel_app/application/models/Admin_model.php 13
ERROR - 2018-12-04 15:33:44 --> Query error: Column 'customerGender' cannot be null - Invalid query: INSERT INTO `travel_customer` (`customerFirstname`, `customerLastname`, `creditLimit`, `customerGender`, `customerAge`, `customerPhone`, `customerEmail`, `customerAddress`, `customerCity`, `customerState`, `customerCountry`, `companyId`, `createdBy`) VALUES ('Louie', 'Moore', '2500', NULL, NULL, '9876543210', 'moore@gmail.com', '80 Ivy Lane', 'Palakkad', 'Kerala', 'India', '102', '102')
ERROR - 2018-12-04 15:44:11 --> Severity: Notice --> Undefined index: companyName /var/www/travel_app/application/views/admin/edit_user.php 60
ERROR - 2018-12-04 15:45:51 --> Severity: Notice --> Undefined variable: variable /var/www/travel_app/application/controllers/Admin.php 318
ERROR - 2018-12-04 15:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/controllers/Admin.php 318
ERROR - 2018-12-04 15:45:51 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:46:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:46:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:46:31 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:48:03 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:48:20 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:48:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 15:49:05 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:49:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 15:49:18 --> Severity: Notice --> Undefined variable: firstName /var/www/travel_app/application/views/admin/edit_user.php 32
ERROR - 2018-12-04 15:49:18 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:49:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 15:49:57 --> Severity: Notice --> Undefined variable: firstName /var/www/travel_app/application/views/admin/edit_user.php 32
ERROR - 2018-12-04 15:49:57 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:49:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:49:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 15:50:22 --> Severity: Notice --> Undefined variable: firstName /var/www/travel_app/application/views/admin/edit_user.php 32
ERROR - 2018-12-04 15:50:22 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:50:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:50:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 15:52:03 --> Severity: Notice --> Undefined offset: 0 /var/www/travel_app/application/controllers/Admin.php 319
ERROR - 2018-12-04 15:52:03 --> Severity: Notice --> Undefined variable: firstName /var/www/travel_app/application/views/admin/edit_user.php 32
ERROR - 2018-12-04 15:52:03 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:52:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 15:52:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 16:31:12 --> 404 Page Not Found: Admin/advancepayment
ERROR - 2018-12-04 16:31:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 16:31:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 16:35:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 16:59:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:04:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:04:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:04:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:04:42 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:04:42 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:04:42 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:04:42 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:04:43 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:04:43 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:04:43 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:04:43 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:05:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:05:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:05:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:05:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:05:51 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:05:51 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:05:52 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:05:52 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:05:52 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:05:52 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:05:52 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:05:52 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:05:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:06:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:06:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:06:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:06:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:06:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:07:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:07:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:07:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:07:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:08:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:08:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:08:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:09:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:09:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:09:49 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:09:49 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:09:50 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:09:50 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:09:50 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:09:50 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:09:50 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 60
ERROR - 2018-12-04 17:09:50 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 62
ERROR - 2018-12-04 17:09:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Advancepayment.php 37
ERROR - 2018-12-04 17:09:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:09:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:10:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:10:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:11:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:11:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:12:00 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 61
ERROR - 2018-12-04 17:12:00 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 63
ERROR - 2018-12-04 17:12:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:12:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:12:10 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 61
ERROR - 2018-12-04 17:12:10 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 63
ERROR - 2018-12-04 17:12:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:12:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:13:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:13:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:14:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:14:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:14:13 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 61
ERROR - 2018-12-04 17:14:13 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 63
ERROR - 2018-12-04 17:14:14 --> Severity: Warning --> Missing argument 1 for Advancepayment::get_airline_name() /var/www/travel_app/application/controllers/Advancepayment.php 61
ERROR - 2018-12-04 17:14:14 --> Severity: Notice --> Undefined variable: name /var/www/travel_app/application/controllers/Advancepayment.php 63
ERROR - 2018-12-04 17:14:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:14:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:14:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:14:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:15:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:15:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:15:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:17:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:17:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:17:31 --> 404 Page Not Found: Daybook/daybook
ERROR - 2018-12-04 17:17:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Advancepayment.php 37
ERROR - 2018-12-04 17:17:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:17:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:17:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 17:17:51 --> 404 Page Not Found: Daybook/daybook
ERROR - 2018-12-04 17:20:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:20:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:21:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:21:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:21:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 17:21:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:21:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 17:27:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 17:31:54 --> Query error: Unknown column 'airlines.airline_id' in 'on clause' - Invalid query: SELECT *
FROM `advance_payment`
LEFT JOIN `airlines` ON `airlines`.`airline_id`=`advance_payment`.`airline_id`
ERROR - 2018-12-04 17:42:16 --> Severity: Notice --> Undefined variable: firstName /var/www/travel_app/application/views/admin/edit_user.php 32
ERROR - 2018-12-04 17:42:16 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:42:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:43:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 320
ERROR - 2018-12-04 17:43:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 321
ERROR - 2018-12-04 17:43:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 322
ERROR - 2018-12-04 17:43:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 323
ERROR - 2018-12-04 17:43:40 --> Severity: Notice --> Undefined variable: firstName /var/www/travel_app/application/views/admin/edit_user.php 32
ERROR - 2018-12-04 17:43:40 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:43:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:44:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 319
ERROR - 2018-12-04 17:44:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 320
ERROR - 2018-12-04 17:44:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 321
ERROR - 2018-12-04 17:44:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 322
ERROR - 2018-12-04 17:44:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 323
ERROR - 2018-12-04 17:44:15 --> Severity: Notice --> Undefined variable: firstName /var/www/travel_app/application/views/admin/edit_user.php 32
ERROR - 2018-12-04 17:44:15 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:44:41 --> Severity: Notice --> Undefined variable: firstName /var/www/travel_app/application/views/admin/edit_user.php 32
ERROR - 2018-12-04 17:44:41 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:47:35 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:48:24 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:48:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_user.php 57
ERROR - 2018-12-04 17:49:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:49:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:50:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 17:58:29 --> Severity: Error --> Call to undefined method Admin_model::update_user() /var/www/travel_app/application/controllers/Admin.php 347
ERROR - 2018-12-04 18:02:25 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/models/Admin_model.php 270
ERROR - 2018-12-04 18:02:25 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/models/Admin_model.php 271
ERROR - 2018-12-04 18:02:25 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/models/Admin_model.php 272
ERROR - 2018-12-04 18:02:25 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/models/Admin_model.php 273
ERROR - 2018-12-04 18:02:25 --> Query error: Unknown column 'fname' in 'field list' - Invalid query: INSERT INTO `travel_users` (`fname`, `mobile`, `companyId`, `email`, `password`, `firstName`, `phone`, `userEmail`) VALUES ('Robert user', '9865321254', 'Robert Tucker', 'Druser@dr.com', NULL, NULL, NULL, NULL)
ERROR - 2018-12-04 18:02:45 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`travel_users`, CONSTRAINT `travel_users_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `travel_users` (`firstName`, `phone`, `userEmail`, `password`) VALUES ('Robert user', '9865321254', 'Druser@dr.com', '123456')
ERROR - 2018-12-04 18:04:47 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`travel_users`, CONSTRAINT `travel_users_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `travel_users` (`firstName`, `phone`, `userEmail`, `password`, `companyId`) VALUES ('Robert user', '9865321254', 'Druser@dr.com', '123456', 'Robert Tucker')
ERROR - 2018-12-04 18:05:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`travel_users`, CONSTRAINT `travel_users_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `travel_users` (`firstName`, `phone`, `userEmail`, `password`, `companyId`) VALUES ('Robert user', '9865321254', 'Druser@dr.com', '123456', 'Robert Tucker')
ERROR - 2018-12-04 18:06:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 18:08:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 18:40:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 18:40:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 18:42:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 18:42:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 18:42:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 18:42:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 18:43:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 18:43:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 18:45:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 18:45:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 19:44:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 19:44:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 19:47:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 19:47:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 19:50:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 19:50:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 19:52:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 159
ERROR - 2018-12-04 19:52:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 19:52:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-04 19:53:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 159
ERROR - 2018-12-04 21:03:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 21:03:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 21:04:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 21:04:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 21:05:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 21:06:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 21:06:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 21:19:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-04 21:42:49 --> Severity: Notice --> Undefined index: todate /var/www/travel_app/application/controllers/Daybook.php 327
ERROR - 2018-12-04 21:42:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') < `IS` `NULL`
AND `payment_t' at line 3 - Invalid query: SELECT `debit`, `description`, `pay_to`, `voucher_no`, `created_at`, `payment_type`, `credit`
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') < `IS` `NULL`
AND `payment_type` = 'cash'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 21:42:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 21:44:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-12-04'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-12-04'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 21:47:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-12-04'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-12-04'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 21:54:04 --> Severity: Notice --> Undefined variable: to_data /var/www/travel_app/application/models/Daybook_model.php 122
ERROR - 2018-12-04 21:54:04 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-12-04 21:54:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array
AND DATE_FORMAT(created_at,'%Y-%m-%d') < `IS` `NULL`
AND `companyId` = '10' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` Array
AND DATE_FORMAT(created_at,'%Y-%m-%d') < `IS` `NULL`
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 21:56:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-12-04'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-12-04'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 21:59:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-12-04'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '2018-12-03'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-12-04'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 21:59:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 21:59:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 22:01:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 22:01:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 22:01:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `company' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = `>` '04-12-2018'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '04-12-2018'
AND `companyId` = '102'
ORDER BY `created_at` DESC
ERROR - 2018-12-04 22:12:43 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/travel_app/application/controllers/Welcome.php 337
ERROR - 2018-12-04 22:13:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 22:15:27 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/travel_app/application/controllers/Welcome.php 338
ERROR - 2018-12-04 22:26:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-04 22:29:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 22:29:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 22:29:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 22:29:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-04 22:30:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-04 22:30:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-04 22:31:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
