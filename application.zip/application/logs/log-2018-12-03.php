<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-03 09:00:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 09:01:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 09:02:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 09:04:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 09:08:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:08:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:08:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:08:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:09:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:09:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:09:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:09:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:09:30 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:09:30 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:10:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:10:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:13:30 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:13:30 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:14:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:14:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:14:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:14:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:18:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:18:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:18:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:18:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:18:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 09:20:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:20:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:28:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 09:36:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 09:36:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 09:38:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 09:39:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 09:43:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 09:43:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 09:44:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:44:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:44:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 09:45:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 09:45:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 09:47:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:47:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:47:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:47:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:56:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 09:56:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 10:09:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 10:10:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 10:13:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 10:13:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 277
ERROR - 2018-12-03 10:14:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 10:23:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 277
ERROR - 2018-12-03 10:26:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 277
ERROR - 2018-12-03 10:34:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 277
ERROR - 2018-12-03 10:59:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 11:02:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 11:05:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:16:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:16:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 12:16:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:20:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:21:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:22:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:22:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 12:23:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:32:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:33:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:34:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:34:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:51:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 12:51:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:51:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 12:51:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 12:51:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 13:04:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 13:06:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 13:14:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 13:14:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 13:14:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 13:14:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 13:15:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 13:15:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 13:15:25 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 13:15:25 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:28:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:28:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:28:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:28:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:28:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:28:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:29:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 14:29:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:29:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:29:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:29:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:36:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:36:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 14:36:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 14:36:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 14:37:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:37:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 14:38:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:38:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 14:38:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:38:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 14:39:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:39:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 14:39:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:39:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 14:40:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 14:43:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:43:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 14:43:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 14:43:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:43:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 14:43:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 14:55:09 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:55:09 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:55:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:55:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 14:55:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 14:55:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 14:56:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 15:02:10 --> 404 Page Not Found: Dev/index
ERROR - 2018-12-03 15:06:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:06:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:06:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:06:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:06:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:06:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:06:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:06:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:07:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 15:07:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:09:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:09:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:10:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:10:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:10:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:10:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:10:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:10:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:12:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:12:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:12:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:12:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:12:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:12:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:13:01 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:13:01 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:13:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:14:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:14:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:14:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:14:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:22:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:22:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 15:22:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:22:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:23:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 15:23:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:23:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:24:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 15:24:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:24:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:24:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:24:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:24:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:24:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:24:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:24:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:24:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:24:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:25:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:25:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:25:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:25:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:25:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:25:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:25:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:25:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:25:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:25:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:25:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:25:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 15:26:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:28:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:28:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:28:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:28:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:29:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:29:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 15:30:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 15:31:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 15:48:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:48:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:48:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:48:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:48:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:48:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:48:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 15:48:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 15:48:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:02:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:02:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:02:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:02:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:02:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:02:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:02:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:02:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:02:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:04:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:04:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:04:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:05:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:05:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:05:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:05:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:05:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:05:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:05:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:05:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:05:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:05:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:05:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:05:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:05:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:08:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:08:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:08:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:08:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:08:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:08:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:08:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:08:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:10:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:10:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:10:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:10:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:10:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:10:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:10:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:10:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:10:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:10:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:11:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:11:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:11:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:11:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:11:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:11:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:11:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:11:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:11:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:11:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:11:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:13:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:13:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:14:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:14:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:14:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:14:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:17:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:17:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:18:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:19:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:37:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:37:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:39:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:39:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:39:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:39:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:39:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:40:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:40:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:41:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:41:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:41:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:42:17 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 16:42:17 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 16:42:31 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 16:42:31 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 16:42:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:42:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:42:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:42:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:42:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:42:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 16:42:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 16:43:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 16:43:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-03 16:43:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:43:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:43:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:43:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 16:43:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 16:43:32 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 16:43:32 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 16:43:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 16:43:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 16:43:43 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 16:43:43 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-03 16:43:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:44:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:44:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:44:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:45:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:45:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:45:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:45:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:46:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:47:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:47:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:49:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:49:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 16:49:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:49:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:50:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:50:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:51:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:52:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 16:52:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 16:58:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 17:04:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 17:05:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:05:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:05:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:05:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:05:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:05:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:05:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:05:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:05:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:05:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:05:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:06:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:06:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:07:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:10:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 17:16:03 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 79
ERROR - 2018-12-03 17:16:15 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 79
ERROR - 2018-12-03 17:16:20 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 79
ERROR - 2018-12-03 17:16:28 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 79
ERROR - 2018-12-03 17:16:29 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 79
ERROR - 2018-12-03 17:16:40 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 79
ERROR - 2018-12-03 17:16:44 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 79
ERROR - 2018-12-03 17:18:10 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 79
ERROR - 2018-12-03 17:18:39 --> Severity: Parsing Error --> syntax error, unexpected '"; </script>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 78
ERROR - 2018-12-03 17:26:01 --> 404 Page Not Found: Welcome/welcome
ERROR - 2018-12-03 17:29:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:29:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:37:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:37:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-03 17:37:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:38:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 17:38:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:39:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-03 17:42:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 17:42:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 17:44:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-03 17:45:16 --> Severity: Notice --> Undefined variable: error /var/www/travel_app/application/views/select_company.php 27
ERROR - 2018-12-03 17:45:16 --> Severity: Notice --> Undefined variable: error /var/www/travel_app/application/views/select_company.php 28
ERROR - 2018-12-03 17:46:05 --> Severity: Notice --> Undefined variable: error /var/www/travel_app/application/views/select_company.php 27
ERROR - 2018-12-03 17:46:05 --> Severity: Notice --> Undefined variable: error /var/www/travel_app/application/views/select_company.php 28
ERROR - 2018-12-03 17:46:20 --> Severity: Notice --> Undefined variable: error /var/www/travel_app/application/views/select_company.php 27
ERROR - 2018-12-03 17:46:20 --> Severity: Notice --> Undefined variable: error /var/www/travel_app/application/views/select_company.php 28
