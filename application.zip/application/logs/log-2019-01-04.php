<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-04 09:00:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:08:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:08:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:09:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:10:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:11:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:11:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:13:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:13:53 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 09:27:14 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 09:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 09:27:14 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 09:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 09:48:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 09:49:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 207
ERROR - 2019-01-04 09:49:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 207
ERROR - 2019-01-04 09:54:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:54:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:54:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:54:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:55:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:55:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:55:43 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:55:43 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:56:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:56:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 208
ERROR - 2019-01-04 09:56:30 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:01:32 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 10:01:32 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 10:01:33 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:04:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 10:04:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 10:04:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:14:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 10:14:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 10:14:11 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:28:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 228
ERROR - 2019-01-04 10:28:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 228
ERROR - 2019-01-04 10:28:48 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:30:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 228
ERROR - 2019-01-04 10:30:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 228
ERROR - 2019-01-04 10:30:21 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:31:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 10:31:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 10:31:06 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:31:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 10:31:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 10:31:42 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:31:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 10:31:51 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:32:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 10:32:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 10:32:05 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 10:38:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 10:43:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 10:43:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 10:46:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 10:47:08 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 10:47:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 10:47:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 10:47:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 10:47:53 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 10:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 10:47:53 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 10:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 10:48:09 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 10:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 10:48:09 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 10:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 10:48:13 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 10:48:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 10:48:13 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 10:48:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 10:49:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 10:50:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 10:50:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 10:50:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 10:53:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:15:14 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:15:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 11:15:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 11:15:56 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:15:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:16:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 11:16:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 11:16:48 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:16:50 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:17:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:17:35 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:17:47 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:17:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 11:17:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 11:17:57 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:18:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 11:18:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 242
ERROR - 2019-01-04 11:19:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 245
ERROR - 2019-01-04 11:19:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 245
ERROR - 2019-01-04 11:20:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 11:20:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 11:21:02 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:22:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 11:22:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 11:22:40 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:22:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 11:22:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 210
ERROR - 2019-01-04 11:22:59 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:25:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 211
ERROR - 2019-01-04 11:25:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 211
ERROR - 2019-01-04 11:25:42 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:27:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 209
ERROR - 2019-01-04 11:27:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 209
ERROR - 2019-01-04 11:27:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:27:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 209
ERROR - 2019-01-04 11:27:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 209
ERROR - 2019-01-04 11:27:36 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:27:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 209
ERROR - 2019-01-04 11:27:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 209
ERROR - 2019-01-04 11:27:55 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:28:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 209
ERROR - 2019-01-04 11:28:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 209
ERROR - 2019-01-04 11:28:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 11:28:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 211
ERROR - 2019-01-04 11:28:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 211
ERROR - 2019-01-04 11:31:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:32:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:33:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:33:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:35:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-04 11:35:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-04 11:37:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-04 11:37:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-04 11:38:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 11:38:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 11:38:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 11:38:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 11:39:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 11:39:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 11:39:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-04 11:39:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-04 11:42:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 11:42:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 11:50:37 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 11:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 11:50:37 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 11:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 11:50:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:54:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:55:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:56:25 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 11:56:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 11:56:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 11:56:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 11:57:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:58:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 11:59:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:01:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:02:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:03:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:11:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:13:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:17:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:23:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:41:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-04 12:41:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-04 12:41:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-04 12:41:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-04 12:41:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-04 12:41:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-04 12:41:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-04 12:41:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-04 12:42:17 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 12:42:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 12:42:17 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 12:42:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 12:42:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:42:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:42:58 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 187
ERROR - 2019-01-04 12:43:14 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 187
ERROR - 2019-01-04 12:44:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:45:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:46:16 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 12:46:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 12:46:16 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 12:46:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 12:46:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:48:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:48:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 146
ERROR - 2019-01-04 12:48:25 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 312
ERROR - 2019-01-04 12:48:54 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 318
ERROR - 2019-01-04 12:51:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:52:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:53:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:57:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:57:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 211
ERROR - 2019-01-04 12:57:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 211
ERROR - 2019-01-04 12:57:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:57:46 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 201
ERROR - 2019-01-04 12:57:51 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 201
ERROR - 2019-01-04 12:58:07 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 201
ERROR - 2019-01-04 12:58:15 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 201
ERROR - 2019-01-04 12:58:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:58:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:58:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 12:59:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 13:05:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 13:46:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 13:47:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 13:47:43 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:47:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:47:43 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:47:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:47:45 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2019-01-04 13:47:45 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 286
ERROR - 2019-01-04 13:47:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2019-01-04 13:47:52 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2019-01-04 13:47:52 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 286
ERROR - 2019-01-04 13:47:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2019-01-04 13:49:10 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:10 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:12 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:12 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:17 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2019-01-04 13:49:17 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 286
ERROR - 2019-01-04 13:49:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2019-01-04 13:49:19 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:19 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:21 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2019-01-04 13:49:21 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2019-01-04 13:49:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2019-01-04 13:49:23 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:23 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:41 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:49:41 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:51:17 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:51:17 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:58:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 13:58:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 13:59:58 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 13:59:58 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 13:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 14:08:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 14:08:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 14:09:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 14:09:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 14:09:41 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 14:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 14:09:41 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 14:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 14:13:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 14:13:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 14:15:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 14:15:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 14:18:36 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 14:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 14:18:36 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 14:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 14:18:39 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/controllers/Welcome.php 391
ERROR - 2019-01-04 14:18:39 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Welcome.php 774
ERROR - 2019-01-04 14:18:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` in()
ERROR - 2019-01-04 14:19:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 14:19:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 14:20:30 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 14:20:30 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 14:20:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 14:20:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 14:20:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 14:20:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 14:21:30 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 14:21:30 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-04 14:54:47 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 14:54:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:07:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 15:07:34 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:07:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:15:47 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:15:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:16:49 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:16:52 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:16:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:17:02 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:17:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:17:43 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:17:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:19:15 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:19:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 15:19:21 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:19:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:25:02 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:25:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:26:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 268
ERROR - 2019-01-04 15:26:50 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/travel_app/application/controllers/Report.php 293
ERROR - 2019-01-04 15:27:44 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:27:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:27:48 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:27:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:28:03 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:28:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:28:07 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:28:11 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:28:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:28:17 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:28:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:28:44 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 15:28:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 15:30:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 15:46:44 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/controllers/Report.php 275
ERROR - 2019-01-04 15:49:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 16:02:25 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:02:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 16:17:28 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:17:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 16:18:15 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:18:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 16:21:02 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:21:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 16:21:29 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 328
ERROR - 2019-01-04 16:21:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:21:41 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:21:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 16:38:39 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:38:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 16:38:42 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:38:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-04 16:54:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 16:54:31 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 16:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-04 16:54:31 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 16:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-04 16:55:33 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 16:56:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 16:56:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 214
ERROR - 2019-01-04 17:01:25 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 216
ERROR - 2019-01-04 17:01:25 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 216
ERROR - 2019-01-04 17:01:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 216
ERROR - 2019-01-04 17:01:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 216
ERROR - 2019-01-04 17:02:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 216
ERROR - 2019-01-04 17:02:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 216
ERROR - 2019-01-04 17:03:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:03:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:03:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:03:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:04:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:04:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:04:31 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:04:31 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:04:41 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 17:04:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:04:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:04:50 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 17:05:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:05:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:05:10 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 17:05:31 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:05:31 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-04 17:05:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 17:05:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 17:06:06 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 17:06:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 17:06:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 17:06:15 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 17:06:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 17:06:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 17:06:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-04 17:06:49 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-04 17:06:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 17:08:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-04 17:17:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
