<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-28 09:18:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:18:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:18:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:20:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:21:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:21:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 09:21:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 09:21:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:23:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:24:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:27:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:43:17 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_booking_graph.php 46
ERROR - 2018-11-28 09:45:19 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_booking_graph.php 46
ERROR - 2018-11-28 09:47:59 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_booking_graph.php 46
ERROR - 2018-11-28 09:48:51 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_booking_graph.php 46
ERROR - 2018-11-28 09:49:16 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_booking_graph.php 46
ERROR - 2018-11-28 09:49:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:49:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:49:46 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_booking_graph.php 46
ERROR - 2018-11-28 09:50:13 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_booking_graph.php 51
ERROR - 2018-11-28 09:50:49 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/travel_app/application/views/user/total_booking_graph.php 51
ERROR - 2018-11-28 09:53:27 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_booking_graph.php 48
ERROR - 2018-11-28 09:57:10 --> 404 Page Not Found: Welcome/%3C
ERROR - 2018-11-28 09:57:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 09:58:34 --> 404 Page Not Found: Report/get_day_book
ERROR - 2018-11-28 10:00:51 --> 404 Page Not Found: Report/get_day_book
ERROR - 2018-11-28 10:01:07 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) /var/www/travel_app/application/views/user/total_booking_graph.php 55
ERROR - 2018-11-28 10:01:21 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) /var/www/travel_app/application/views/user/total_booking_graph.php 55
ERROR - 2018-11-28 10:02:10 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/total_booking_graph.php 68
ERROR - 2018-11-28 10:02:23 --> Severity: Notice --> Undefined index: as totcount /var/www/travel_app/application/views/user/total_booking_graph.php 57
ERROR - 2018-11-28 10:02:23 --> Severity: Notice --> Undefined index: as totcount /var/www/travel_app/application/views/user/total_booking_graph.php 57
ERROR - 2018-11-28 10:02:23 --> Severity: Notice --> Undefined index: as totcount /var/www/travel_app/application/views/user/total_booking_graph.php 57
ERROR - 2018-11-28 10:03:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:05:06 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 61
ERROR - 2018-11-28 10:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:05:13 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 61
ERROR - 2018-11-28 10:05:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:06:27 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 63
ERROR - 2018-11-28 10:06:40 --> Severity: Parsing Error --> syntax error, unexpected '$i' (T_VARIABLE), expecting ';' /var/www/travel_app/application/views/user/total_booking_graph.php 59
ERROR - 2018-11-28 10:06:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:07:36 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 63
ERROR - 2018-11-28 10:07:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Daybook_model /var/www/travel_app/system/core/Loader.php 348
ERROR - 2018-11-28 10:08:35 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 60
ERROR - 2018-11-28 10:08:46 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 33
ERROR - 2018-11-28 10:08:46 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 50
ERROR - 2018-11-28 10:08:46 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 50
ERROR - 2018-11-28 10:08:46 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:10:03 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 42
ERROR - 2018-11-28 10:10:03 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 59
ERROR - 2018-11-28 10:10:03 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 59
ERROR - 2018-11-28 10:10:03 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:10:31 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 61
ERROR - 2018-11-28 10:10:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:10:40 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 42
ERROR - 2018-11-28 10:10:40 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 59
ERROR - 2018-11-28 10:10:40 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 59
ERROR - 2018-11-28 10:10:40 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:10:53 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 42
ERROR - 2018-11-28 10:10:53 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 59
ERROR - 2018-11-28 10:10:53 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 59
ERROR - 2018-11-28 10:10:53 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:11:53 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 61
ERROR - 2018-11-28 10:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:12:07 --> 404 Page Not Found: R/index
ERROR - 2018-11-28 10:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:13:59 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 61
ERROR - 2018-11-28 10:13:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:13:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:14:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:15:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:15:27 --> Severity: Error --> Allowed memory size of 1073741824 bytes exhausted (tried to allocate 1072693248 bytes) /var/www/travel_app/application/views/user/total_booking_graph.php 61
ERROR - 2018-11-28 10:16:56 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/expenses.php 424
ERROR - 2018-11-28 10:17:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:17:31 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:17:31 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:17:31 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:17:31 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:18:02 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:18:02 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:18:02 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:18:02 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:19:50 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:19:50 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:19:50 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:19:50 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:20:44 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:20:44 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:20:44 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:20:44 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:21:37 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:21:37 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:21:37 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:21:37 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:22:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:22:40 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:22:40 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:22:40 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:22:40 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:22:43 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:22:43 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:22:43 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:22:43 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:22:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 56
ERROR - 2018-11-28 10:22:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 71
ERROR - 2018-11-28 10:22:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:22:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:22:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:23:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:23:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:24:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:24:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:24:45 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:24:45 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:24:45 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:24:45 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:24:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:26:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:26:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:26:59 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:26:59 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:26:59 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:27:00 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:27:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 55
ERROR - 2018-11-28 10:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/total_booking_graph.php 71
ERROR - 2018-11-28 10:27:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:28:25 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 46
ERROR - 2018-11-28 10:28:25 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:28:25 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:28:25 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:28:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:28:49 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 44
ERROR - 2018-11-28 10:28:49 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 61
ERROR - 2018-11-28 10:28:49 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 61
ERROR - 2018-11-28 10:28:49 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:29:53 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:29:53 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:29:53 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:30:10 --> Severity: Warning --> date() expects parameter 2 to be long, string given /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:30:10 --> Severity: Warning --> date() expects parameter 2 to be long, string given /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:30:10 --> Severity: Warning --> date() expects parameter 2 to be long, string given /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:31:57 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:31:57 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:31:57 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/views/user/total_booking_graph.php 76
ERROR - 2018-11-28 10:32:26 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:32:26 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:32:26 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:32:26 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:33:45 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:33:45 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:33:45 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:33:45 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:34:24 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:34:24 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:34:24 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:34:24 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:34:25 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:34:25 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:34:25 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:34:25 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:34:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:34:51 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:34:51 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:34:51 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:34:51 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:35:01 --> Severity: Notice --> Undefined variable: total_credit /var/www/travel_app/application/views/user/total_credit_graph.php 54
ERROR - 2018-11-28 10:45:47 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:45:47 --> Severity: Notice --> Undefined property: CI_Loader::$fee_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:45:47 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:45:47 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:47:02 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:47:02 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:47:02 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:47:02 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:47:04 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:47:04 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:47:04 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:47:04 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:47:31 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:47:31 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:47:31 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:47:31 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:48:02 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 44
ERROR - 2018-11-28 10:48:02 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 61
ERROR - 2018-11-28 10:48:02 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 61
ERROR - 2018-11-28 10:48:02 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:48:32 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 45
ERROR - 2018-11-28 10:48:32 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:48:32 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 62
ERROR - 2018-11-28 10:48:32 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:50:43 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 46
ERROR - 2018-11-28 10:50:43 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:50:43 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:50:43 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:50:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 10:50:55 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 46
ERROR - 2018-11-28 10:50:55 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:50:55 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:50:55 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:51:38 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 46
ERROR - 2018-11-28 10:51:38 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:51:38 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:51:38 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:52:08 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 46
ERROR - 2018-11-28 10:52:08 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:52:08 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 10:52:08 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:52:47 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 56
ERROR - 2018-11-28 10:52:47 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 73
ERROR - 2018-11-28 10:52:47 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 73
ERROR - 2018-11-28 10:52:47 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:53:16 --> Severity: Error --> Call to undefined method First_model::search_customer() /var/www/travel_app/application/controllers/Admin.php 113
ERROR - 2018-11-28 10:53:17 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 55
ERROR - 2018-11-28 10:53:17 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 72
ERROR - 2018-11-28 10:53:17 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 72
ERROR - 2018-11-28 10:53:17 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:53:18 --> Severity: Error --> Call to undefined method First_model::search_customer() /var/www/travel_app/application/controllers/Admin.php 113
ERROR - 2018-11-28 10:53:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:53:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 10:53:29 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 55
ERROR - 2018-11-28 10:53:29 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 72
ERROR - 2018-11-28 10:53:29 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 72
ERROR - 2018-11-28 10:53:29 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:53:30 --> Severity: Error --> Call to undefined method First_model::search_customer() /var/www/travel_app/application/controllers/Admin.php 113
ERROR - 2018-11-28 10:53:47 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 55
ERROR - 2018-11-28 10:53:47 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 72
ERROR - 2018-11-28 10:53:47 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 72
ERROR - 2018-11-28 10:53:47 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:54:23 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 55
ERROR - 2018-11-28 10:54:23 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 72
ERROR - 2018-11-28 10:54:23 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 72
ERROR - 2018-11-28 10:54:23 --> 404 Page Not Found: Daybook/assets
ERROR - 2018-11-28 10:58:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 10:58:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 11:03:45 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/travel_app/application/controllers/Daybook.php 21
ERROR - 2018-11-28 11:04:01 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 11:04:01 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 80
ERROR - 2018-11-28 11:04:01 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 80
ERROR - 2018-11-28 11:04:28 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 11:04:28 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 80
ERROR - 2018-11-28 11:04:28 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 80
ERROR - 2018-11-28 11:04:29 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 63
ERROR - 2018-11-28 11:04:29 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 80
ERROR - 2018-11-28 11:04:29 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 80
ERROR - 2018-11-28 11:05:47 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:05:47 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:05:47 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:06:28 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:06:28 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:06:28 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:06:41 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:06:41 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:06:41 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:08:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:08:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 11:08:28 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:08:28 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:08:28 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:08:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:08:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 11:10:44 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 206
ERROR - 2018-11-28 11:10:44 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 209
ERROR - 2018-11-28 11:11:00 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 206
ERROR - 2018-11-28 11:11:00 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 209
ERROR - 2018-11-28 11:11:21 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 206
ERROR - 2018-11-28 11:11:21 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 209
ERROR - 2018-11-28 11:12:03 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 206
ERROR - 2018-11-28 11:12:03 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 209
ERROR - 2018-11-28 11:12:22 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:12:22 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:12:22 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:13:24 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/travel_app/application/controllers/Daybook.php 44
ERROR - 2018-11-28 11:13:54 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:13:54 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:13:54 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:14:24 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:14:24 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:14:24 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:15:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:15:37 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:15:37 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:15:37 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:15:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:15:41 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:15:41 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:15:41 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:15:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:17:47 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:17:47 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:17:47 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:17:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:17:48 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:17:48 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:17:48 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:17:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:17:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 11:17:54 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 64
ERROR - 2018-11-28 11:17:54 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:17:54 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 81
ERROR - 2018-11-28 11:17:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:22:23 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/navigation.php 31
ERROR - 2018-11-28 11:26:33 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/expenses.php 22
ERROR - 2018-11-28 11:26:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:26:54 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 74
ERROR - 2018-11-28 11:26:54 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 91
ERROR - 2018-11-28 11:26:54 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 91
ERROR - 2018-11-28 11:26:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:26:58 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 74
ERROR - 2018-11-28 11:26:58 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 91
ERROR - 2018-11-28 11:26:58 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 91
ERROR - 2018-11-28 11:28:23 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 75
ERROR - 2018-11-28 11:28:23 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 92
ERROR - 2018-11-28 11:28:23 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 92
ERROR - 2018-11-28 11:28:46 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 75
ERROR - 2018-11-28 11:28:46 --> Severity: Notice --> Undefined property: CI_Loader::$Daybook_model /var/www/travel_app/application/views/user/expenses.php 92
ERROR - 2018-11-28 11:28:46 --> Severity: Error --> Call to a member function get_expense_types() on null /var/www/travel_app/application/views/user/expenses.php 92
ERROR - 2018-11-28 11:29:09 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 75
ERROR - 2018-11-28 11:29:09 --> Severity: Error --> Call to undefined method Daybook_model::get_expense_types() /var/www/travel_app/application/views/user/expenses.php 92
ERROR - 2018-11-28 11:29:11 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 75
ERROR - 2018-11-28 11:29:11 --> Severity: Error --> Call to undefined method Daybook_model::get_expense_types() /var/www/travel_app/application/views/user/expenses.php 92
ERROR - 2018-11-28 11:29:51 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 75
ERROR - 2018-11-28 11:29:51 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/expenses.php 95
ERROR - 2018-11-28 11:29:53 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 75
ERROR - 2018-11-28 11:29:53 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/expenses.php 95
ERROR - 2018-11-28 11:30:31 --> Severity: Notice --> Undefined variable: billno /var/www/travel_app/application/views/user/expenses.php 75
ERROR - 2018-11-28 11:30:31 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/expenses.php 95
ERROR - 2018-11-28 11:31:33 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/expenses.php 95
ERROR - 2018-11-28 11:32:05 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/expenses.php 111
ERROR - 2018-11-28 11:33:37 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:34:50 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:35:40 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:39:17 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:39:18 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:43:57 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:46:26 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:47:52 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:49:05 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:49:53 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:50:24 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:52:04 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:52:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:52:56 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:52:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:54:14 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:54:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:55:18 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:55:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:56:51 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:56:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:57:14 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:57:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:58:56 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 142
ERROR - 2018-11-28 11:58:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 11:59:58 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 144
ERROR - 2018-11-28 11:59:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 12:00:36 --> Severity: Error --> Call to undefined method Daybook_model::get_banks() /var/www/travel_app/application/views/user/expenses.php 162
ERROR - 2018-11-28 12:00:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 12:17:16 --> Severity: Notice --> Undefined property: stdClass::$userName /var/www/travel_app/application/views/user/expenses.php 207
ERROR - 2018-11-28 12:29:15 --> Query error: Unknown column 'cid' in 'field list' - Invalid query: INSERT INTO `expense` (`cid`, `type`, `pay_to`, `phone`, `amount`, `payment_type`, `particulars`, `approved_by`, `created_by`) VALUES ('101', '1', 'dsfcsdfd', '9865321254', '5000', 'cash', 'asdafafafsffs', 'anjali m ksoft', '1')
ERROR - 2018-11-28 12:38:28 --> Query error: Unknown column 'cid' in 'field list' - Invalid query: INSERT INTO `expense` (`cid`, `type`, `pay_to`, `phone`, `amount`, `payment_type`, `particulars`, `approved_by`, `created_by`) VALUES ('101', '1', 'dsfcsdfd', '9865321254', '5000', 'cash', 'asdafafafsffs', 'anjali m ksoft', '1')
ERROR - 2018-11-28 12:43:21 --> Query error: Unknown column 'amount' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `amount`, `payment_type`, `description`, `approved_by`, `created_by`) VALUES ('101', '1', 'anjali', '9865321254', '5000', 'cash', 'Baggage', 'anjali m ksoft', '1')
ERROR - 2018-11-28 12:45:14 --> Query error: Unknown column 'amount' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `amount`, `payment_type`, `description`, `approved_by`, `created_by`) VALUES ('101', '1', 'anjali', '9865321254', '5000', 'cash', 'Baggage', 'anjali m ksoft', '1')
ERROR - 2018-11-28 12:47:11 --> Query error: Unknown column 'created_by' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `created_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', 'anjali m ksoft', '1')
ERROR - 2018-11-28 12:49:34 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`expense`, CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', '1')
ERROR - 2018-11-28 12:51:55 --> Severity: Notice --> Undefined variable: page_data /var/www/travel_app/application/controllers/Daybook.php 41
ERROR - 2018-11-28 12:51:55 --> Query error: Column 'approved_by' cannot be null - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', NULL)
ERROR - 2018-11-28 12:52:37 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`expense`, CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', '1')
ERROR - 2018-11-28 12:54:04 --> Severity: Notice --> Undefined variable: page_data /var/www/travel_app/application/controllers/Daybook.php 41
ERROR - 2018-11-28 12:54:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Daybook.php 41
ERROR - 2018-11-28 12:54:04 --> Query error: Column 'approved_by' cannot be null - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', NULL)
ERROR - 2018-11-28 12:54:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`expense`, CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', '1')
ERROR - 2018-11-28 12:56:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`expense`, CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', 'anjali m ksoft')
ERROR - 2018-11-28 12:56:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`expense`, CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', '1')
ERROR - 2018-11-28 12:59:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`expense`, CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', '1')
ERROR - 2018-11-28 13:01:45 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`expense`, CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `expense` (`customerId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('101', '1', 'anjali', '9865321254', '2500', 'cash', 'Baggage', '1')
ERROR - 2018-11-28 13:01:59 --> Severity: 8192 --> mysql_insert_id(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/travel_app/application/models/Daybook_model.php 23
ERROR - 2018-11-28 13:01:59 --> Severity: Warning --> mysql_insert_id(): Access denied for user ''@'localhost' (using password: NO) /var/www/travel_app/application/models/Daybook_model.php 23
ERROR - 2018-11-28 13:01:59 --> Severity: Warning --> mysql_insert_id(): A link to the server could not be established /var/www/travel_app/application/models/Daybook_model.php 23
ERROR - 2018-11-28 13:02:38 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`) VALUES ('1', '101', '1', 'anjali', '9865321254', '5000', 'cash', 'Baggage', '1')
ERROR - 2018-11-28 13:03:27 --> Severity: Warning --> mysqli_insert_id() expects exactly 1 parameter, 0 given /var/www/travel_app/application/models/Daybook_model.php 23
ERROR - 2018-11-28 13:03:51 --> Severity: Warning --> mysqli_insert_id() expects exactly 1 parameter, 0 given /var/www/travel_app/application/models/Daybook_model.php 23
ERROR - 2018-11-28 13:04:37 --> Severity: Warning --> mysqli_insert_id() expects exactly 1 parameter, 0 given /var/www/travel_app/application/models/Daybook_model.php 23
ERROR - 2018-11-28 13:06:30 --> Query error: Unknown column 'bank_name' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`, `approved_by`) VALUES ('1', '101', '1', 'xdcvffdgv', '9865321254', '52587', 'cheque', 'Canara', 'VF4546', '2018-11-07', 'Fee', '1')
ERROR - 2018-11-28 13:09:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 14:20:49 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 5
ERROR - 2018-11-28 14:22:44 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 26
ERROR - 2018-11-28 14:23:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 14:29:00 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 34
ERROR - 2018-11-28 14:29:00 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 14:29:00 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 14:29:00 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 14:29:00 --> Query error: Table 'travel_app_db.expenses' doesn't exist - Invalid query: SELECT *
FROM `expenses`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') >= '--2018-11-01'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '--2018-11-30'
ORDER BY `created_at` DESC
ERROR - 2018-11-28 14:29:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 14:29:32 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Daybook.php 145
ERROR - 2018-11-28 14:29:32 --> Query error: Table 'travel_app_db.expenses' doesn't exist - Invalid query: SELECT *
FROM `expenses`
ORDER BY `created_at` DESC
ERROR - 2018-11-28 14:29:34 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Daybook.php 145
ERROR - 2018-11-28 14:29:34 --> Query error: Table 'travel_app_db.expenses' doesn't exist - Invalid query: SELECT *
FROM `expenses`
ORDER BY `created_at` DESC
ERROR - 2018-11-28 14:29:41 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Daybook.php 145
ERROR - 2018-11-28 14:29:41 --> Query error: Table 'travel_app_db.expenses' doesn't exist - Invalid query: SELECT *
FROM `expenses`
ORDER BY `created_at` DESC
ERROR - 2018-11-28 14:31:44 --> Query error: Table 'travel_app_db.expenses' doesn't exist - Invalid query: SELECT *
FROM `expenses`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') >= '2018-11-28'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-11-28'
ORDER BY `created_at` DESC
ERROR - 2018-11-28 14:32:03 --> Query error: Unknown column 'created_at' in 'where clause' - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') >= '2018-11-28'
AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '2018-11-28'
ORDER BY `created_at` DESC
ERROR - 2018-11-28 14:38:51 --> Severity: Notice --> Undefined variable: user_id /var/www/travel_app/application/views/user/transaction_report.php 43
ERROR - 2018-11-28 14:38:51 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 50
ERROR - 2018-11-28 14:39:22 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 49
ERROR - 2018-11-28 14:41:54 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 57
ERROR - 2018-11-28 14:43:06 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 59
ERROR - 2018-11-28 14:43:23 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 59
ERROR - 2018-11-28 14:43:37 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 59
ERROR - 2018-11-28 14:44:00 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 59
ERROR - 2018-11-28 14:44:01 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 59
ERROR - 2018-11-28 14:44:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 14:44:58 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 59
ERROR - 2018-11-28 14:44:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 14:45:35 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/transaction_report.php 87
ERROR - 2018-11-28 14:45:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/transaction_report.php 90
ERROR - 2018-11-28 14:45:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/transaction_report.php 91
ERROR - 2018-11-28 14:45:35 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:45:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:45:35 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:45:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 14:46:06 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/transaction_report.php 87
ERROR - 2018-11-28 14:46:06 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/transaction_report.php 90
ERROR - 2018-11-28 14:46:06 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/transaction_report.php 91
ERROR - 2018-11-28 14:46:06 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:46:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:46:06 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:46:56 --> Severity: Notice --> Undefined index: escription /var/www/travel_app/application/views/user/transaction_report.php 90
ERROR - 2018-11-28 14:46:56 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:46:56 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:46:56 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:47:07 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:47:07 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:47:07 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:47 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:47 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:47 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:48 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:48 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:50 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:50 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:50 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:50 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:50 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:50 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:48:51 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:48:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:48:51 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:49:10 --> Severity: Notice --> Undefined index: created_by /var/www/travel_app/application/views/user/transaction_report.php 95
ERROR - 2018-11-28 14:49:10 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:49:10 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:49:40 --> Severity: Notice --> Undefined property: stdClass::$name /var/www/travel_app/application/views/user/transaction_report.php 96
ERROR - 2018-11-28 14:49:40 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:49:40 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:50:36 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/transaction_report.php 86
ERROR - 2018-11-28 14:50:36 --> Severity: Notice --> Undefined property: stdClass::$name /var/www/travel_app/application/views/user/transaction_report.php 96
ERROR - 2018-11-28 14:50:36 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:50:36 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:50:53 --> Severity: Notice --> Undefined property: stdClass::$name /var/www/travel_app/application/views/user/transaction_report.php 96
ERROR - 2018-11-28 14:50:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:50:53 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:51:52 --> Query error: Unknown column 'customerId' in 'where clause' - Invalid query: SELECT *
FROM `travel_users`
WHERE `customerId` = '1'
ERROR - 2018-11-28 14:52:12 --> Query error: Unknown column 'customerId' in 'where clause' - Invalid query: SELECT *
FROM `travel_users`
WHERE `customerId` = '1'
ERROR - 2018-11-28 14:52:54 --> Query error: Unknown column 'customerId' in 'where clause' - Invalid query: SELECT *
FROM `travel_users`
WHERE `customerId` = '1'
ERROR - 2018-11-28 14:53:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:53:44 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/transaction_report.php 111
ERROR - 2018-11-28 14:54:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:54:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:54:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:54:27 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:54:27 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:54:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:54:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:54:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:54:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:55:07 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:55:07 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:55:07 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:07 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:07 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:07 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:55:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:55:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/transaction_report.php 122
ERROR - 2018-11-28 14:55:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:55:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:55:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:55:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:55:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 14:55:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-28 14:55:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-28 14:55:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:55:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:55:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 14:55:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-28 14:55:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-28 14:55:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:55:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:55:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 14:55:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-28 14:55:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-28 14:56:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:56:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:56:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 14:56:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-28 14:56:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-28 14:56:32 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 14:56:32 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 14:56:32 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 14:56:32 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:56:32 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 14:56:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 14:57:11 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 34
ERROR - 2018-11-28 14:57:11 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 14:57:11 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 14:57:11 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 15:00:07 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:00:07 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:00:07 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:00:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:00:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:02:11 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 15:02:11 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 34
ERROR - 2018-11-28 15:02:11 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 15:02:11 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 38
ERROR - 2018-11-28 15:02:11 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 15:02:11 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 15:02:35 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 15:02:35 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 34
ERROR - 2018-11-28 15:02:35 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 38
ERROR - 2018-11-28 15:02:35 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 15:02:51 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 15:02:51 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 34
ERROR - 2018-11-28 15:02:51 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 38
ERROR - 2018-11-28 15:02:51 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 15:03:04 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 15:03:04 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 34
ERROR - 2018-11-28 15:03:04 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 38
ERROR - 2018-11-28 15:03:04 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 15:03:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:03:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:03:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:03:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:03:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:04:12 --> Severity: Notice --> Undefined variable: data1 /var/www/travel_app/application/controllers/Daybook.php 93
ERROR - 2018-11-28 15:04:44 --> Severity: Notice --> Undefined variable: data1 /var/www/travel_app/application/controllers/Daybook.php 93
ERROR - 2018-11-28 15:04:53 --> Severity: Notice --> Undefined variable: data1 /var/www/travel_app/application/controllers/Daybook.php 93
ERROR - 2018-11-28 15:08:18 --> Severity: Notice --> Undefined variable: Day /var/www/travel_app/application/models/Daybook_model.php 34
ERROR - 2018-11-28 15:10:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:10:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:10:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:10:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:10:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:10:19 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 15:10:19 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 15:10:19 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 15:10:19 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 15:11:23 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 15:11:23 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 15:11:23 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 15:11:23 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 15:11:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''%Y-%m-%d') >= '--2018-11-29'
AND DATE_FORMAT(created_at<=,'%Y-%m-%d') <= '--201' at line 3 - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created_at>=,'%Y-%m-%d') >= '--2018-11-29'
AND DATE_FORMAT(created_at<=,'%Y-%m-%d') <= '--2018-11-30'
ORDER BY `created_at` DESC
ERROR - 2018-11-28 15:11:43 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 15:11:43 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 15:11:43 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 15:11:43 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 15:11:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:11:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:11:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:11:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:11:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:12:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:12:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:12:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:12:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:12:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:13:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:13:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:13:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:13:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:13:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:13:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:13:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:13:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:13:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:13:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:13:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:13:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:13:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:13:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:13:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:14:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:14:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:14:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:14:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:14:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:14:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:14:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:14:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:14:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:14:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:14:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:14:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:14:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:14:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:14:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:15:11 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:15:11 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:15:11 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:15:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:15:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:16:09 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:16:09 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:16:09 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:16:09 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:16:09 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:17:13 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:17:13 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:17:13 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:17:13 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:17:13 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:17:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:17:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:17:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:17:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:17:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:17:40 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 15:17:40 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 15:17:40 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 15:17:40 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 15:18:57 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 15:18:57 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 15:18:57 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 15:18:57 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 15:21:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:21:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:21:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:21:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:21:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:21:57 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:21:57 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:21:57 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:21:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:21:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:25:52 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:25:52 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:25:52 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:25:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:25:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:34:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:34:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:34:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:34:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:35:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:35:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:35:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 15:36:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:36:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:36:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:36:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:38:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:38:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:39:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 15:41:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:41:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:42:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:42:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:42:47 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:42:47 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:42:47 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:42:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:42:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:42:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:43:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:43:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:43:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:44:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 15:44:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 15:44:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 15:44:23 --> Query error: Unknown column 'voucher_id' in 'field list' - Invalid query: SELECT MAX(`voucher_id`) AS `voucher_id`
FROM `income`
ERROR - 2018-11-28 15:45:10 --> Severity: Notice --> Undefined property: Daybook::$fee_model /var/www/travel_app/application/controllers/Daybook.php 176
ERROR - 2018-11-28 15:45:10 --> Severity: Error --> Call to a member function add_income() on null /var/www/travel_app/application/controllers/Daybook.php 176
ERROR - 2018-11-28 15:46:35 --> Query error: Unknown column 'created_by' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `cash_from`, `credit`, `payment_type`, `description`, `created_by`) VALUES ('1', '101', 'skdjhasdkad', '5000', 'cash', 'Fee', '1')
ERROR - 2018-11-28 15:49:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 15:51:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:51:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:51:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:51:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:51:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:53:55 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 15:55:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 15:55:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 15:55:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 15:55:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 15:55:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:02:43 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 16:02:43 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:02:43 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:02:43 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:02:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:02:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:02:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 51
ERROR - 2018-11-28 16:02:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 53
ERROR - 2018-11-28 16:02:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 55
ERROR - 2018-11-28 16:03:22 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-11-28 16:03:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 16:03:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-28 16:04:06 --> Severity: Error --> Call to undefined method Daybook_model::income_report() /var/www/travel_app/application/controllers/Daybook.php 257
ERROR - 2018-11-28 16:05:21 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 68
ERROR - 2018-11-28 16:05:21 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:05:21 --> Severity: Notice --> Undefined offset: 20 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:05:21 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 73
ERROR - 2018-11-28 16:05:21 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:05:49 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:05:49 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:05:49 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:05:49 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 75
ERROR - 2018-11-28 16:05:52 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:05:52 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:05:52 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:05:52 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 75
ERROR - 2018-11-28 16:05:58 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:05:58 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:05:58 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:05:58 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 75
ERROR - 2018-11-28 16:06:00 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 16:06:00 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:06:00 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 16:06:00 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:06:08 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:06:08 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:06:08 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:06:08 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 75
ERROR - 2018-11-28 16:07:54 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 16:07:54 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:07:54 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 16:07:54 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:07:54 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:07:54 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:07:54 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:07:54 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 75
ERROR - 2018-11-28 16:07:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/system/core/Exceptions.php:271) /var/www/travel_app/system/core/Common.php 570
ERROR - 2018-11-28 16:07:58 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 16:07:58 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:07:58 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 16:07:58 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:07:58 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:07:58 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:07:58 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:07:58 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 75
ERROR - 2018-11-28 16:07:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/system/core/Exceptions.php:271) /var/www/travel_app/system/core/Common.php 570
ERROR - 2018-11-28 16:22:08 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 33
ERROR - 2018-11-28 16:22:08 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:22:08 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 39
ERROR - 2018-11-28 16:22:08 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:22:08 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:22:08 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:22:08 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:22:08 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 75
ERROR - 2018-11-28 16:22:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/system/core/Exceptions.php:271) /var/www/travel_app/system/core/Common.php 570
ERROR - 2018-11-28 16:23:48 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:23:48 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 16:23:48 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:23:48 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:23:48 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 69
ERROR - 2018-11-28 16:23:48 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 70
ERROR - 2018-11-28 16:23:48 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 74
ERROR - 2018-11-28 16:23:48 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 75
ERROR - 2018-11-28 16:23:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/system/core/Exceptions.php:271) /var/www/travel_app/system/core/Common.php 570
ERROR - 2018-11-28 16:29:56 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:29:56 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 16:29:56 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:29:56 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:30:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:30:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:30:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 51
ERROR - 2018-11-28 16:30:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 53
ERROR - 2018-11-28 16:30:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 55
ERROR - 2018-11-28 16:31:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 16:31:20 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:31:20 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 16:31:20 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:31:20 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:31:30 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:31:30 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 16:31:30 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:31:30 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:31:51 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:31:51 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:31:53 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:31:53 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:32:40 --> Severity: Warning --> explode(): Empty delimiter /var/www/travel_app/application/models/Daybook_model.php 32
ERROR - 2018-11-28 16:32:40 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:32:40 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:32:43 --> Severity: Warning --> explode(): Empty delimiter /var/www/travel_app/application/models/Daybook_model.php 32
ERROR - 2018-11-28 16:32:43 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:32:43 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:32:56 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:32:56 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 16:32:56 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:32:56 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:33:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 16:33:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 16:33:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 16:33:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 16:33:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 16:33:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:33:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:33:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 16:33:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 16:33:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 16:33:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:33:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:33:40 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 35
ERROR - 2018-11-28 16:33:40 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 36
ERROR - 2018-11-28 16:33:40 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 40
ERROR - 2018-11-28 16:33:40 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 41
ERROR - 2018-11-28 16:35:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 16:35:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 16:35:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 16:35:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:35:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:35:01 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 16:35:01 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 16:35:01 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 16:35:01 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:35:01 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 16:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 16:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 16:36:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:36:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:37:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 16:37:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 16:37:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 16:37:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:37:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:38:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 16:39:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 16:39:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 16:39:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 16:39:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:39:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:40:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 16:40:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 16:40:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 16:40:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:40:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 16:43:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:43:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:43:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 51
ERROR - 2018-11-28 16:43:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 53
ERROR - 2018-11-28 16:43:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 55
ERROR - 2018-11-28 16:44:00 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:44:22 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:44:31 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:46:28 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:46:31 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:46:38 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:46:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:46:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:46:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 51
ERROR - 2018-11-28 16:46:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 53
ERROR - 2018-11-28 16:46:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 55
ERROR - 2018-11-28 16:46:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 16:46:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:46:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:46:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 51
ERROR - 2018-11-28 16:46:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 53
ERROR - 2018-11-28 16:46:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 55
ERROR - 2018-11-28 16:46:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 16:48:45 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:48:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:48:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:48:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 51
ERROR - 2018-11-28 16:48:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 53
ERROR - 2018-11-28 16:48:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 55
ERROR - 2018-11-28 16:50:27 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:50:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 16:50:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:50:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:50:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 51
ERROR - 2018-11-28 16:50:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 53
ERROR - 2018-11-28 16:50:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 55
ERROR - 2018-11-28 16:51:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:51:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:51:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 51
ERROR - 2018-11-28 16:51:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 53
ERROR - 2018-11-28 16:51:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 55
ERROR - 2018-11-28 16:51:37 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:51:39 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:56:49 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:57:02 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:57:06 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:57:06 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:57:06 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 16:57:06 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 58
ERROR - 2018-11-28 16:57:06 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 60
ERROR - 2018-11-28 16:57:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 16:57:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:57:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:57:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 16:57:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 58
ERROR - 2018-11-28 16:57:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 60
ERROR - 2018-11-28 16:58:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 16:58:17 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:58:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 16:58:20 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 16:58:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 16:59:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:59:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:59:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 16:59:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 58
ERROR - 2018-11-28 16:59:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 60
ERROR - 2018-11-28 16:59:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 16:59:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 16:59:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 16:59:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 58
ERROR - 2018-11-28 16:59:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 60
ERROR - 2018-11-28 16:59:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 16:59:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 17:00:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 17:00:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 17:00:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 17:00:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 58
ERROR - 2018-11-28 17:00:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 60
ERROR - 2018-11-28 17:00:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 17:00:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 17:00:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 17:00:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 58
ERROR - 2018-11-28 17:00:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 60
ERROR - 2018-11-28 17:01:57 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:01:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:02:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 17:02:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 17:02:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 17:02:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 58
ERROR - 2018-11-28 17:02:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 60
ERROR - 2018-11-28 17:02:36 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:02:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:03 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:07 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:07 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:08 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:10 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:11 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:12 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:13 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:13 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:13 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:13 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:13 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:14 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:14 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:14 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:15 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:15 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:15 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:15 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:16 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:16 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:16 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:17 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:17 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:18 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:18 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:19 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:19 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:20 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:20 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:21 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:21 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:22 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:23 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:23 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:23 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:23 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:24 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:24 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:24 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:25 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:44 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 25
ERROR - 2018-11-28 17:03:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:03:57 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:03:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:04:00 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:04:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:05:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:05:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-28 17:05:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-28 17:05:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-28 17:05:30 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 17:05:30 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-28 17:06:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 17:06:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 17:06:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 17:06:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 63
ERROR - 2018-11-28 17:06:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 70
ERROR - 2018-11-28 17:06:54 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:07:06 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:07:25 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:07:32 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:07:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:09:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 33
ERROR - 2018-11-28 17:10:08 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 33
ERROR - 2018-11-28 17:10:18 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:20 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:20 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:21 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:21 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:22 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:22 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:22 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:23 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:25 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:26 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:27 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:10:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:10:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 34
ERROR - 2018-11-28 17:10:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-28 17:10:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 56
ERROR - 2018-11-28 17:10:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 63
ERROR - 2018-11-28 17:10:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/login.php 70
ERROR - 2018-11-28 17:11:10 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:11:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:12:05 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:12:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:13:09 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:13:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:14:45 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:14:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:14:48 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:14:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:15:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 33
ERROR - 2018-11-28 17:15:10 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:15:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:15:12 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:15:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:15:13 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:15:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:15:16 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:15:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:15:18 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:15:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:15:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 17:15:42 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:15:49 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:15:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:15:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-28 17:16:24 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:16:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:16:36 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:16:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:18:03 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:18:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:20:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 33
ERROR - 2018-11-28 17:20:32 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:20:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:22:03 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:22:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:22:50 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:22:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:23:37 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:23:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:24:17 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:24:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:24:41 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:24:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:25:24 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:25:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:25:28 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:25:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:25:33 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:25:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:25:37 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:25:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:26:16 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:26:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:27:26 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:27:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:27:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:27:50 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/income_report.php 26
ERROR - 2018-11-28 17:28:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-28 17:29:06 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 33
ERROR - 2018-11-28 17:29:06 --> Severity: Error --> Cannot break/continue 1 level /var/www/travel_app/application/controllers/Welcome.php 43
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:29:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:29:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:29:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 33
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/income_report.php 86
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/income_report.php 88
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/income_report.php 89
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:29:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:29:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:30:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:30:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:30:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:30:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-28 17:31:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:31:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-28 17:33:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 33
ERROR - 2018-11-28 17:39:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
