<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-27 00:00:24 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:00:24 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:00:24 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:00:25 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:01:06 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:01:06 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:01:06 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:01:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:01:10 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:01:10 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:01:10 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:01:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:03:20 --> Severity: error --> Exception: Cannot use object of type mysqli as array C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-27 00:04:40 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:04:40 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:04:40 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:04:40 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:06:00 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:00 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:00 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:00 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:00 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:00 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:06:22 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ']' C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 56
ERROR - 2020-05-27 00:06:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:06:34 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:07:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:07:02 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:07:02 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:07:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:07:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:07:58 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:07:58 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 58
ERROR - 2020-05-27 00:07:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:08:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-27 00:08:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-27 00:08:54 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-27 00:08:54 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-27 00:08:54 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-27 00:08:54 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-27 00:08:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:10:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-27 00:10:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-27 00:10:05 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-27 00:10:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:10:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:10:58 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:13:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:13:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:14:41 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 00:15:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:32:26 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-27 12:32:26 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-27 12:32:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-27 12:32:26 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-27 12:32:26 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-27 12:32:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-27 12:32:26 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-27 12:32:26 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-27 12:32:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-27 12:32:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:32:34 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:35:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:35:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:39:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:40:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:43:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:44:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:44:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:44:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:44:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 12:44:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:03:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:03:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:04:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:04:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:06:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:09:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:14:05 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:42:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 13:42:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:09:19 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:17:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:17:38 --> 404 Page Not Found: Assets/lib
ERROR - 2020-05-27 14:18:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:20:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:21:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:22:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:22:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:23:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:24:31 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:29:05 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:34:41 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:40:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:41:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:59:44 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:59:47 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 14:59:58 --> 404 Page Not Found: Assets/lib
ERROR - 2020-05-27 15:00:17 --> 404 Page Not Found: Assets/lib
ERROR - 2020-05-27 15:00:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 15:02:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 15:02:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 15:03:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 15:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 15:05:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 15:05:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-27 15:05:25 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `proprietor` (`name`, `address`, `email`, `adminEmail`) VALUES (NULL, NULL, NULL, NULL)
ERROR - 2020-05-27 15:35:44 --> 404 Page Not Found: Assets/img
