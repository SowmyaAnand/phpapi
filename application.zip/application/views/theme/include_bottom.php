
  <script src="<?php echo base_url();?>assets/lib/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
 <script class="include" type="text/javascript" src="<?php echo base_url();?>assets/lib/jquery.dcjqaccordion.2.7.js"></script>
  <!--common script for all pages-->
  <script src="<?php echo base_url(); ?>assets/lib/jquery.scrollTo.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url(); ?>assets/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>assets/lib/common-scripts.js" type="text/javascript"></script>
  <!--script for this page-->

<script type="text/javascript" language="javascript" src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo base_url();?>assets/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo base_url();?>assets/js/dataTables.fixedHeader.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo base_url();?>assets/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo base_url();?>assets/js/responsive.bootstrap.min.js"></script>

<!--common script for all pages-->
