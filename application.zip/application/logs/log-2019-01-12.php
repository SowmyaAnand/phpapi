<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-12 10:05:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 10:07:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2019-01-12 10:08:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 10:08:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 10:46:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 10:48:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 10:53:47 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/view_income_types.php 43
ERROR - 2019-01-12 10:54:04 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/view_income_types.php 43
ERROR - 2019-01-12 10:54:26 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/view_income_types.php 43
ERROR - 2019-01-12 11:17:31 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:17:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 11:18:10 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:18:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 11:20:57 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::last_aquery() /var/www/travel_app/application/models/Booking_model.php 234
ERROR - 2019-01-12 11:21:17 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::last_aquery() /var/www/travel_app/application/models/Booking_model.php 234
ERROR - 2019-01-12 11:21:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:21:26 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::last_aquery() /var/www/travel_app/application/models/Booking_model.php 234
ERROR - 2019-01-12 11:26:17 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:26:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 11:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 11:32:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-12 11:32:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-12 11:32:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2019-01-12 11:32:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2019-01-12 11:32:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-12 11:32:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 11:32:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 11:32:45 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:32:51 --> Severity: Notice --> Undefined index: airline_name /var/www/travel_app/application/views/user/advance_modal.php 29
ERROR - 2019-01-12 11:32:51 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 33
ERROR - 2019-01-12 11:32:51 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 39
ERROR - 2019-01-12 11:32:51 --> Severity: Notice --> Undefined index: airline_name /var/www/travel_app/application/views/user/advance_modal.php 29
ERROR - 2019-01-12 11:32:51 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 33
ERROR - 2019-01-12 11:32:51 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 39
ERROR - 2019-01-12 11:35:01 --> Severity: Notice --> Undefined index: airline_name /var/www/travel_app/application/views/user/advance_modal.php 29
ERROR - 2019-01-12 11:35:01 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 33
ERROR - 2019-01-12 11:35:01 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 39
ERROR - 2019-01-12 11:35:01 --> Severity: Notice --> Undefined index: airline_name /var/www/travel_app/application/views/user/advance_modal.php 29
ERROR - 2019-01-12 11:35:01 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 33
ERROR - 2019-01-12 11:35:01 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 39
ERROR - 2019-01-12 11:35:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 11:36:17 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:36:19 --> Severity: Notice --> Undefined index: airline_name /var/www/travel_app/application/views/user/advance_modal.php 29
ERROR - 2019-01-12 11:36:19 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 33
ERROR - 2019-01-12 11:36:19 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 39
ERROR - 2019-01-12 11:36:19 --> Severity: Notice --> Undefined index: airline_name /var/www/travel_app/application/views/user/advance_modal.php 29
ERROR - 2019-01-12 11:36:19 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 33
ERROR - 2019-01-12 11:36:19 --> Severity: Notice --> Undefined index: totAdvance /var/www/travel_app/application/views/user/advance_modal.php 39
ERROR - 2019-01-12 11:38:55 --> Severity: Notice --> Undefined variable: advancesList /var/www/travel_app/application/views/user/advance_modal.php 21
ERROR - 2019-01-12 11:38:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 21
ERROR - 2019-01-12 11:38:55 --> Severity: Notice --> Undefined variable: advancesList /var/www/travel_app/application/views/user/advance_modal.php 38
ERROR - 2019-01-12 11:42:04 --> Query error: Unknown column 'companyName' in 'where clause' - Invalid query: SELECT *
FROM `travel_booking`
WHERE `companyName` = 'UnReg User'
ERROR - 2019-01-12 11:42:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2019-01-12 11:42:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 188
ERROR - 2019-01-12 11:42:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 11:42:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 11:42:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-12 11:43:18 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2019-01-12 11:43:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2019-01-12 11:43:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 188
ERROR - 2019-01-12 11:43:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 11:43:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 11:43:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-12 11:44:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 11:44:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 11:44:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-12 11:44:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 11:44:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 11:44:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-12 11:44:49 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:45:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 11:46:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:49:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 11:49:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 11:49:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-12 11:49:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 11:49:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 11:49:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 11:49:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-12 11:53:48 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:54:09 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:54:57 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:54:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 11:56:03 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 309
ERROR - 2019-01-12 11:56:33 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:57:34 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 210
ERROR - 2019-01-12 11:57:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 11:57:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 11:57:49 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:58:11 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:58:16 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:58:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 11:59:34 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 11:59:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 12:00:07 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 12:01:01 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 12:01:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 12:01:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 12:02:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-12 12:02:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-12 12:02:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-12 12:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2019-01-12 12:03:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2019-01-12 12:08:51 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 12:08:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 12:09:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 12:14:24 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 12:14:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 12:15:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 12:15:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 12:16:46 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 12:16:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 12:29:08 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) /var/www/travel_app/application/models/Booking_model.php 354
ERROR - 2019-01-12 12:40:36 --> Severity: Parsing Error --> syntax error, unexpected 'unset' (T_UNSET) /var/www/travel_app/application/controllers/Banking.php 73
ERROR - 2019-01-12 12:46:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'totAmount' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'label' /var/www/travel_app/application/views/user/trial_balance.php 91
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 92
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 93
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'totAmount' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'label' /var/www/travel_app/application/views/user/trial_balance.php 91
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 92
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 93
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'totAmount' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'label' /var/www/travel_app/application/views/user/trial_balance.php 91
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 92
ERROR - 2019-01-12 12:46:54 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 93
ERROR - 2019-01-12 12:50:51 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/models/Booking_model.php 364
ERROR - 2019-01-12 12:50:51 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/models/Booking_model.php 366
ERROR - 2019-01-12 12:51:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/models/Booking_model.php 364
ERROR - 2019-01-12 12:51:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/models/Booking_model.php 366
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'totAmount' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'label' /var/www/travel_app/application/views/user/trial_balance.php 91
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 92
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 93
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'totAmount' /var/www/travel_app/application/views/user/trial_balance.php 86
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'label' /var/www/travel_app/application/views/user/trial_balance.php 91
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 92
ERROR - 2019-01-12 12:59:00 --> Severity: Warning --> Illegal string offset 'type' /var/www/travel_app/application/views/user/trial_balance.php 93
ERROR - 2019-01-12 13:02:09 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 13:02:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 13:02:09 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 13:02:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 14:08:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 14:09:30 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 14:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 14:09:30 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 14:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 14:15:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 14:17:46 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 14:22:23 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 14:22:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 14:22:23 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 14:22:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 14:40:01 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 14:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 14:42:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2019-01-12 14:42:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2019-01-12 14:42:54 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 14:42:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-12 14:42:55 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 14:42:55 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 14:43:01 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 14:43:06 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 14:43:11 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:01:41 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:01:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:01:41 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:01:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:11:56 --> Severity: Warning --> Missing argument 1 for Admin_model::get_companies(), called in /var/www/travel_app/application/views/admin/add_user.php on line 56 and defined /var/www/travel_app/application/models/Admin_model.php 369
ERROR - 2019-01-12 15:12:24 --> Severity: Warning --> Missing argument 1 for Admin_model::get_companies(), called in /var/www/travel_app/application/views/admin/add_user.php on line 50 and defined /var/www/travel_app/application/models/Admin_model.php 369
ERROR - 2019-01-12 15:14:55 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/models/Booking_model.php 379
ERROR - 2019-01-12 15:15:38 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/models/Booking_model.php 379
ERROR - 2019-01-12 15:20:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2019-01-12 15:20:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2019-01-12 15:21:39 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/views/admin/add_user.php 59
ERROR - 2019-01-12 15:22:44 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:22:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:22:44 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:22:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:25:57 --> 404 Page Not Found: Booking/index.html
ERROR - 2019-01-12 15:26:36 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:26:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:26:36 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:26:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:29:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-12 15:29:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-12 15:32:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:32:52 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:33:17 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:33:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:33:52 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:33:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:33:52 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:33:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:35:07 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:35:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:35:22 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:35:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:35:45 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:35:50 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:35:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:35:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-12 15:35:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 213
ERROR - 2019-01-12 15:37:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-12 15:37:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-12 15:37:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-12 15:37:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-12 15:39:08 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:39:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:39:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:39:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:39:12 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:39:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:39:12 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:39:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:43:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:43:18 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:43:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:43:18 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:43:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:43:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:44:09 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:47:05 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:47:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:47:05 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:47:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:47:06 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:47:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:47:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:47:15 --> 404 Page Not Found: Admin/calendar.html
ERROR - 2019-01-12 15:47:18 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:47:18 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:47:19 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:47:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:47:21 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:47:21 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:47:22 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:47:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:47:25 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:47:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:48:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:48:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:48:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:48:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:48:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:48:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:49:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:49:36 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:49:39 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:49:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:49:45 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:49:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:07 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:51:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:51:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:12 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:51:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:51:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:15 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:21 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:51:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:31 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:34 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:47 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:51:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-12 15:54:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-12 15:54:06 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:54:06 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2019-01-12 15:54:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:54:25 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-12 15:54:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-12 15:55:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-12 15:56:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
