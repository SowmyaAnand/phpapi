<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-28 16:17:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\assignment\application\controllers\Welcome.php 20
ERROR - 2020-03-28 16:17:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\assignment\application\controllers\Welcome.php 20
ERROR - 2020-03-28 16:21:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\assignment\application\controllers\Welcome.php 20
ERROR - 2020-03-28 16:21:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\assignment\application\controllers\Welcome.php 20
ERROR - 2020-03-28 16:24:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\assignment\application\controllers\Welcome.php 20
ERROR - 2020-03-28 16:47:34 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 16:50:14 --> 404 Page Not Found: Admin/login
ERROR - 2020-03-28 16:58:00 --> Severity: Compile Error --> Multiple access type modifiers are not allowed C:\xampp\htdocs\assignment\application\controllers\Admin.php 26
ERROR - 2020-03-28 16:59:24 --> 404 Page Not Found: User/polling
ERROR - 2020-03-28 17:00:49 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:00 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:03 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:04 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:05 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:06 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:08 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:10 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:30 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 17:01:32 --> 404 Page Not Found: Assets/lib
ERROR - 2020-03-28 18:48:32 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-03-28 18:48:32 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-03-28 18:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-03-28 18:48:32 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-03-28 18:48:32 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-03-28 18:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-03-28 18:48:32 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-03-28 18:48:32 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-03-28 18:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-03-28 18:48:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-28 19:05:15 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-03-28 19:05:15 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-03-28 19:05:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-03-28 19:05:15 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-03-28 19:05:15 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-03-28 19:05:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-03-28 19:05:15 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-03-28 19:05:15 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-03-28 19:05:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-03-28 19:05:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-28 19:05:28 --> Severity: Notice --> Undefined variable: company_image C:\xampp\htdocs\assignment\application\views\admin\profile.php 51
ERROR - 2020-03-28 19:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\profile.php 51
ERROR - 2020-03-28 19:05:28 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\profile.php 94
ERROR - 2020-03-28 19:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\profile.php 94
ERROR - 2020-03-28 19:05:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-28 19:14:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-28 19:14:34 --> 404 Page Not Found: Assets/img
