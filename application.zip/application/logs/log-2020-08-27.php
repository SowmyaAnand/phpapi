<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-27 02:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 21
ERROR - 2020-08-27 13:36:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 21
ERROR - 2020-08-27 19:22:28 --> 404 Page Not Found: Uploads/items
ERROR - 2020-08-27 19:25:37 --> 404 Page Not Found: Uploads/items
ERROR - 2020-08-27 19:26:03 --> 404 Page Not Found: Uploads/items
ERROR - 2020-08-27 19:31:17 --> 404 Page Not Found: Uploads/items
ERROR - 2020-08-27 20:55:53 --> 404 Page Not Found: Api/uploads
