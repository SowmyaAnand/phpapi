<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-01 17:07:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 17:07:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 17:07:19 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 17:07:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 18:01:44 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 18:01:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 18:01:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 18:01:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 18:02:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 18:02:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-01 18:02:29 --> 404 Page Not Found: Assets/img
