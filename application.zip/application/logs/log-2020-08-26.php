<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-26 06:19:43 --> 404 Page Not Found: Api/lists
ERROR - 2020-08-26 06:25:38 --> 404 Page Not Found: Api/lisCategory
