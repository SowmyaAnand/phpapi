<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-20 09:24:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 92
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-20 09:38:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-20 10:01:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-20 10:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-20 11:43:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 11:43:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:03:50 --> Severity: Error --> Call to undefined method Booking_model::isCompanyExist() /var/www/travel_app/application/controllers/Booking.php 183
ERROR - 2018-12-20 12:04:41 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/models/Booking_model.php 41
ERROR - 2018-12-20 12:04:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:04:46 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/models/Booking_model.php 41
ERROR - 2018-12-20 12:04:50 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/models/Booking_model.php 41
ERROR - 2018-12-20 12:05:24 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/models/Booking_model.php 61
ERROR - 2018-12-20 12:05:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:05:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:06:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:14:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:20:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:21:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-20 12:28:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:31:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-20 12:31:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-20 12:35:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 12:35:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-20 12:35:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-20 12:48:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 13:00:08 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-20 13:00:08 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 179
ERROR - 2018-12-20 13:00:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) where exp.`expenseDate` >= '2018-12-20' and exp.`expenseDate` <='2018-12-20' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-20 13:00:18 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-20 13:00:18 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 179
ERROR - 2018-12-20 13:00:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) where exp.`expenseDate` >= '2018-12-20' and exp.`expenseDate` <='2018-12-20' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-20 13:00:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 13:05:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 14:11:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-20 14:11:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-20 14:11:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-20 14:20:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-20 14:37:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-20 14:38:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 15:57:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and date_format(`createdAt`,"%Y-%m-%d") >= "2018-12-01" AND date_format(`created' at line 1 - Invalid query: SELECT SUM(priceCash) as totcount,date_format(createdAt,"%Y-%m-%d") as createdAt FROM `travel_booking` WHERE companyId = and date_format(`createdAt`,"%Y-%m-%d") >= "2018-12-01" AND date_format(`createdAt`,"%Y-%m-%d") <= "2019-01-02" group by date_format(`createdAt`,"%Y-%m-%d")
ERROR - 2018-12-20 15:57:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and date_format(`createdAt`,"%Y-%m-%d") >= "2018-12-01" AND date_format(`created' at line 1 - Invalid query: SELECT SUM(priceCash) as totcount,date_format(createdAt,"%Y-%m-%d") as createdAt FROM `travel_booking` WHERE companyId = and date_format(`createdAt`,"%Y-%m-%d") >= "2018-12-01" AND date_format(`createdAt`,"%Y-%m-%d") <= "2019-01-02" group by date_format(`createdAt`,"%Y-%m-%d")
ERROR - 2018-12-20 16:42:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-20 16:56:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 17:00:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 17:00:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 17:02:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 17:03:07 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-20 17:38:30 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-20 17:39:04 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-20 17:40:51 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-20 17:49:01 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-20 17:49:01 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-20 17:49:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-20 17:49:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-20 17:49:12 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/travel_app/application/views/user/edit_income.php 122
ERROR - 2018-12-20 17:51:38 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-20 17:52:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-20 17:52:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-20 17:52:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-20 21:03:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
