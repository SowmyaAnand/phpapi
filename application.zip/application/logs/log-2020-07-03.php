<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-03 00:25:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 00:26:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 00:41:05 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 01:23:20 --> 404 Page Not Found: Admin/delete_questionnaire
ERROR - 2020-07-03 01:26:50 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 01:27:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 01:27:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 01:27:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 01:29:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 01:56:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 01:56:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 01:58:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 12:18:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 12:19:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 12:19:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 12:20:31 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 12:31:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 12:31:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 13:03:59 --> 404 Page Not Found: Admin/delete_questionnaire
ERROR - 2020-07-03 13:04:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 13:27:41 --> 404 Page Not Found: Admin/edit_questionnaire
ERROR - 2020-07-03 13:37:30 --> Severity: Notice --> Undefined index: questionnaire C:\xampp\htdocs\ipoll\application\views\admin\edit_questionnaire.php 28
ERROR - 2020-07-03 13:37:30 --> Severity: Notice --> Undefined index: questionnaire C:\xampp\htdocs\ipoll\application\views\admin\edit_questionnaire.php 33
ERROR - 2020-07-03 13:37:30 --> Severity: Notice --> Undefined index: questionnaire C:\xampp\htdocs\ipoll\application\views\admin\edit_questionnaire.php 34
ERROR - 2020-07-03 13:37:31 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 13:38:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 13:39:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 13:39:44 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 13:40:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 13:40:13 --> Severity: error --> Exception: Too few arguments to function Admin::edit_questionnaire(), 0 passed in C:\xampp\htdocs\ipoll\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\ipoll\application\controllers\Admin.php 273
ERROR - 2020-07-03 13:42:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 13:48:53 --> 404 Page Not Found: Admin/delete_questionnaire
ERROR - 2020-07-03 14:01:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:01:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:02:16 --> 404 Page Not Found: Admin/delete_questionnaire
ERROR - 2020-07-03 14:05:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:07:47 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:07:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:11:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:26:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:31:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:31:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:32:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:32:19 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:32:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:32:34 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:32:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:42:14 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:42:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:42:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:42:25 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:42:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:42:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:42:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:46:34 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:50:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 14:53:49 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:00:40 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:01:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:01:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:01:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:01:50 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:02:05 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:04:16 --> Severity: Notice --> Undefined variable: total_questionnaire C:\xampp\htdocs\ipoll\application\views\admin\dashboard.php 21
ERROR - 2020-07-03 15:04:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:04:59 --> Severity: Notice --> Undefined variable: total_questionnaire C:\xampp\htdocs\ipoll\application\views\admin\dashboard.php 21
ERROR - 2020-07-03 15:05:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:06:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:07:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:11:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:11:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:12:05 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:12:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:12:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:16:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:18:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:18:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:20:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:39:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:48:25 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:49:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:49:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 15:49:48 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:15:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:15:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:18:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:18:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:19:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:19:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:19:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:19:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:19:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:20:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:20:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:20:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:21:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:21:47 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:21:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:21:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:23:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:23:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:25:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:25:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:25:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:26:41 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:26:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:26:48 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 17:54:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'as totIncome FROM `questions` as q left join questionnaire as qr on(qr.qrId = q.' at line 1 - Invalid query: SELECT q.* as totIncome FROM `questions` as q left join questionnaire as qr on(qr.qrId = q.qrId) WHERE qr.status = 1 ORDER BY qr.`qrId` DESC
ERROR - 2020-07-03 20:40:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 20:51:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: qrId C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 87
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 91
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 94
ERROR - 2020-07-03 20:51:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 20:55:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\views\admin\view_polls.php 93
ERROR - 2020-07-03 20:57:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 20:57:47 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 20:58:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 20:59:14 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:04:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:13:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:14:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:14:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:15:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:15:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:15:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:16:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:17:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:22:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:30:40 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:39:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:39:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '1' ORDER BY tp.`createdAt` DESC' at line 1 - Invalid query: SELECT q.*,qr.status,qr.questionnaire,tp.* FROM `questions` as q left join questionnaire as qr on(qr.qrId = q.qrId) left join  testpoll  as tp on(tp.qId = q.qId) where qr.`qrId`== '1' ORDER BY tp.`createdAt` DESC
ERROR - 2020-07-03 21:40:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:44:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:44:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:44:31 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:44:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:46:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:47:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:47:44 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:48:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:48:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:48:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-03 21:50:58 --> 404 Page Not Found: Assets/img
