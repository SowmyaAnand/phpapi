<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-24 00:01:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 514
ERROR - 2020-08-24 00:01:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 518
ERROR - 2020-08-24 00:01:44 --> Severity: Notice --> Undefined variable: array_of_eventsubs /home/dailyest/public_html/dailyestore/application/controllers/Api.php 527
ERROR - 2020-08-24 00:01:44 --> Severity: Notice --> Undefined variable: array_of_eventitem /home/dailyest/public_html/dailyestore/application/controllers/Api.php 528
