<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-12 20:53:54 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context C:\xampp\htdocs\ipoll\application\views\questionnaire.php 80
ERROR - 2020-07-12 21:10:10 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\ipoll\application\controllers\Welcome.php 46
ERROR - 2020-07-12 21:19:36 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\models\First_model.php 16
ERROR - 2020-07-12 21:19:36 --> Query error: Column 'options' cannot be null - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('1', NULL)
ERROR - 2020-07-12 21:20:53 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\models\First_model.php 16
ERROR - 2020-07-12 21:20:53 --> Query error: Column 'options' cannot be null - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('1', NULL)
ERROR - 2020-07-12 21:22:11 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-12 21:25:52 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\ipoll\application\models\First_model.php 20
ERROR - 2020-07-12 21:25:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\models\First_model.php 21
ERROR - 2020-07-12 21:36:34 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-12 21:43:49 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-12 21:45:20 --> 404 Page Not Found: Assets/lib
