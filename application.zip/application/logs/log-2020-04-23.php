<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-23 13:43:00 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-04-23 13:43:00 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-04-23 13:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-04-23 13:43:00 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-04-23 13:43:00 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-04-23 13:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-04-23 13:43:00 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-04-23 13:43:00 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-04-23 13:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-04-23 13:43:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-04-23 13:44:31 --> 404 Page Not Found: Assets/img
ERROR - 2020-04-23 13:44:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 331
ERROR - 2020-04-23 13:44:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-04-23 13:44:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 331
ERROR - 2020-04-23 13:44:40 --> 404 Page Not Found: Assets/img
ERROR - 2020-04-23 13:44:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 331
ERROR - 2020-04-23 13:44:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-04-23 13:44:46 --> 404 Page Not Found: Assets/img
