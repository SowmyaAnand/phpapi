<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-30 08:56:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 08:57:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 08:57:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 08:58:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 09:03:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 09:03:43 --> 404 Page Not Found: Daybook/index.html
ERROR - 2018-11-30 09:09:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 09:15:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 09:19:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 09:19:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 09:20:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:20:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:21:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:21:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:22:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:22:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:23:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:23:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:24:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:24:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:24:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:25:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined variable: count /var/www/travel_app/application/views/user/transaction_report.php 135
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:25:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:25:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 09:26:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:26:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 09:26:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:26:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:26:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:26:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:43 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:43 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:43 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:27:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:27:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:28:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:28:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:29:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:29:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:29:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 09:29:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:29:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:31:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:31:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:31:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:31:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:32:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:32:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:32:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:32:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:34:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:34:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/application/controllers/Daybook.php:272) /var/www/travel_app/system/core/Common.php 570
ERROR - 2018-11-30 09:34:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-30 09:35:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:35:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-30 09:40:36 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) /var/www/travel_app/application/views/user/income_report.php 119
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:40:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:40:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:41:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:41:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 09:43:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:43:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 09:43:30 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 09:43:30 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:08:00 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/models/Daybook_model.php 82
ERROR - 2018-11-30 10:08:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:08:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:08:41 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/models/Daybook_model.php 80
ERROR - 2018-11-30 10:08:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:08:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:09:56 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/models/Daybook_model.php 80
ERROR - 2018-11-30 10:09:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:09:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:10:02 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/models/Daybook_model.php 80
ERROR - 2018-11-30 10:10:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:10:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:10:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:10:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:10:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:13:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:13:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:13:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 108
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 116
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 121
ERROR - 2018-11-30 10:14:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:14:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:15:42 --> Severity: Notice --> Undefined index: cid /var/www/travel_app/application/controllers/Daybook.php 147
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:15:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 10:15:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 10:16:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 10:16:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 10:32:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 10:32:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 11:13:50 --> 404 Page Not Found: Daybook/index.html
ERROR - 2018-11-30 11:38:36 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/views/user/daily_transactions.php 94
ERROR - 2018-11-30 11:39:07 --> Severity: Error --> Call to undefined function shortodate() /var/www/travel_app/application/views/user/daily_transactions.php 94
ERROR - 2018-11-30 11:54:56 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/daily_transactions.php 121
ERROR - 2018-11-30 11:55:12 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ';' /var/www/travel_app/application/views/user/daily_transactions.php 121
ERROR - 2018-11-30 11:55:31 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/user/daily_transactions.php 121
ERROR - 2018-11-30 11:55:31 --> Severity: Notice --> Undefined variable: income /var/www/travel_app/application/views/user/daily_transactions.php 121
ERROR - 2018-11-30 11:55:44 --> Severity: Notice --> Undefined variable: income /var/www/travel_app/application/views/user/daily_transactions.php 121
ERROR - 2018-11-30 11:56:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 11:56:20 --> Severity: Notice --> Undefined variable: income1 /var/www/travel_app/application/views/user/daily_transactions.php 121
ERROR - 2018-11-30 11:58:21 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/views/user/daily_transactions.php 121
ERROR - 2018-11-30 12:04:59 --> Severity: Notice --> Undefined variable: expensescash /var/www/travel_app/application/views/user/daily_transactions.php 126
ERROR - 2018-11-30 12:04:59 --> Severity: Notice --> Undefined variable: expensescredit /var/www/travel_app/application/views/user/daily_transactions.php 127
ERROR - 2018-11-30 12:06:17 --> Severity: Notice --> Undefined variable: expensescash /var/www/travel_app/application/views/user/daily_transactions.php 126
ERROR - 2018-11-30 12:06:17 --> Severity: Notice --> Undefined variable: expensescredit /var/www/travel_app/application/views/user/daily_transactions.php 127
ERROR - 2018-11-30 12:29:19 --> Severity: Compile Error --> Cannot redeclare Daybook_model::daily_expense_per_date_tot() /var/www/travel_app/application/models/Daybook_model.php 114
ERROR - 2018-11-30 12:29:52 --> Severity: Notice --> Undefined index: expenses_tot /var/www/travel_app/application/controllers/Daybook.php 326
ERROR - 2018-11-30 12:30:44 --> Severity: Notice --> Undefined index: expenses_tot /var/www/travel_app/application/controllers/Daybook.php 327
ERROR - 2018-11-30 12:31:10 --> Severity: Notice --> Undefined index: expenses_tot /var/www/travel_app/application/controllers/Daybook.php 327
ERROR - 2018-11-30 12:32:02 --> Severity: Notice --> Undefined variable: expenses_t /var/www/travel_app/application/controllers/Daybook.php 327
ERROR - 2018-11-30 12:32:02 --> Severity: Notice --> Undefined variable: expenses_tot /var/www/travel_app/application/views/user/daily_transactions.php 106
ERROR - 2018-11-30 12:32:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 12:32:28 --> Severity: Notice --> Undefined index: expenses_tot /var/www/travel_app/application/controllers/Daybook.php 327
ERROR - 2018-11-30 12:33:38 --> Severity: Notice --> Undefined index: expenses_tot /var/www/travel_app/application/controllers/Daybook.php 328
ERROR - 2018-11-30 12:33:57 --> Severity: Notice --> Undefined variable: expenses_tot /var/www/travel_app/application/views/user/daily_transactions.php 106
ERROR - 2018-11-30 12:35:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 12:49:54 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 113
ERROR - 2018-11-30 13:02:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 13:06:25 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/views/user/daily_transactions.php 141
ERROR - 2018-11-30 14:11:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:14:55 --> Severity: Notice --> Undefined variable: expense_type /var/www/travel_app/application/views/user/income.php 110
ERROR - 2018-11-30 14:14:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/income.php 110
ERROR - 2018-11-30 14:19:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:21:23 --> Query error: Unknown column 'expenseType' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `expenseType`, `cash_from`, `phone`, `credit`, `payment_type`, `description`) VALUES ('1', '101', 'IN421566455', '1', 'Ambika', '9865321254', '250', 'cash', 'decsptn1')
ERROR - 2018-11-30 14:23:29 --> Query error: Unknown column 'expenseType' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `expenseType`, `cash_from`, `phone`, `credit`, `payment_type`, `description`) VALUES ('1', '101', 'IN421566455', '1', 'Ambika', '9865321254', '250', 'cash', 'decsptn1')
ERROR - 2018-11-30 14:24:43 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 14:24:43 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 14:24:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 14:24:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 14:33:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:33:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-30 14:48:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 14:48:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 14:48:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 14:48:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 14:49:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 14:49:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 14:49:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 14:49:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 143
ERROR - 2018-11-30 14:49:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:49:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:49:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:50:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:50:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:50:07 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-30 14:50:07 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-30 14:50:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:50:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:50:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:50:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:50:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:50:57 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-30 14:50:58 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-30 14:51:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:51:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:51:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:52:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:52:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:52:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:52:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:52:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:53:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:53:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 110
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 118
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 123
ERROR - 2018-11-30 14:53:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:53:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 145
ERROR - 2018-11-30 14:54:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:54:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:54:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:55:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:55:46 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:55:46 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:55:46 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:55:46 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:55:46 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:55:46 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:55:46 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:55:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 128
ERROR - 2018-11-30 14:55:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 128
ERROR - 2018-11-30 14:56:31 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:56:31 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:56:31 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:56:31 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:56:31 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:56:31 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:56:31 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:56:31 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 14:56:31 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 14:57:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 14:57:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 14:57:43 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 14:57:43 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 14:57:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:49 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 14:57:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 14:57:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 14:58:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:58:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:59:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 14:59:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 14:59:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:00:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:00:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:00:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:00:58 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:00:58 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:00:58 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:00:58 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:00:58 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:00:58 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:00:58 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:00:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 15:00:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 15:02:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:02:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:02:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:02:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:02:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:02:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:02:06 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:02:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 15:02:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 177
ERROR - 2018-11-30 15:03:10 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:03:10 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:03:10 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:03:10 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:03:10 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:03:10 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:03:10 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 109
ERROR - 2018-11-30 15:03:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:03:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:03:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:03:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:04:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:04:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:04:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:04:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:04:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:04:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:06:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:07:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:07:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:08:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:09:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:09:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:09:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:10:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:10:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 173
ERROR - 2018-11-30 15:10:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 173
ERROR - 2018-11-30 15:10:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:10:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 173
ERROR - 2018-11-30 15:10:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 173
ERROR - 2018-11-30 15:10:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:10:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:11:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:11:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:11:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:12:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:12:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:12:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:12:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:14:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:15:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:15:13 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/total_booking_graph.php 146
ERROR - 2018-11-30 15:15:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:16:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:16:16 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/total_booking_graph.php 147
ERROR - 2018-11-30 15:16:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:16:35 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/total_booking_graph.php 147
ERROR - 2018-11-30 15:16:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:16:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:17:18 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/total_booking_graph.php 172
ERROR - 2018-11-30 15:17:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:17:24 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/total_booking_graph.php 172
ERROR - 2018-11-30 15:17:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:17:34 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/total_booking_graph.php 172
ERROR - 2018-11-30 15:17:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:17:57 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/total_booking_graph.php 173
ERROR - 2018-11-30 15:17:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:17:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:18:04 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/total_booking_graph.php 173
ERROR - 2018-11-30 15:18:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:18:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:18:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:18:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:19:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:25:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:27:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:27:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:27:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:28:56 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /var/www/travel_app/application/views/user/daily_transactions.php 118
ERROR - 2018-11-30 15:30:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:30:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:30:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:31:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:32:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:32:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:32:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:32:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:33:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:35:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:35:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:35:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 110
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 118
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 128
ERROR - 2018-11-30 15:36:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:36:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 140
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:38:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 142
ERROR - 2018-11-30 15:38:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 142
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 112
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 120
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 130
ERROR - 2018-11-30 15:39:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 142
ERROR - 2018-11-30 15:39:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 142
ERROR - 2018-11-30 15:39:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:40:13 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:40:13 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:41:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:41:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 179
ERROR - 2018-11-30 15:41:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 15:41:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 15:42:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:42:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:42:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:45:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:45:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:45:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:45:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:45:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:45:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:45:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 15:45:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 15:45:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 15:45:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 15:46:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:46:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:46:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 15:48:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 15:51:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:51:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:52:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:52:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 15:54:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:00:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:03:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:04:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:04:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:05:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:06:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:06:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:21:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:21:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 16:21:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 16:22:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:22:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 16:22:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 16:22:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:23:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 16:23:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 115
ERROR - 2018-11-30 16:24:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:24:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 16:24:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 16:24:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:24:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 16:24:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 16:24:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:25:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:25:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 16:25:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 16:26:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:26:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:27:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:28:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:28:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:28:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:28:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:28:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:28:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:28:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:28:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:28:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:28:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:30:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:30:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:30:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:30:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:31:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:31:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:31:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:32:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:32:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:32:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:32:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:32:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:32:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:32:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:32:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:33:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:33:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:33:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:33:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:34:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:34:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:34:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:34:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:35:03 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:03 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:35:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:35:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:35:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:35:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:35:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:35:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 181
ERROR - 2018-11-30 16:36:13 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:36:13 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:36:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:36:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 175
ERROR - 2018-11-30 16:38:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:38:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:39:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:39:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:41:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 181
ERROR - 2018-11-30 16:41:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 181
ERROR - 2018-11-30 16:41:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-11-30 16:41:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-11-30 16:42:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-11-30 16:42:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-11-30 16:42:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-11-30 16:42:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-11-30 16:43:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:43:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:43:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:43:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:44:01 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:44:01 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:45:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:45:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 183
ERROR - 2018-11-30 16:45:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 177
ERROR - 2018-11-30 16:45:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 177
ERROR - 2018-11-30 16:45:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:47:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:48:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 16:48:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:49:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:49:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 16:49:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 16:49:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 16:49:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 16:49:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:51:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 16:51:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 16:51:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:51:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:52:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:52:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:52:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:52:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:52:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:53:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:54:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:54:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:54:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:55:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:56:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:57:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:58:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:58:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 16:58:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:01:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:02:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:03:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:05:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:05:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:10:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`create' at line 1 - Invalid query: SELECT SUM(priceCash) as totcount,date_format(createdAt,"%Y-%m-%d",) as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`createdAt`,"%Y-%m-%d") >= "2018-11-01" AND date_format(`createdAt`,"%Y-%m-%d") <= "2018-12-08" group by date_format(`createdAt`,"%Y-%m-%d")
ERROR - 2018-11-30 17:10:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`create' at line 1 - Invalid query: SELECT SUM(priceCash) as totcount,date_format(createdAt,"%Y-%m-%d",) as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`createdAt`,"%Y-%m-%d") >= "2018-11-01" AND date_format(`createdAt`,"%Y-%m-%d") <= "2018-12-08" group by date_format(`createdAt`,"%Y-%m-%d")
ERROR - 2018-11-30 17:11:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`create' at line 1 - Invalid query: SELECT SUM(priceCash) as totcount,date_format(createdAt,"%Y-%m-%d",) as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`createdAt`,"%Y-%m-%d") >= "2018-11-01" AND date_format(`createdAt`,"%Y-%m-%d") <= "2018-11-30" group by date_format(`createdAt`,"%Y-%m-%d")
ERROR - 2018-11-30 17:11:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 17:11:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`create' at line 1 - Invalid query: SELECT SUM(priceCash) as totcount,date_format(createdAt,"%Y-%m-%d",) as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`createdAt`,"%Y-%m-%d") >= "2018-11-20" AND date_format(`createdAt`,"%Y-%m-%d") <= "2018-12-08" group by date_format(`createdAt`,"%Y-%m-%d")
ERROR - 2018-11-30 17:12:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 17:12:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`create' at line 1 - Invalid query: SELECT SUM(priceCash) as totcount,date_format(createdAt,"%Y-%m-%d",) as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`createdAt`,"%Y-%m-%d") >= "2018-11-20" AND date_format(`createdAt`,"%Y-%m-%d") <= "2018-12-08" group by date_format(`createdAt`,"%Y-%m-%d")
ERROR - 2018-11-30 17:13:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`create' at line 1 - Invalid query: SELECT SUM(priceCash) as totcount,date_format(createdAt,"%Y-%m-%d",) as createdAt FROM `travel_booking` WHERE companyId=102 and date_format(`createdAt`,"%Y-%m-%d") >= "2018-11-20" AND date_format(`createdAt`,"%Y-%m-%d") <= "2018-12-01" group by date_format(`createdAt`,"%Y-%m-%d")
ERROR - 2018-11-30 17:14:59 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_cash_graph.php 105
ERROR - 2018-11-30 17:15:06 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_cash_graph.php 105
ERROR - 2018-11-30 17:15:22 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_cash_graph.php 105
ERROR - 2018-11-30 17:15:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 17:15:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 17:16:23 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_cash_graph.php 105
ERROR - 2018-11-30 17:16:30 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/views/user/total_cash_graph.php 105
ERROR - 2018-11-30 17:17:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 17:17:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 17:17:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 17:19:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 17:19:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 17:19:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:19:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:21:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 177
ERROR - 2018-11-30 17:21:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 177
ERROR - 2018-11-30 17:21:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 17:21:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-30 17:22:01 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 17:22:01 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 17:22:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 17:22:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 183
ERROR - 2018-11-30 17:29:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:31:06 --> Severity: Notice --> Undefined variable: expensescredit1 /var/www/travel_app/application/views/user/daily_transactions.php 151
ERROR - 2018-11-30 17:31:06 --> Severity: Notice --> Undefined variable: expensescredit1 /var/www/travel_app/application/views/user/daily_transactions.php 157
ERROR - 2018-11-30 17:31:06 --> Severity: Notice --> Undefined variable: expensescredit1 /var/www/travel_app/application/views/user/daily_transactions.php 165
ERROR - 2018-11-30 17:32:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:32:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 177
ERROR - 2018-11-30 17:32:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 177
ERROR - 2018-11-30 17:33:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:38:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:41:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:41:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:42:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:42:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:42:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:50:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:53:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 17:57:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:00:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:01:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:01:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:05:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:05:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:05:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:05:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:05:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:06:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:06:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:06:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:06:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:07:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:08:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:08:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:08:47 --> 404 Page Not Found: Welcome/index.html
ERROR - 2018-11-30 18:08:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:10:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-30 18:11:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 18:11:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 19:22:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 19:22:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 177
ERROR - 2018-11-30 19:22:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 177
ERROR - 2018-11-30 19:33:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:33:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:34:32 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:34:32 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:34:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:34:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:35:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:35:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:35:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:35:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:36:03 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:36:03 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:36:07 --> 404 Page Not Found: Daybook/edit_expense
ERROR - 2018-11-30 19:36:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 19:36:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:36:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 19:53:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 19:58:18 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /var/www/travel_app/application/views/user/edit_expense.php 220
ERROR - 2018-11-30 20:02:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-30 20:02:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 20:02:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 20:05:17 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/edit_expense.php 123
ERROR - 2018-11-30 20:05:17 --> Severity: Notice --> Undefined index: phone /var/www/travel_app/application/views/user/edit_expense.php 130
ERROR - 2018-11-30 20:05:17 --> Severity: Notice --> Undefined index: debit /var/www/travel_app/application/views/user/edit_expense.php 137
ERROR - 2018-11-30 20:05:17 --> Severity: Notice --> Undefined index: bank_name /var/www/travel_app/application/views/user/edit_expense.php 204
ERROR - 2018-11-30 20:05:17 --> Severity: Notice --> Undefined index: chequeno /var/www/travel_app/application/views/user/edit_expense.php 205
ERROR - 2018-11-30 20:05:17 --> Severity: Notice --> Undefined index: dd_date /var/www/travel_app/application/views/user/edit_expense.php 206
ERROR - 2018-11-30 20:05:17 --> Severity: Notice --> Undefined index: description /var/www/travel_app/application/views/user/edit_expense.php 211
ERROR - 2018-11-30 20:15:00 --> Severity: Notice --> Undefined index: phone /var/www/travel_app/application/views/user/edit_expense.php 130
ERROR - 2018-11-30 20:15:00 --> Severity: Notice --> Undefined index: debit /var/www/travel_app/application/views/user/edit_expense.php 137
ERROR - 2018-11-30 20:15:00 --> Severity: Notice --> Undefined index: bank_name /var/www/travel_app/application/views/user/edit_expense.php 204
ERROR - 2018-11-30 20:15:00 --> Severity: Notice --> Undefined index: chequeno /var/www/travel_app/application/views/user/edit_expense.php 205
ERROR - 2018-11-30 20:15:00 --> Severity: Notice --> Undefined index: dd_date /var/www/travel_app/application/views/user/edit_expense.php 206
ERROR - 2018-11-30 20:15:00 --> Severity: Notice --> Undefined index: description /var/www/travel_app/application/views/user/edit_expense.php 211
ERROR - 2018-11-30 20:17:08 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/edit_expense.php 123
ERROR - 2018-11-30 20:17:08 --> Severity: Notice --> Undefined index: phone /var/www/travel_app/application/views/user/edit_expense.php 130
ERROR - 2018-11-30 20:17:08 --> Severity: Notice --> Undefined index: debit /var/www/travel_app/application/views/user/edit_expense.php 137
ERROR - 2018-11-30 20:17:08 --> Severity: Notice --> Undefined index: bank_name /var/www/travel_app/application/views/user/edit_expense.php 204
ERROR - 2018-11-30 20:17:08 --> Severity: Notice --> Undefined index: chequeno /var/www/travel_app/application/views/user/edit_expense.php 205
ERROR - 2018-11-30 20:17:08 --> Severity: Notice --> Undefined index: dd_date /var/www/travel_app/application/views/user/edit_expense.php 206
ERROR - 2018-11-30 20:17:08 --> Severity: Notice --> Undefined index: description /var/www/travel_app/application/views/user/edit_expense.php 211
ERROR - 2018-11-30 20:38:38 --> Severity: Notice --> Undefined index: gender /var/www/travel_app/application/views/user/edit_expense.php 147
ERROR - 2018-11-30 20:38:38 --> Severity: Notice --> Undefined index: gender /var/www/travel_app/application/views/user/edit_expense.php 149
ERROR - 2018-11-30 20:38:38 --> Severity: Notice --> Undefined index: gender /var/www/travel_app/application/views/user/edit_expense.php 150
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:15:09 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 112
ERROR - 2018-11-30 21:27:18 --> Query error: Unknown column 'voucher_no' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `voucher_no`, `incomId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`, `approved_by`) VALUES ('1', '101', 'TN928706703', '18', '61', 'anjali', '2147483647', '1750', 'credit', '', '', '', 'CREDIT', 'User ABC')
ERROR - 2018-11-30 21:28:27 --> Query error: Unknown column 'voucher_no' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `voucher_no`, `incomId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`, `approved_by`) VALUES ('1', '101', 'TN928706703', '18', '61', 'anjali', '2147483647', '1750', 'credit', '', '', '', 'CREDIT', 'User ABC')
ERROR - 2018-11-30 21:32:54 --> Query error: Unknown column 'voucher_no' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `voucher_no`, `incomId`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`, `approved_by`) VALUES ('1', '101', 'TN928706703', '18', '61', 'anjali', '2147483647', '1750', 'credit', '', '', '', 'CREDIT', 'User ABC')
ERROR - 2018-11-30 21:40:18 --> Severity: Notice --> Undefined index: incomIds /var/www/travel_app/application/controllers/Daybook.php 393
ERROR - 2018-11-30 21:40:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 21:40:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 21:45:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-11-30 21:45:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
