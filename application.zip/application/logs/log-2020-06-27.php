<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-27 22:55:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 22:56:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 22:56:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 22:56:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 22:57:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 22:58:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:13:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:13:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:14:25 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:15:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:16:48 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:17:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:17:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:17:36 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:17:50 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:18:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:18:48 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:18:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:29:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:32:35 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\assignment\application\views\admin\edit_question.php 45
ERROR - 2020-06-27 23:32:35 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\assignment\application\views\admin\edit_question.php 45
ERROR - 2020-06-27 23:32:35 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\assignment\application\views\admin\edit_question.php 45
ERROR - 2020-06-27 23:32:35 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\assignment\application\views\admin\edit_question.php 45
ERROR - 2020-06-27 23:32:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:33:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:34:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:34:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:35:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:35:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:36:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:37:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:37:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:38:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:38:44 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:44:34 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:45:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-27 23:45:17 --> 404 Page Not Found: Assets/lib
