<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-23 22:49:59 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::limit() /home/dailyest/public_html/dailyestore/application/models/Api_model.php 13
ERROR - 2020-08-23 22:50:53 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::limit() /home/dailyest/public_html/dailyestore/application/models/Api_model.php 13
ERROR - 2020-08-23 22:52:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 18
ERROR - 2020-08-23 22:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 18
ERROR - 2020-08-23 23:12:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 18
ERROR - 2020-08-23 23:12:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 18
ERROR - 2020-08-23 23:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 18
ERROR - 2020-08-23 23:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 21
ERROR - 2020-08-23 23:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 21
ERROR - 2020-08-23 23:46:33 --> 404 Page Not Found: Api/listAllCategory
ERROR - 2020-08-23 23:56:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 514
ERROR - 2020-08-23 23:56:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 518
ERROR - 2020-08-23 23:56:51 --> Severity: Notice --> Undefined variable: array_of_eventsubs /home/dailyest/public_html/dailyestore/application/controllers/Api.php 527
ERROR - 2020-08-23 23:56:51 --> Severity: Notice --> Undefined variable: array_of_eventitem /home/dailyest/public_html/dailyestore/application/controllers/Api.php 528
ERROR - 2020-08-23 23:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 514
ERROR - 2020-08-23 23:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 518
ERROR - 2020-08-23 23:57:49 --> Severity: Notice --> Undefined variable: array_of_eventsubs /home/dailyest/public_html/dailyestore/application/controllers/Api.php 527
ERROR - 2020-08-23 23:57:49 --> Severity: Notice --> Undefined variable: array_of_eventitem /home/dailyest/public_html/dailyestore/application/controllers/Api.php 528
ERROR - 2020-08-23 23:57:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 514
ERROR - 2020-08-23 23:57:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 518
ERROR - 2020-08-23 23:57:53 --> Severity: Notice --> Undefined variable: array_of_eventsubs /home/dailyest/public_html/dailyestore/application/controllers/Api.php 527
ERROR - 2020-08-23 23:57:53 --> Severity: Notice --> Undefined variable: array_of_eventitem /home/dailyest/public_html/dailyestore/application/controllers/Api.php 528
ERROR - 2020-08-23 23:58:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 513
ERROR - 2020-08-23 23:58:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 517
ERROR - 2020-08-23 23:58:23 --> Severity: Notice --> Undefined variable: array_of_eventsubs /home/dailyest/public_html/dailyestore/application/controllers/Api.php 526
ERROR - 2020-08-23 23:58:23 --> Severity: Notice --> Undefined variable: array_of_eventitem /home/dailyest/public_html/dailyestore/application/controllers/Api.php 527
