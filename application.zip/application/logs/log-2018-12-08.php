<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-08 09:01:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 09:21:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 362
ERROR - 2018-12-08 09:25:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 362
ERROR - 2018-12-08 09:30:32 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 177
ERROR - 2018-12-08 09:31:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 09:31:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 177
ERROR - 2018-12-08 09:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-08 09:33:40 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 42
ERROR - 2018-12-08 09:33:40 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-08 09:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-08 09:33:40 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 94
ERROR - 2018-12-08 09:33:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-08 09:33:50 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 42
ERROR - 2018-12-08 09:33:50 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-08 09:33:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-08 09:33:50 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 94
ERROR - 2018-12-08 09:36:06 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 177
ERROR - 2018-12-08 09:36:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-08 09:36:28 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 42
ERROR - 2018-12-08 09:36:28 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-08 09:36:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 69
ERROR - 2018-12-08 09:36:28 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/accounts_receivable_modal.php 94
ERROR - 2018-12-08 09:37:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accounts_receivable_modal.php 22
ERROR - 2018-12-08 09:38:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 76
ERROR - 2018-12-08 09:38:07 --> Query error: Column 'airline' cannot be null - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `travelTo`, `departureDateTime`, `arrivalDateTime`, `flightNo`, `pnr`, `priceCash`, `priceCredit`, `tax`, `bookingDate`, `paymentType`, `airline`, `airline_cost`, `service_charge`, `companyId`, `createdBy`) VALUES ('abcd', 'passenger2', '1', '2', '2018-12-08 09:37', '2018-12-09 09:37', 'F1', 'pnrK02', '5000', '1000', '1000', '2018-12-08', 2, NULL, '1000', '1000', '102', '2')
ERROR - 2018-12-08 09:39:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 76
ERROR - 2018-12-08 09:39:27 --> Query error: Column 'airline' cannot be null - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `travelTo`, `departureDateTime`, `arrivalDateTime`, `flightNo`, `pnr`, `priceCash`, `priceCredit`, `tax`, `bookingDate`, `paymentType`, `airline`, `airline_cost`, `service_charge`, `companyId`, `createdBy`) VALUES ('abcd', 'passenger2', '1', '2', '2018-12-08 09:39', '2018-12-09 09:37', 'F1', 'pnrK02', '5000', '1000', '1000', '2018-12-08', 2, NULL, '1000', '1000', '102', '2')
ERROR - 2018-12-08 09:40:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 177
ERROR - 2018-12-08 09:40:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 76
ERROR - 2018-12-08 09:40:56 --> Query error: Column 'airline' cannot be null - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `travelTo`, `departureDateTime`, `arrivalDateTime`, `flightNo`, `pnr`, `priceCash`, `priceCredit`, `tax`, `bookingDate`, `paymentType`, `airline`, `airline_cost`, `service_charge`, `companyId`, `createdBy`) VALUES ('abcd', 'passenger2', '1', '2', '2018-12-08 09:40', '2018-12-09 09:37', 'F1', 'pnrK02', '5000', '1000', '1000', '2018-12-08', 2, NULL, '1000', '1000', '102', '2')
ERROR - 2018-12-08 09:41:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 362
ERROR - 2018-12-08 10:14:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-08 10:14:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-08 10:14:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-08 10:14:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-08 10:14:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-08 10:14:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-08 10:14:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-08 10:14:08 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-08 10:14:08 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-08 10:14:08 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-08 10:16:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-08 10:19:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-08 10:20:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-08 10:20:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-08 10:27:02 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/total_booking_graph.php 59
ERROR - 2018-12-08 10:27:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 59
ERROR - 2018-12-08 10:32:36 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) /var/www/travel_app/application/controllers/Banking.php 49
ERROR - 2018-12-08 10:33:03 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) /var/www/travel_app/application/controllers/Banking.php 49
ERROR - 2018-12-08 10:34:05 --> Severity: Parsing Error --> syntax error, unexpected '"> Select Account</option>"' (T_CONSTANT_ENCAPSED_STRING) /var/www/travel_app/application/controllers/Banking.php 49
ERROR - 2018-12-08 10:37:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 10:37:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 10:39:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 10:42:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 10:42:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 10:43:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 10:44:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 10:44:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:26:13 --> Query error: Unknown column 'companyId' in 'where clause' - Invalid query: SELECT sum(amount) as totAirline  FROM `advance_payment` where `date` >= '2018-12-08' and `date` <='2018-12-08' and companyId in (102,103)
ERROR - 2018-12-08 11:26:17 --> Query error: Unknown column 'companyId' in 'where clause' - Invalid query: SELECT sum(amount) as totAirline  FROM `advance_payment` where `date` >= '2018-12-08' and `date` <='2018-12-08' and companyId in (102,103)
ERROR - 2018-12-08 11:37:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 11:37:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:43:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:43:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:43:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:44:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:44:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:44:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:45:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:45:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:45:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:47:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 11:47:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:47:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 11:47:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:47:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:51:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:51:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:51:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:51:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 11:51:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:04:46 --> Severity: Error --> Call to undefined method User_model::get_company() /var/www/travel_app/application/controllers/Advancepayment.php 80
ERROR - 2018-12-08 12:04:59 --> Severity: Error --> Call to undefined method User_model::get_company() /var/www/travel_app/application/controllers/Advancepayment.php 80
ERROR - 2018-12-08 12:07:12 --> Severity: Error --> Call to undefined method User_model::get_company() /var/www/travel_app/application/controllers/Advancepayment.php 80
ERROR - 2018-12-08 12:07:58 --> Query error: Unknown table 'advance_payment' - Invalid query: SELECT sum(advance_payment.amount) as totamount, `advance_payment`.*, `airlines`.*, `companyId`
FROM `travel_users`
WHERE `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'
GROUP BY `airlines`.`id`, `airlines`.`companyId`
ERROR - 2018-12-08 12:10:13 --> Severity: Parsing Error --> syntax error, unexpected '$qry' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 307
ERROR - 2018-12-08 12:10:23 --> Query error: Unknown table 'advance_payment' - Invalid query: SELECT sum(advance_payment.amount) as totamount, `advance_payment`.*, `airlines`.*, `companyId`
FROM `travel_users`
WHERE `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'
GROUP BY `airlines`.`id`, `airlines`.`companyId`
ERROR - 2018-12-08 12:10:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:11:24 --> Query error: Unknown table 'advance_payment' - Invalid query: SELECT sum(advance_payment.amount) as totamount, `advance_payment`.*, `airlines`.*, `companyId`
FROM `travel_users`
WHERE `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'
GROUP BY `airlines`.`id`, `airlines`.`companyId`
ERROR - 2018-12-08 12:11:26 --> Query error: Unknown table 'advance_payment' - Invalid query: SELECT sum(advance_payment.amount) as totamount, `advance_payment`.*, `airlines`.*, `companyId`
FROM `travel_users`
WHERE `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'
GROUP BY `airlines`.`id`, `airlines`.`companyId`
ERROR - 2018-12-08 12:11:46 --> Query error: Unknown table 'advance_payment' - Invalid query: SELECT sum(advance_payment.amount) as totamount, `advance_payment`.*, `airlines`.*, `companyId`
FROM `travel_users`
WHERE `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'
GROUP BY `airlines`.`id`, `airlines`.`companyId`
ERROR - 2018-12-08 12:11:49 --> Query error: Unknown table 'advance_payment' - Invalid query: SELECT sum(advance_payment.amount) as totamount, `advance_payment`.*, `airlines`.*, `companyId`
FROM `travel_users`
WHERE `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'
GROUP BY `airlines`.`id`, `airlines`.`companyId`
ERROR - 2018-12-08 12:12:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:13:15 --> Query error: Unknown column 'airlines.companyId' in 'where clause' - Invalid query: SELECT sum(advance_payment.amount) as totamount, `advance_payment`.*, `airlines`.*
FROM `advance_payment`
LEFT JOIN `airlines` ON `airlines`.`id`=`advance_payment`.`airline_id`
WHERE `airlines`.`companyId` IN('102', '103')
GROUP BY `airlines`.`id`, `airlines`.`companyId`
ERROR - 2018-12-08 12:14:56 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/models/Admin_model.php 308
ERROR - 2018-12-08 12:14:56 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT (sum(tb.airline_cost)+sum(tb.service_charge)+sum(tb.tax)) as charge,tb.airline FROM `travel_booking` as tb where tb.airline='1' and tb.company in (Array) group by tb.airline
ERROR - 2018-12-08 12:17:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:18:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:20:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:20:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:20:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:20:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:21:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:21:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:21:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:21:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:23:25 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/models/Report_model.php 49
ERROR - 2018-12-08 12:44:21 --> 404 Page Not Found: Banking/capital
ERROR - 2018-12-08 12:50:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:50:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and date_format(`createdAt`,"%Y-%m-%d") >= "2018-11-25" AND date_format(`creat' at line 1 - Invalid query: SELECT companyId,COUNT(bookingId) as totcount,date_format(createdAt,"%Y-%m-%d") as createdAt FROM `travel_booking` WHERE companyId in () and date_format(`createdAt`,"%Y-%m-%d") >= "2018-11-25" AND date_format(`createdAt`,"%Y-%m-%d") <= "2018-12-14" group by date_format(`createdAt`,"%Y-%m-%d"),companyId
ERROR - 2018-12-08 12:51:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 12:51:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:51:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:51:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:52:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 12:59:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 13:01:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 13:01:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 13:02:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:07:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:11:56 --> Severity: Error --> Call to undefined method Booking_model::advance_list() /var/www/travel_app/application/views/user/advance_modal.php 6
ERROR - 2018-12-08 14:12:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:12:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'tb.companyId in (102,103) group by tb.airline' at line 1 - Invalid query: SELECT tb.airline,(sum(tb.airline_cost)+sum(tb.service_charge)+sum(tb.tax)) as totTicket FROM `travel_booking` as tb  where `bookingDate` >= '2018-12-04' and `bookingDate` <='2018-12-08' tb.companyId in (102,103) group by tb.airline
ERROR - 2018-12-08 14:13:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:13:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'tb.companyId in (102,103) group by tb.airline' at line 1 - Invalid query: SELECT tb.airline,(sum(tb.airline_cost)+sum(tb.service_charge)+sum(tb.tax)) as totTicket FROM `travel_booking` as tb  where `bookingDate` >= '2018-12-04' and `bookingDate` <='2018-12-08' tb.companyId in (102,103) group by tb.airline
ERROR - 2018-12-08 14:13:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:13:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:13:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'tb.companyId in (102,103) group by tb.airline' at line 1 - Invalid query: SELECT tb.airline,(sum(tb.airline_cost)+sum(tb.service_charge)+sum(tb.tax)) as totTicket FROM `travel_booking` as tb  where `bookingDate` >= '2018-12-04' and `bookingDate` <='2018-12-08' tb.companyId in (102,103) group by tb.airline
ERROR - 2018-12-08 14:14:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:14:18 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:14:18 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 14:14:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:14:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:14:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:14:51 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:14:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:14:51 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 14:14:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:18:23 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/models/First_model.php 180
ERROR - 2018-12-08 14:19:04 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/models/First_model.php 180
ERROR - 2018-12-08 14:20:37 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/models/First_model.php 180
ERROR - 2018-12-08 14:20:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:22:48 --> Severity: Compile Error --> Cannot redeclare First_model::get_companies() /var/www/travel_app/application/models/First_model.php 197
ERROR - 2018-12-08 14:23:17 --> Severity: Compile Error --> Cannot redeclare First_model::get_companies() /var/www/travel_app/application/models/First_model.php 197
ERROR - 2018-12-08 14:23:20 --> Severity: Compile Error --> Cannot redeclare First_model::get_companies() /var/www/travel_app/application/models/First_model.php 197
ERROR - 2018-12-08 14:26:03 --> Severity: Compile Error --> Cannot redeclare First_model::get_companies() /var/www/travel_app/application/models/First_model.php 197
ERROR - 2018-12-08 14:28:37 --> Severity: Compile Error --> Cannot redeclare First_model::total_cash_graph() /var/www/travel_app/application/models/First_model.php 223
ERROR - 2018-12-08 14:29:09 --> Severity: Compile Error --> Cannot redeclare First_model::total_cash_graph() /var/www/travel_app/application/models/First_model.php 223
ERROR - 2018-12-08 14:29:12 --> Severity: Compile Error --> Cannot redeclare First_model::total_cash_graph() /var/www/travel_app/application/models/First_model.php 223
ERROR - 2018-12-08 14:30:08 --> Severity: Compile Error --> Cannot redeclare First_model::get_companies() /var/www/travel_app/application/models/First_model.php 230
ERROR - 2018-12-08 14:33:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:35:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:37:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:37:28 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:37:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:37:28 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 14:37:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:44:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:44:13 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:44:13 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 14:46:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:46:04 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:46:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:46:04 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 14:47:17 --> Query error: Unknown column 'al.name' in 'field list' - Invalid query: SELECT ap.airline_id, sum(amount) as totAdvance, al.name FROM `advance_payment` as ap left join airlines as al on(al.id = ap.airline_id) where ap.`date` >= '2018-12-04' and ap.`date` <='2018-12-08' and ap.companyId in (102,103) group by ap.airline_id
ERROR - 2018-12-08 14:47:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:47:54 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:47:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:47:54 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 14:48:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:48:41 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 14:48:41 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 14:51:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 14:58:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 14:58:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:01:50 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/travel_app/application/models/First_model.php 171
ERROR - 2018-12-08 15:02:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT GROUP_CONCAT(CONCAT(companyId, 
ERROR - 2018-12-08 15:14:01 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/models/First_model.php 181
ERROR - 2018-12-08 15:14:50 --> Severity: Parsing Error --> syntax error, unexpected '$res' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 247
ERROR - 2018-12-08 15:15:10 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 246
ERROR - 2018-12-08 15:15:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:15:21 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:15:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:15:21 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:15:36 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 245
ERROR - 2018-12-08 15:15:38 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 245
ERROR - 2018-12-08 15:17:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 15:17:43 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:17:43 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:17:54 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 245
ERROR - 2018-12-08 15:17:57 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 245
ERROR - 2018-12-08 15:17:58 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 245
ERROR - 2018-12-08 15:18:00 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 245
ERROR - 2018-12-08 15:18:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:18:35 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 246
ERROR - 2018-12-08 15:18:36 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 246
ERROR - 2018-12-08 15:18:37 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 246
ERROR - 2018-12-08 15:18:38 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 246
ERROR - 2018-12-08 15:19:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 15:19:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:20:45 --> Severity: Notice --> Undefined index: totTicket /var/www/travel_app/application/models/Booking_model.php 180
ERROR - 2018-12-08 15:20:45 --> Severity: Notice --> Undefined index: totTicket /var/www/travel_app/application/models/Booking_model.php 180
ERROR - 2018-12-08 15:20:45 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:20:45 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:21:20 --> Severity: Notice --> Undefined index: totTicket /var/www/travel_app/application/models/Booking_model.php 181
ERROR - 2018-12-08 15:21:20 --> Severity: Notice --> Undefined index: totTicket /var/www/travel_app/application/models/Booking_model.php 181
ERROR - 2018-12-08 15:21:20 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:21:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:21:20 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:22:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:22:31 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:22:31 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:22:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:22:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 15:22:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:23:12 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:23:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:23:12 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:23:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:23:36 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:23:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:23:36 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:23:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 15:23:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:23:53 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:23:53 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:24:09 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:24:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:24:09 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:24:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:24:21 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:24:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:24:21 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:24:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 15:24:34 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:24:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:24:34 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:24:57 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 255
ERROR - 2018-12-08 15:24:58 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 255
ERROR - 2018-12-08 15:24:59 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 255
ERROR - 2018-12-08 15:24:59 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 255
ERROR - 2018-12-08 15:25:27 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:25:27 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:25:55 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/travel_app/application/models/Admin_model.php 258
ERROR - 2018-12-08 15:26:03 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:26:03 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:27:01 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:27:01 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:27:38 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:27:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:27:38 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:27:53 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 254
ERROR - 2018-12-08 15:28:35 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 22
ERROR - 2018-12-08 15:28:35 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 42
ERROR - 2018-12-08 15:31:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 157
ERROR - 2018-12-08 15:31:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 157
ERROR - 2018-12-08 15:31:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 15:34:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-08 15:34:45 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 23
ERROR - 2018-12-08 15:34:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/advance_modal.php 23
ERROR - 2018-12-08 15:34:45 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 46
ERROR - 2018-12-08 15:35:15 --> Severity: Notice --> Undefined index: totAmount /var/www/travel_app/application/views/user/advance_modal.php 36
ERROR - 2018-12-08 15:35:15 --> Severity: Notice --> Undefined index: totAmount /var/www/travel_app/application/views/user/advance_modal.php 39
ERROR - 2018-12-08 15:35:15 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 46
ERROR - 2018-12-08 15:36:11 --> Severity: Notice --> Undefined index: totAmount /var/www/travel_app/application/views/user/advance_modal.php 36
ERROR - 2018-12-08 15:36:11 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 46
ERROR - 2018-12-08 15:52:09 --> Severity: Notice --> Undefined index: totAmount /var/www/travel_app/application/views/user/advance_modal.php 36
ERROR - 2018-12-08 15:52:09 --> Severity: Notice --> Undefined variable: accounts_receivable /var/www/travel_app/application/views/user/advance_modal.php 46
ERROR - 2018-12-08 15:52:33 --> Severity: Notice --> Undefined index: totAmount /var/www/travel_app/application/views/user/advance_modal.php 36
ERROR - 2018-12-08 15:57:03 --> Severity: Warning --> key() expects exactly 1 parameter, 0 given /var/www/travel_app/application/views/admin/total_booking_graph.php 160
ERROR - 2018-12-08 15:57:03 --> Severity: Warning --> key() expects exactly 1 parameter, 0 given /var/www/travel_app/application/views/admin/total_booking_graph.php 160
ERROR - 2018-12-08 15:57:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/views/admin/total_booking_graph.php 160
ERROR - 2018-12-08 15:58:11 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/views/admin/total_booking_graph.php 160
ERROR - 2018-12-08 15:58:15 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/views/admin/total_booking_graph.php 160
ERROR - 2018-12-08 16:08:44 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/travel_app/application/models/Admin_model.php 304
ERROR - 2018-12-08 16:09:56 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/travel_app/application/models/Admin_model.php 304
ERROR - 2018-12-08 16:10:21 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/travel_app/application/models/Admin_model.php 304
ERROR - 2018-12-08 16:10:21 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/travel_app/application/models/Admin_model.php 304
ERROR - 2018-12-08 16:11:10 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 254
ERROR - 2018-12-08 16:11:13 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 254
ERROR - 2018-12-08 16:11:16 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/models/Admin_model.php 254
ERROR - 2018-12-08 16:46:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 16:46:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 16:58:13 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 16:58:13 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 16:58:13 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 16:58:13 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 16:59:56 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 16:59:56 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 16:59:56 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 16:59:56 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:01:22 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:01:22 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:01:22 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:01:22 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:01:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 17:01:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 17:01:48 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:01:48 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:01:48 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:01:48 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/models/Admin_model.php 303
ERROR - 2018-12-08 17:03:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 17:03:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 17:05:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 17:11:49 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-08 17:24:04 --> Severity: Notice --> Undefined variable: total_booking /var/www/travel_app/application/models/First_model.php 200
ERROR - 2018-12-08 17:24:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/models/First_model.php 200
ERROR - 2018-12-08 17:43:32 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-08 17:43:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-08 17:46:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and date_format(`createdAt`,'%Y-%m-%d') >= '2018-11-26' AND date_format(`creat' at line 1 - Invalid query: SELECT GROUP_CONCAT(CONCAT(companyId, ',', totcount) SEPARATOR '|') as points,createdAt FROM (SELECT companyId,SUM(priceCredit) as totcount,date_format(createdAt,'%Y-%m-%d') as createdAt FROM `travel_booking` WHERE companyId in () and date_format(`createdAt`,'%Y-%m-%d') >= '2018-11-26' AND date_format(`createdAt`,'%Y-%m-%d') <= '2018-12-10' group by date_format(`createdAt`,'%Y-%m-%d'),companyId) t group by date_format(`createdAt`,'%Y-%m-%d')
ERROR - 2018-12-08 17:47:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 117
ERROR - 2018-12-08 17:48:35 --> Query error: Unknown column 'txn_date' in 'field list' - Invalid query: INSERT INTO `banking` (`companyId`, `type`, `description`, `txn_date`, `amount`) VALUES ('102', '1', 'first', '2018-12-08', '10000')
ERROR - 2018-12-08 17:49:05 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-08 17:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-08 17:50:55 --> Query error: Unknown column 'txn_date' in 'field list' - Invalid query: INSERT INTO `banking` (`companyId`, `type`, `description`, `txn_date`, `amount`) VALUES ('102', '1', 'first', '2018-12-08', '10000')
ERROR - 2018-12-08 17:51:10 --> 404 Page Not Found: Banking/banking
ERROR - 2018-12-08 17:51:32 --> Query error: Unknown column 'txn_date' in 'field list' - Invalid query: INSERT INTO `banking` (`companyId`, `type`, `description`, `txn_date`, `amount`) VALUES ('102', '1', 'test', '2018-12-08', '100000')
ERROR - 2018-12-08 17:51:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-08 17:52:52 --> Query error: Unknown column 'txn_date' in 'field list' - Invalid query: INSERT INTO `banking` (`companyId`, `type`, `description`, `txn_date`, `amount`) VALUES ('102', '1', '', '2018-12-08', '100000')
ERROR - 2018-12-08 18:08:34 --> Query error: Unknown column 'type' in 'field list' - Invalid query: INSERT INTO `capital_account` (`companyId`, `type`, `description`, `txn_date`, `amount`) VALUES ('102', '1', 'first payment', '2018-12-08', '100000')
ERROR - 2018-12-08 19:24:40 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/models/Booking_model.php 197
