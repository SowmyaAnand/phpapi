<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-24 09:07:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:08:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:08:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:09:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:09:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:09:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:24:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:24:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:24:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-24 09:25:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-24 09:25:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 125
ERROR - 2018-12-24 09:26:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-24 09:31:14 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/controllers/Report.php 177
ERROR - 2018-12-24 09:34:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-24 09:35:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-24 09:35:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 125
ERROR - 2018-12-24 09:43:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 09:44:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 10:16:53 --> Severity: Error --> Call to undefined method Admin_model::admin_details() /var/www/travel_app/application/controllers/Admin.php 206
ERROR - 2018-12-24 10:16:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 11:20:20 --> Severity: Notice --> Undefined index: userFirstName /var/www/travel_app/application/views/admin/profile.php 40
ERROR - 2018-12-24 11:20:20 --> Severity: Notice --> Undefined index: userFirstName /var/www/travel_app/application/views/admin/profile.php 50
ERROR - 2018-12-24 11:20:20 --> Severity: Notice --> Undefined index: mobile /var/www/travel_app/application/views/admin/profile.php 61
ERROR - 2018-12-24 11:24:17 --> Severity: Notice --> Undefined index: FirstName /var/www/travel_app/application/views/admin/profile.php 40
ERROR - 2018-12-24 11:24:17 --> Severity: Notice --> Undefined index: FirstName /var/www/travel_app/application/views/admin/profile.php 50
ERROR - 2018-12-24 11:32:29 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 11:37:02 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 11:37:54 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 11:38:33 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 11:38:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 11:38:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 11:39:05 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:39:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:39:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 11:39:48 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:40:09 --> Severity: Error --> Call to undefined method Admin_model::update_profile() /var/www/travel_app/application/controllers/Admin.php 239
ERROR - 2018-12-24 11:41:35 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:41:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:43:59 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:44:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:44:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:44:49 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:44:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:45:30 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:45:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:54:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-24 11:54:53 --> 404 Page Not Found: User/profile
ERROR - 2018-12-24 11:54:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 11:55:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-24 11:57:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-24 11:58:10 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:58:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:59:26 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 11:59:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:03:07 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:03:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:03:37 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:03:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:04:07 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:04:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:05:40 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:06:03 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:06:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:06:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 12:06:31 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:16:02 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:16:47 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:16:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:16:50 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:16:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:16:53 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:16:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:29:23 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:29:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:29:34 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:31:06 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:31:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:31:07 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2018-12-24 12:31:07 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-24 12:31:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-24 12:31:40 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:31:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:31:44 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:31:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:31:46 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:31:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:35:51 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:35:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:35:53 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2018-12-24 12:35:53 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 286
ERROR - 2018-12-24 12:35:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2018-12-24 12:35:55 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:35:59 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:35:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:02 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:43 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:45 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2018-12-24 12:36:45 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 286
ERROR - 2018-12-24 12:36:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2018-12-24 12:36:46 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:47 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:49 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:36:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:19 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:23 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:28 --> Severity: Warning --> Illegal string offset 'password' /var/www/travel_app/application/controllers/Admin.php 253
ERROR - 2018-12-24 12:37:54 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:56 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2018-12-24 12:37:56 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-24 12:37:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-24 12:37:58 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:59 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:37:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:38:03 --> Severity: Warning --> Illegal string offset 'password' /var/www/travel_app/application/controllers/Admin.php 253
ERROR - 2018-12-24 12:39:22 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:39:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:39:26 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:39:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:39:31 --> Severity: Warning --> Illegal string offset 'password' /var/www/travel_app/application/controllers/Admin.php 252
ERROR - 2018-12-24 12:40:11 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:40:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:40:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 12:40:15 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:40:22 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:40:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:40:46 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:40:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:41:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:41:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:41:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 12:41:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 12:41:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-24 12:41:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 12:41:30 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:41:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:41:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 12:43:48 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:43:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:44:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 12:46:19 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:46:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:46:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 12:48:45 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:48:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:48:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 12:48:53 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:48:58 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:49:00 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:49:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:52:11 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:52:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:52:14 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 12:52:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:01:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:01:34 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:01:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:02:12 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:02:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:04:05 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2018-12-24 13:04:05 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 286
ERROR - 2018-12-24 13:04:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2018-12-24 13:04:06 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:04:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:04:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:04:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:04:14 --> Severity: Notice --> Undefined variable: result /var/www/travel_app/application/controllers/Admin.php 255
ERROR - 2018-12-24 13:04:59 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:05:01 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:05:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:05:04 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:06:34 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:06:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:06:36 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2018-12-24 13:06:36 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 286
ERROR - 2018-12-24 13:06:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2018-12-24 13:06:37 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:06:40 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:06:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:08:20 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:08:42 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:08:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:09:37 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:14:49 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:14:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:15:04 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:15:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 13:15:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 14:17:03 --> Severity: Compile Error --> Cannot redeclare Admin_model::edit_mail_exists() /var/www/travel_app/application/models/Admin_model.php 250
ERROR - 2018-12-24 14:17:56 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:17:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:18:44 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:18:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:18:59 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:21:58 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:21:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:25:30 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:25:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 14:25:38 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:25:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:25:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 14:26:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:26:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:26:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 14:26:12 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 374
ERROR - 2018-12-24 14:26:12 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 286
ERROR - 2018-12-24 14:26:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2018-12-24 14:34:17 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:34:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 14:34:23 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:34:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 14:36:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:36:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:36:19 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:36:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:38:28 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:38:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:38:31 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 74
ERROR - 2018-12-24 14:41:51 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:43:54 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:43:56 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:43:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:44:23 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:44:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:47:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:51:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:51:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:52:44 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 76
ERROR - 2018-12-24 14:55:49 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:56:49 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:57:41 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:57:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:58:26 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:58:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:58:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 14:59:18 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:59:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:59:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 14:59:38 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:59:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 14:59:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 15:01:17 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 15:01:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 15:01:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 15:02:03 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 15:02:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 15:02:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 15:02:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 15:02:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 75
ERROR - 2018-12-24 15:02:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 15:06:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:06:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:06:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-24 15:07:12 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:07:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:07:23 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:07:42 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:07:56 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:07:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:09 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:17 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:24 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:33 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:47 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:08:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:11:46 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/controllers/Welcome.php 390
ERROR - 2018-12-24 15:11:46 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Welcome.php 773
ERROR - 2018-12-24 15:11:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` in()
ERROR - 2018-12-24 15:14:22 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/controllers/Welcome.php 389
ERROR - 2018-12-24 15:15:52 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/controllers/Welcome.php 391
ERROR - 2018-12-24 15:15:52 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Welcome.php 774
ERROR - 2018-12-24 15:15:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` in()
ERROR - 2018-12-24 15:20:15 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-24 15:20:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
