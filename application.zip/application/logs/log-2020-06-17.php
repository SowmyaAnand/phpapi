<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-17 12:34:06 --> Severity: Notice --> Undefined variable: total_questions C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 21
ERROR - 2020-06-17 12:34:06 --> Severity: Notice --> Undefined variable: total_polls C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 50
ERROR - 2020-06-17 12:34:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-17 12:34:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-17 12:34:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-17 12:34:39 --> 404 Page Not Found: Assets/img
