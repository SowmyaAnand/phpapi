<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-18 13:57:01 --> 404 Page Not Found: ListAllCategoryItem/index
ERROR - 2020-08-18 13:57:02 --> 404 Page Not Found: ListAllCategoryItem/index
ERROR - 2020-08-18 13:58:29 --> 404 Page Not Found: ListAllCategoryItem/index
ERROR - 2020-08-18 13:58:35 --> 404 Page Not Found: ListAllCategoryItem/index
ERROR - 2020-08-18 13:59:37 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:03:29 --> 404 Page Not Found: ListAllCategoryItem/index
ERROR - 2020-08-18 14:03:54 --> 404 Page Not Found: ListAllCategoryItem/index
ERROR - 2020-08-18 14:03:57 --> 404 Page Not Found: ListAllCategoryItem/index
ERROR - 2020-08-18 14:05:32 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:05:36 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:21:26 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:29:10 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:30:28 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:30:39 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:30:43 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:32:07 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:32:07 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:35:11 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:35:12 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:35:13 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:35:14 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:36:01 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:41:08 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:41:10 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:44:27 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:44:46 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:06 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:22 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:22 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:23 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:23 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:23 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:23 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:23 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:23 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:45:43 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:49:13 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:49:13 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:49:13 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:49:13 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:49:13 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:49:14 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:50:04 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:50:05 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:50:06 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:50:07 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:53:40 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:53:41 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:53:46 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:53:47 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:53:47 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-18 14:53:47 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
