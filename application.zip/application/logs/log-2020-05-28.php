<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-28 19:24:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-28 19:37:44 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-28 19:38:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-28 19:40:38 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::last_insert_id() C:\xampp\htdocs\assignment\application\controllers\Admin.php 86
ERROR - 2020-05-28 20:51:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-28 20:53:14 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 20:53:14 --> Query error: Unknown column 'question' in 'field list' - Invalid query: INSERT INTO `options` (`question`, `type`) VALUES ('year of birth', '1')
ERROR - 2020-05-28 20:53:49 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 20:53:50 --> Query error: Unknown column 'option' in 'field list' - Invalid query: INSERT INTO `options` (`option`, `qId`) VALUES ('1', 8)
ERROR - 2020-05-28 20:54:14 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 20:54:14 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 20:54:14 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 20:54:14 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 20:54:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-28 21:05:58 --> Severity: Warning --> Illegal string offset 'options' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 21:05:58 --> Severity: Warning --> Illegal string offset 'options' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 21:05:58 --> Severity: Warning --> Illegal string offset 'options' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 21:05:58 --> Severity: Warning --> Illegal string offset 'options' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-05-28 21:05:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-28 21:06:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-28 22:26:55 --> 404 Page Not Found: Assets/img
