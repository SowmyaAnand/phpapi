<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-17 22:50:01 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-17 22:50:01 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-17 22:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-17 22:50:01 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-17 22:50:01 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-17 22:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-17 22:50:01 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-17 22:50:01 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-17 22:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-17 22:50:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-17 22:50:16 --> 404 Page Not Found: Assets/img
