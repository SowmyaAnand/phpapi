<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-02 08:51:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 08:51:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 08:52:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 08:52:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 08:53:06 --> Severity: Notice --> Undefined variable: add_booking /var/www/travel_app/application/controllers/Report.php 207
ERROR - 2019-01-02 08:53:19 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 08:53:19 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 08:53:19 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-02 08:53:19 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-02 08:54:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 08:54:21 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 08:54:21 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 08:54:21 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-02 08:54:21 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-02 09:02:08 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:02:08 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:02:08 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-02 09:02:08 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-02 09:02:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 09:02:24 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:02:24 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:02:24 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-02 09:02:24 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-02 09:03:37 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:03:37 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:03:37 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-02 09:03:37 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-02 09:04:58 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:04:58 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:04:58 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-02 09:04:58 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-02 09:09:45 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 09:09:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 09:09:49 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:09:49 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-02 09:09:49 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-02 09:09:49 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-02 09:16:45 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2019-01-02 09:16:45 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2019-01-02 09:16:45 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 160
ERROR - 2019-01-02 09:16:45 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-02 09:17:35 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2019-01-02 09:17:35 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2019-01-02 09:17:35 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 160
ERROR - 2019-01-02 09:17:35 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-02 09:18:17 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2019-01-02 09:18:17 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2019-01-02 09:18:17 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 160
ERROR - 2019-01-02 09:18:17 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-02 09:18:20 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2019-01-02 09:18:20 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 156
ERROR - 2019-01-02 09:18:20 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 160
ERROR - 2019-01-02 09:18:20 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-02 09:18:46 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-02 09:18:46 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-02 09:18:46 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-02 09:18:46 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 162
ERROR - 2019-01-02 09:18:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 09:19:17 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-02 09:19:17 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-02 09:19:17 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-02 09:19:17 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 162
ERROR - 2019-01-02 09:19:32 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-02 09:19:32 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-02 09:19:32 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-02 09:19:32 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 162
ERROR - 2019-01-02 09:22:09 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/invoice.php 246
ERROR - 2019-01-02 09:33:18 --> Severity: Notice --> Undefined variable: add_booking /var/www/travel_app/application/controllers/Report.php 208
ERROR - 2019-01-02 09:35:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 10:05:51 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/controllers/Report.php 104
ERROR - 2019-01-02 10:06:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 10:17:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 10:17:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 10:18:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 10:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-02 10:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-02 10:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-02 10:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-02 10:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-02 10:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-02 10:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-02 10:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-02 10:23:18 --> Severity: Notice --> Undefined property: stdClass::$company /var/www/travel_app/application/controllers/Report.php 106
ERROR - 2019-01-02 10:27:56 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/views/user/customer_travel.php 84
ERROR - 2019-01-02 10:27:56 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/views/user/customer_travel.php 84
ERROR - 2019-01-02 10:27:56 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/views/user/customer_travel.php 84
ERROR - 2019-01-02 10:27:56 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/views/user/customer_travel.php 84
ERROR - 2019-01-02 10:28:48 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/views/user/customer_travel.php 84
ERROR - 2019-01-02 10:28:48 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/views/user/customer_travel.php 84
ERROR - 2019-01-02 10:28:48 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/views/user/customer_travel.php 84
ERROR - 2019-01-02 10:28:48 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/views/user/customer_travel.php 84
ERROR - 2019-01-02 10:36:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 10:51:30 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-02 10:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-02 10:51:30 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-02 10:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-02 11:04:58 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:04:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:05:01 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:05:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:05:04 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:05:06 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:05:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:05:07 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:05:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:05:07 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:05:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:05:08 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:05:08 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:04 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:08 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:09 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:09 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:10 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:10 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:11 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:12 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:12 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:13 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:14 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:14 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:15 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:08:15 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:08:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:24 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:25 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:25 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:26 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:26 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:27 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:27 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:28 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:28 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:30 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:30 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:31 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:31 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:09:32 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:09:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:10:15 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:10:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:10:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:10:23 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:10:23 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:10:24 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:10:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:10:24 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:10:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:10:31 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:10:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:11:18 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:11:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:16:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:16:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:16:02 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:16:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:16:02 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:16:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:16:03 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:16:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:16:03 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:16:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:16:03 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:16:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:16:05 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:16:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:32 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:34 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:36 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:37 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:38 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:38 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:39 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:39 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:40 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:41 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:41 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:42 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:42 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:43 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:44 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:44 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:19:45 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:19:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:20:52 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:20:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:20:53 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:20:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:20:57 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:20:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:20:57 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:20:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:20:58 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:20:58 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:20:59 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:20:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:20:59 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:20:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:21:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:21:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:21:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:21:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:21:01 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:21:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:21:15 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:21:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:38:03 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:38:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:38:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 11:38:34 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:38:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:39:06 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:39:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:39:32 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:39:56 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:39:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:40:10 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:40:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:40:31 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:40:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:40:57 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:40:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:41:18 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:41:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:42:43 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:42:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:42:50 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:42:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:43:18 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:43:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:43:31 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:43:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:44:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:44:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:44:25 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:44:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:45:14 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:45:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:45:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:45:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:45:47 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:45:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:46:09 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:46:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:46:51 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:46:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:47:36 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:47:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:47:49 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:47:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:48:59 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:48:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:49:19 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:49:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:49:34 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:49:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:49:47 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:49:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:54:49 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:54:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:55:17 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:55:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:56:01 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:56:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:56:12 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:57:56 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:57:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 11:58:24 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 11:58:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:00:38 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:00:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:08:16 --> Severity: Error --> Call to undefined method Report_model::expense_report_admin() /var/www/travel_app/application/controllers/Report.php 127
ERROR - 2019-01-02 12:08:18 --> Severity: Error --> Call to undefined method Report_model::expense_report_admin() /var/www/travel_app/application/controllers/Report.php 127
ERROR - 2019-01-02 12:17:50 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:17:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:22:11 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:22:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:22:56 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:22:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:23:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:23:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:23:06 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:23:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:23:57 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:23:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:24:31 --> Severity: Warning --> Missing argument 2 for Report::cancel_booking() /var/www/travel_app/application/controllers/Report.php 220
ERROR - 2019-01-02 12:25:02 --> Severity: Warning --> Missing argument 2 for Report::cancel_booking() /var/www/travel_app/application/controllers/Report.php 220
ERROR - 2019-01-02 12:27:27 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Report.php 228
ERROR - 2019-01-02 12:27:44 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:27:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:27:52 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:27:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:27:56 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Report.php 228
ERROR - 2019-01-02 12:27:56 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:27:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:28:59 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:29:01 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Report.php 228
ERROR - 2019-01-02 12:29:02 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:29:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:29:44 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:29:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:29:48 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Report.php 228
ERROR - 2019-01-02 12:29:49 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:29:52 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:34:15 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Report.php 228
ERROR - 2019-01-02 12:37:30 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:37:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:37:55 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 12:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 12:49:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 12:50:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 12:50:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 13:00:54 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 14:21:20 --> Query error: Unknown column 'staus' in 'where clause' - Invalid query: SELECT `priceCredit` as `credit`, `creditPaid`, `company`, `bookingDate`, `bookingId`
FROM `travel_booking`
WHERE `company` = 'RTwoCompany'
AND `staus` = 0
ERROR - 2019-01-02 14:47:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2019-01-02 14:47:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2019-01-02 15:01:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 15:03:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 15:13:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 15:14:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-02 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-02 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-02 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-02 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-02 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-02 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-02 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-02 15:17:34 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-02 15:17:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-02 15:17:34 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-02 15:17:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-02 15:28:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 15:29:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 15:30:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 15:31:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:31:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 15:32:15 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:32:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 15:33:30 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:33:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 15:34:43 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:34:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 15:35:23 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:35:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 15:36:16 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:36:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 15:36:18 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/controllers/Booking.php 380
ERROR - 2019-01-02 15:40:43 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:40:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 15:56:05 --> Severity: Notice --> Undefined index: student_id /var/www/travel_app/application/views/user/customer_travel.php 144
ERROR - 2019-01-02 15:56:05 --> Severity: Notice --> Undefined index: student_id /var/www/travel_app/application/views/user/customer_travel.php 153
ERROR - 2019-01-02 15:56:05 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/customer_travel.php 155
ERROR - 2019-01-02 15:57:35 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/customer_travel.php 155
ERROR - 2019-01-02 15:57:40 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:57:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 15:57:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 15:58:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-02 15:58:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-02 19:21:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 19:46:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 19:50:16 --> Severity: Notice --> Undefined variable: cost_of_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 7
ERROR - 2019-01-02 19:50:29 --> Severity: Notice --> Undefined variable: cost_of_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 7
ERROR - 2019-01-02 19:59:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`bookingDate` >= '2018-12-01' and `bookingDate` <='2019-01-02' ORDER BY `booking' at line 1 - Invalid query: SELECT sum(priceCash+creditPaid) as totTicket  FROM `travel_booking` WHERE `companyId` in (102,103,130,130,132) and `status`='0' `bookingDate` >= '2018-12-01' and `bookingDate` <='2019-01-02' ORDER BY `bookingId`  DESC
ERROR - 2019-01-02 20:10:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-02 21:03:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2019-01-02 21:03:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2019-01-02 21:03:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2019-01-02 21:05:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2019-01-02 21:05:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2019-01-02 21:05:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2019-01-02 21:05:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2019-01-02 21:08:08 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/capital_details.php 213
ERROR - 2019-01-02 21:08:34 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /var/www/travel_app/application/views/admin/capital_details.php 158
ERROR - 2019-01-02 21:13:48 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/views/admin/capital_details.php 157
ERROR - 2019-01-02 21:15:11 --> Severity: Notice --> Undefined variable: sum /var/www/travel_app/application/views/admin/capital_details.php 157
ERROR - 2019-01-02 21:15:11 --> Severity: Notice --> Undefined variable: sum1 /var/www/travel_app/application/views/admin/capital_details.php 164
ERROR - 2019-01-02 21:17:54 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /var/www/travel_app/application/views/admin/capital_details.php 157
ERROR - 2019-01-02 21:19:56 --> Severity: Notice --> Undefined variable: sum /var/www/travel_app/application/views/admin/capital_details.php 157
ERROR - 2019-01-02 21:19:56 --> Severity: Notice --> Undefined variable: sum1 /var/www/travel_app/application/views/admin/capital_details.php 164
ERROR - 2019-01-02 21:40:01 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2019-01-02 21:40:01 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2019-01-02 21:40:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2019-01-02 21:40:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2019-01-02 21:46:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 207
ERROR - 2019-01-02 21:46:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 207
ERROR - 2019-01-02 22:03:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2019-01-02 22:03:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2019-01-02 22:05:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-02 22:05:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-02 22:05:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-02 22:05:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-02 22:05:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2019-01-02 22:05:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2019-01-02 22:06:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2019-01-02 22:06:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2019-01-02 22:07:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 228
ERROR - 2019-01-02 22:07:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 228
ERROR - 2019-01-02 22:08:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 228
ERROR - 2019-01-02 22:08:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 228
ERROR - 2019-01-02 22:27:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 208
ERROR - 2019-01-02 22:27:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 208
