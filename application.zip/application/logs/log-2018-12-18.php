<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-18 09:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 09:52:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 09:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 09:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 09:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 09:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 09:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 09:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 09:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 09:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 09:57:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 09:57:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 09:57:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 09:57:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 09:57:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 09:57:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 09:57:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 09:57:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 09:58:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-18 09:58:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-18 10:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:06:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:07:15 --> Severity: Notice --> Undefined offset: 0 /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:07:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:07:20 --> Severity: Notice --> Undefined offset: 0 /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:07:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:07:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:08:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:09:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 10:28:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 10:30:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 10:57:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:05:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:05:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:05:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:08:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:10:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:10:17 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Advancepayment.php 70
ERROR - 2018-12-18 11:13:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:14:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:16:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:16:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:17:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:18:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:19:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:23:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:24:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:25:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:25:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:25:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:30:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:30:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:30:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:32:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:32:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:32:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:35:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:35:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:35:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:36:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:36:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:36:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:36:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:37:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:37:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:37:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:37:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:37:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:37:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:38:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:38:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:38:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:38:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:38:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:42:57 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /var/www/travel_app/application/controllers/Advancepayment.php 101
ERROR - 2018-12-18 11:43:10 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /var/www/travel_app/application/controllers/Advancepayment.php 101
ERROR - 2018-12-18 11:43:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:43:33 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /var/www/travel_app/application/controllers/Advancepayment.php 101
ERROR - 2018-12-18 11:44:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:44:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:44:29 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /var/www/travel_app/application/controllers/Advancepayment.php 101
ERROR - 2018-12-18 11:45:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:46:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:46:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:46:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:47:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 11:47:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-18 11:47:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:48:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:48:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:48:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:49:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:52:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:52:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 11:54:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 11:55:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 12:26:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 12:26:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 12:26:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 12:26:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 12:26:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 12:26:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 12:26:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 12:26:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 12:28:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 12:28:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 12:28:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 12:28:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 12:28:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 12:28:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 12:28:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 12:28:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 12:30:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 12:52:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 12:52:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 12:52:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 12:52:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 12:52:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 12:52:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 12:52:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 12:52:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 12:57:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 13:09:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 13:13:25 --> Severity: Notice --> Undefined index: creditpaid /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-18 13:14:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 13:15:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 13:18:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 13:18:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:19:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:20:02 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-18 14:22:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:23:11 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:23:11 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:23:11 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:23:11 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:40:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 14:40:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 14:40:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 14:40:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 14:40:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 14:40:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 14:40:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 14:40:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 14:41:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:41:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 14:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 14:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 14:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 14:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 14:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 14:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 14:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 14:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 14:42:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:46:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 186
ERROR - 2018-12-18 14:46:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:46:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:46:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 186
ERROR - 2018-12-18 14:46:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:47:06 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:47:06 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:47:06 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:47:06 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:47:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 186
ERROR - 2018-12-18 14:47:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:48:10 --> Query error: Unknown column 'type' in 'field list' - Invalid query: SELECT (tb.priceCash+tb.creditPaid) as totAmount, tc.companyName as company,type as 'Ticket Booking'  FROM `travel_booking` as tb left join travel_company as tc on(tc.companyId = tb.companyId) WHERE tb.`companyId` in (102,103,130,130) and tb.`bookingDate` >= '2018-12-18' and tb.`bookingDate` <='2018-12-18'
ERROR - 2018-12-18 14:48:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:49:00 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:49:00 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:49:00 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:49:00 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:49:24 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:49:24 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:49:24 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:49:24 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:49:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:49:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:51:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:52:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:52:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:52:27 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:52:27 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:52:27 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:52:27 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:52:53 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:52:53 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:52:53 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:52:53 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:53:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:54:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:54:31 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:54:31 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:54:31 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:54:31 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:54:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:55:05 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:55:05 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:55:05 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:55:05 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:55:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 14:55:40 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:55:40 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:55:40 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:55:40 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:55:56 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:55:56 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:55:56 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:55:56 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:56:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:57:21 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:57:21 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:57:21 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:57:21 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:57:39 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:57:39 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-18 14:57:39 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:57:39 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-18 14:58:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 14:58:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:58:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 14:59:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 14:59:29 --> Severity: Notice --> Undefined offset: 0 /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 14:59:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 14:59:34 --> Severity: Notice --> Undefined offset: 0 /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 14:59:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 14:59:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-18 15:02:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 15:02:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 15:02:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 15:02:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 15:02:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 15:02:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 15:02:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 15:02:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 15:03:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:03:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 15:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 15:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 15:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 15:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 15:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 15:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 15:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 15:04:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:04:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:04:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 15:04:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-18 15:04:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-18 15:04:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-18 15:04:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 15:04:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-18 15:04:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-18 15:04:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-18 15:04:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-18 15:05:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:06:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:17:09 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/travel_app/application/controllers/Report.php 265
ERROR - 2018-12-18 15:18:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 15:18:54 --> 404 Page Not Found: Daybook/trial_balance
ERROR - 2018-12-18 15:25:03 --> 404 Page Not Found: Daybook/trial_balance
ERROR - 2018-12-18 15:26:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 15:42:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 15:53:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/controllers/Report.php 160
ERROR - 2018-12-18 15:56:44 --> Severity: Notice --> Undefined variable: fromDate /var/www/travel_app/application/views/user/trial_balance.php 75
ERROR - 2018-12-18 15:56:44 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/views/user/trial_balance.php 75
ERROR - 2018-12-18 15:57:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:58:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:58:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:59:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 15:59:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:59:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 15:59:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 15:59:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 16:00:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 16:00:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 16:00:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 16:00:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 16:00:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-18 16:02:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 16:07:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 16:45:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 16:56:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 16:58:23 --> 404 Page Not Found: Banking/trial_balance
ERROR - 2018-12-18 16:58:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 17:00:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 157
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 158
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:04:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/system/core/Exceptions.php:271) /var/www/travel_app/system/helpers/url_helper.php 564
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Illegal string offset 'priceCredit' /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:05:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/system/core/Exceptions.php:271) /var/www/travel_app/system/helpers/url_helper.php 564
ERROR - 2018-12-18 17:07:37 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-18 17:07:37 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/controllers/Report.php 165
ERROR - 2018-12-18 17:09:57 --> Query error: Unknown column 'ca.amount' in 'field list' - Invalid query: SELECT sum(ca.amount) as capital_account,p.name  FROM `capital_account` as cs left join proprietor as p on(p.id = ca.proprietor) WHERE ca.`companyId` in (102,103,130,130) and ca.`txn_date` >= '2018-12-18' and ca.`txn_date` <='2018-12-18' and ca.txn_type = 1 group by ca.proprietor
ERROR - 2018-12-18 17:10:36 --> Severity: Notice --> Undefined index: capital_account /var/www/travel_app/application/models/Booking_model.php 235
ERROR - 2018-12-18 17:11:38 --> Severity: Notice --> Undefined index: capital_account /var/www/travel_app/application/models/Booking_model.php 235
ERROR - 2018-12-18 17:11:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 17:14:12 --> Severity: Notice --> Undefined index: capital_account /var/www/travel_app/application/models/Booking_model.php 235
ERROR - 2018-12-18 17:15:06 --> Severity: Notice --> Undefined index: capital_account /var/www/travel_app/application/models/Booking_model.php 235
ERROR - 2018-12-18 17:16:20 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:16:20 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:16:20 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:20:58 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:20:58 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:20:58 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:25:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'where ca.txn_type = 1' at line 1 - Invalid query: SELECT SUM(ca.amount) as totAmount,'Capital' as 'label', 'credit' as 'type' FROM `capital_account` as ca WHERE ca.`companyId` in (102,103,130,130) and ca.`txn_date` >= '2018-12-18' and ca.`txn_date` <='2018-12-18' where ca.txn_type = 1
ERROR - 2018-12-18 17:27:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 17:28:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-18 17:31:29 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:31:29 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:31:29 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:32:43 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:32:43 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:32:43 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:33:28 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:33:28 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:33:28 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:33:38 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:33:38 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:33:38 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:35:01 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:35:01 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:35:01 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:35:17 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:35:17 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:35:17 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:35:50 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:35:50 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:35:50 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:36:24 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 133
ERROR - 2018-12-18 17:36:24 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 138
ERROR - 2018-12-18 17:36:24 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 150
ERROR - 2018-12-18 17:41:10 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 134
ERROR - 2018-12-18 17:41:10 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/balance_sheet.php 139
ERROR - 2018-12-18 17:41:10 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 151
ERROR - 2018-12-18 17:47:10 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/balance_sheet.php 154
