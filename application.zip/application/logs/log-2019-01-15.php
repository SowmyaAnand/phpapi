<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-15 09:04:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-15 11:27:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-15 11:28:03 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/controllers/Booking.php 151
ERROR - 2019-01-15 11:28:03 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 175
ERROR - 2019-01-15 11:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 11:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 11:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 11:49:10 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/controllers/Booking.php 151
ERROR - 2019-01-15 11:49:10 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 174
ERROR - 2019-01-15 11:49:10 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 178
ERROR - 2019-01-15 11:49:10 --> Query error: Column 'companyName' cannot be null - Invalid query: INSERT INTO `travel_company` (`companyCode`, `companyName`, `companyLogo`, `companyAddress`, `companyEmail`, `companyPhone`) VALUES ('', NULL, '', '', '', '')
ERROR - 2019-01-15 11:50:14 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/controllers/Booking.php 151
ERROR - 2019-01-15 11:50:14 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 174
ERROR - 2019-01-15 11:50:14 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 178
ERROR - 2019-01-15 11:50:14 --> Query error: Column 'companyName' cannot be null - Invalid query: INSERT INTO `travel_company` (`companyCode`, `companyName`, `companyLogo`, `companyAddress`, `companyEmail`, `companyPhone`) VALUES ('', NULL, '', '', '', '')
ERROR - 2019-01-15 11:50:38 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 174
ERROR - 2019-01-15 11:50:38 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 178
ERROR - 2019-01-15 11:50:38 --> Query error: Column 'companyName' cannot be null - Invalid query: INSERT INTO `travel_company` (`companyCode`, `companyName`, `companyLogo`, `companyAddress`, `companyEmail`, `companyPhone`) VALUES ('', NULL, '', '', '', '')
ERROR - 2019-01-15 11:53:52 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 174
ERROR - 2019-01-15 11:55:11 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 179
ERROR - 2019-01-15 11:55:11 --> Query error: Column 'companyName' cannot be null - Invalid query: INSERT INTO `travel_company` (`companyCode`, `companyName`, `companyLogo`, `companyAddress`, `companyEmail`, `companyPhone`) VALUES ('', NULL, '', '', '', '')
ERROR - 2019-01-15 11:55:27 --> Query error: Duplicate entry '0' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyCode`, `companyName`, `companyLogo`, `companyAddress`, `companyEmail`, `companyPhone`) VALUES ('', 'company xyzfgfghfg', '', '', '', '')
ERROR - 2019-01-15 12:08:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-15 12:12:45 --> Query error: Table 'travel_app_db.travel_customers' doesn't exist - Invalid query: SELECT *
FROM `travel_customers`
WHERE `customerCompany` = 'aasdfsdf'
ERROR - 2019-01-15 12:17:42 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 201
ERROR - 2019-01-15 12:17:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 12:17:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 12:17:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 13:33:33 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 201
ERROR - 2019-01-15 13:33:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 13:33:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 13:33:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 13:34:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-15 13:34:50 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::mysql_insert_id() /var/www/travel_app/application/controllers/Booking.php 197
ERROR - 2019-01-15 13:35:18 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 201
ERROR - 2019-01-15 13:35:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 13:35:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 13:35:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 13:39:20 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 201
ERROR - 2019-01-15 13:39:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 13:39:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 13:39:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 13:40:33 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 202
ERROR - 2019-01-15 13:40:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 13:40:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 13:40:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 13:48:08 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Booking.php 190
ERROR - 2019-01-15 13:48:08 --> Query error: Column 'companyId' cannot be null - Invalid query: INSERT INTO `travel_customer` (`customerCompany`, `customerFirstname`, `customerLastname`, `customerGender`, `customerAge`, `customerEmail`, `customerPhone`, `customerAddress`, `customerPost`, `customerPincode`, `customerCity`, `customerState`, `customerCountry`, `companyId`, `createdBy`, `status`) VALUES ('sadasdsdsad', 'Ambikadsddas', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '')
ERROR - 2019-01-15 13:48:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-15 13:50:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`travel_app_db`.`travel_customer`, CONSTRAINT `travel_customer_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: INSERT INTO `travel_customer` (`customerCompany`, `customerFirstname`, `customerLastname`, `customerGender`, `customerAge`, `customerEmail`, `customerPhone`, `customerAddress`, `customerPost`, `customerPincode`, `customerCity`, `customerState`, `customerCountry`, `createdBy`, `status`) VALUES ('sadasdsdsad', 'Ambikadsddas', '', '', '', '', '', '', '', '', '', '', '', '', '')
ERROR - 2019-01-15 13:58:12 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 200
ERROR - 2019-01-15 13:58:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 167
ERROR - 2019-01-15 13:58:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 168
ERROR - 2019-01-15 13:58:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 169
ERROR - 2019-01-15 13:58:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 170
ERROR - 2019-01-15 14:00:36 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 203
ERROR - 2019-01-15 14:00:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 167
ERROR - 2019-01-15 14:00:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 168
ERROR - 2019-01-15 14:00:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 169
ERROR - 2019-01-15 14:00:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 170
ERROR - 2019-01-15 14:05:31 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 204
ERROR - 2019-01-15 14:08:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:08:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:08:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:11:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:11:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:11:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:11:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:11:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:11:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:12:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:12:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:12:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 260
ERROR - 2019-01-15 14:12:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:12:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:12:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:13:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:13:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:13:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:14:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:14:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:14:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:17:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:17:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:17:00 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:17:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:17:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:17:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:20:09 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/views/user/ticket_details.php 188
ERROR - 2019-01-15 14:23:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:24:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:24:15 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:24:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:24:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:25:24 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 204
ERROR - 2019-01-15 14:25:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:25:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:25:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:25:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:36:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-15 14:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-15 14:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 259
ERROR - 2019-01-15 14:37:47 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:49:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:52:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:53:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:57:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:57:52 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-15 14:57:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-15 14:57:52 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-15 14:57:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-15 14:57:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:57:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:57:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:58:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:58:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:58:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:58:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:58:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:58:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:58:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:59:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:59:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:59:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:59:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-15 14:59:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 14:59:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:00:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:00:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:00:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:00:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:01:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:01:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-15 15:01:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-15 15:02:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-15 15:02:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-15 15:02:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:03:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:03:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:03:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:03:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:04:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:07:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:09:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:10:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:11:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:12:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:13:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:13:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:15:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:15:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:16:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:16:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:17:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:18:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:19:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:20:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:23:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:23:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:25:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:25:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:48:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:51:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:51:35 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-15 15:51:45 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-15 15:51:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:52:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:55:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:57:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 15:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-15 16:00:11 --> 404 Page Not Found: Assets/img
