<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-06 09:32:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 09:32:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 09:36:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:36:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:36:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:36:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:36:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:36:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:38:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:38:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:38:32 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:38:32 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:38:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:38:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:38:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 09:38:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:38:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:39:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 09:40:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:40:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 09:40:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 09:41:22 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN859559686', '9', '103', 'new company', '1234567890', '5000', 'cash', 'new company', 'Robert')
ERROR - 2018-12-06 09:49:40 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN1258170649', '9', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 09:49:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 09:50:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 09:51:03 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN1258170649', '9', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 09:51:07 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN1258170649', '9', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 09:52:58 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /var/www/travel_app/application/models/User_model.php 244
ERROR - 2018-12-06 09:55:28 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN1258170649', '9', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 09:55:32 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN1258170649', '9', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 10:04:41 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:05:57 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:06:06 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:08:50 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:08:56 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:12:00 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:12:14 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:13:58 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:14:02 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-06 10:14:38 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN1949963152', '7', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 10:19:05 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN1949963152', '7', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 10:20:31 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN65156774', '7', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 10:28:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:29:22 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `income` (`customerId`, `companyId`, `receipt_no`, `incomeType`, `company`, `cash_from`, `phone`, `credit`, `payment_type`, `description`, `approved_by`) VALUES ('2', '102', 'IN835321758', '9', '102', 'robort', '1234567890', '5000', 'cash', 'robert', 'Robert')
ERROR - 2018-12-06 10:36:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:41:57 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseType`, `company`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN1223751277', '1', '103', 'new company', '1234567890', '40000', 'cash', 'new company', '2', NULL)
ERROR - 2018-12-06 10:46:49 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/models/User_model.php 260
ERROR - 2018-12-06 10:47:28 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-06 10:47:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:47:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:48:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:49:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:49:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:50:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:50:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:50:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 10:51:43 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseType`, `company`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN388816859', '1', '102', 'robert', '1234567890', '4000', 'cash', 'robert', '2', NULL)
ERROR - 2018-12-06 10:53:06 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseType`, `company`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN388816859', '1', '102', 'robert', '1234567890', '4000', 'cash', 'robert', '2', NULL)
ERROR - 2018-12-06 10:53:09 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseType`, `company`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN388816859', '1', '102', 'robert', '1234567890', '4000', 'cash', 'robert', '2', NULL)
ERROR - 2018-12-06 10:53:43 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseType`, `company`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN881060388', '1', '102', 'robert', '1234567890', '4000', 'cash', 'robert', '2', NULL)
ERROR - 2018-12-06 11:23:08 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseType`, `company`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN881060388', '1', '102', 'robert', '1234567890', '4000', 'cash', 'robert', '2', NULL)
ERROR - 2018-12-06 11:26:26 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseType`, `company`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN881060388', '1', '102', 'robert', '1234567890', '4000', 'cash', 'robert', '2', NULL)
ERROR - 2018-12-06 11:26:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 11:27:28 --> Query error: Unknown column 'expenseDate' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseDate`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN573535651', '2018-12-07', '1', 'robert', '1234567890', '4000', 'cash', 'robert', '2', NULL)
ERROR - 2018-12-06 11:32:52 --> Query error: Unknown column 'expensDate' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseDate`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `description`, `approved_by`, `expensDate`) VALUES ('2', '102', 'TN573535651', '2018-12-07', '1', 'robert', '1234567890', '4000', 'cash', 'robert', '2', NULL)
ERROR - 2018-12-06 11:47:57 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/day_report.php 33
ERROR - 2018-12-06 11:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/day_report.php 33
ERROR - 2018-12-06 11:53:13 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/transaction_report.php 60
ERROR - 2018-12-06 11:53:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/transaction_report.php 60
ERROR - 2018-12-06 11:53:15 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/transaction_report.php 60
ERROR - 2018-12-06 11:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/transaction_report.php 60
ERROR - 2018-12-06 11:53:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 11:54:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 11:57:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:01:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:02:46 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/day_report.php 33
ERROR - 2018-12-06 12:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/day_report.php 33
ERROR - 2018-12-06 12:03:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:03:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:03:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:06:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:09:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:09:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:10:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:10:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:11:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:11:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:12:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:12:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:12:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:13:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:15:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:25:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:25:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:25:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:25:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:26:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:26:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:26:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:26:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:27:40 --> 404 Page Not Found: Booking/credit_payment
ERROR - 2018-12-06 12:27:44 --> Severity: Notice --> Undefined variable: formDate /var/www/travel_app/application/views/user/profit_loss.php 46
ERROR - 2018-12-06 12:27:50 --> 404 Page Not Found: Booking/credit_payment
ERROR - 2018-12-06 12:27:56 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/credit_payment.php 57
ERROR - 2018-12-06 12:27:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/credit_payment.php 57
ERROR - 2018-12-06 12:33:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:33:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:33:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:35:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:40:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:40:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:41:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:47:19 --> Severity: Notice --> Undefined variable: system_name /var/www/travel_app/application/views/theme/modal.php 43
ERROR - 2018-12-06 12:47:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:48:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:48:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:48:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:48:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 12:51:07 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/credit_payment.php 165
ERROR - 2018-12-06 12:51:32 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/credit_payment.php 165
ERROR - 2018-12-06 12:51:53 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/credit_payment.php 165
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: month_difference /var/www/travel_app/application/views/user/profit_loss.php 45
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/views/user/profit_loss.php 45
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: fromDate /var/www/travel_app/application/views/user/profit_loss.php 46
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/views/user/profit_loss.php 46
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/views/user/profit_loss.php 54
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: all_revenue /var/www/travel_app/application/views/user/profit_loss.php 60
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: cost_of_revenue /var/www/travel_app/application/views/user/profit_loss.php 66
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: cost_of_revenue /var/www/travel_app/application/views/user/profit_loss.php 72
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: all_revenue /var/www/travel_app/application/views/user/profit_loss.php 72
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: cost_of_revenue /var/www/travel_app/application/views/user/profit_loss.php 72
ERROR - 2018-12-06 12:52:56 --> Severity: Notice --> Undefined variable: all_revenue /var/www/travel_app/application/views/user/profit_loss.php 72
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: month_difference /var/www/travel_app/application/views/user/profit_loss.php 45
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/views/user/profit_loss.php 45
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: fromDate /var/www/travel_app/application/views/user/profit_loss.php 46
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/views/user/profit_loss.php 46
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/views/user/profit_loss.php 54
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: all_revenue /var/www/travel_app/application/views/user/profit_loss.php 60
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: cost_of_revenue /var/www/travel_app/application/views/user/profit_loss.php 66
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: cost_of_revenue /var/www/travel_app/application/views/user/profit_loss.php 72
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: all_revenue /var/www/travel_app/application/views/user/profit_loss.php 72
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: cost_of_revenue /var/www/travel_app/application/views/user/profit_loss.php 72
ERROR - 2018-12-06 12:53:09 --> Severity: Notice --> Undefined variable: all_revenue /var/www/travel_app/application/views/user/profit_loss.php 72
ERROR - 2018-12-06 12:53:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 12:55:58 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/credit_payment.php 106
ERROR - 2018-12-06 12:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/credit_payment.php 106
ERROR - 2018-12-06 12:56:06 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 12:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 12:56:06 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 76
ERROR - 2018-12-06 12:56:13 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/credit_payment.php 106
ERROR - 2018-12-06 12:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/credit_payment.php 106
ERROR - 2018-12-06 12:56:37 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 12:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 12:56:37 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 76
ERROR - 2018-12-06 12:56:42 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 12:56:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 12:56:42 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 76
ERROR - 2018-12-06 12:57:49 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 12:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 12:58:17 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/profit_loss.php 59
ERROR - 2018-12-06 13:01:51 --> Severity: Notice --> Undefined variable: param1 /var/www/travel_app/application/views/user/revenue_modal.php 2
ERROR - 2018-12-06 13:01:51 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 26
ERROR - 2018-12-06 13:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 26
ERROR - 2018-12-06 13:01:51 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 79
ERROR - 2018-12-06 13:02:44 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 26
ERROR - 2018-12-06 13:02:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 26
ERROR - 2018-12-06 13:02:44 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 79
ERROR - 2018-12-06 13:03:12 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 27
ERROR - 2018-12-06 13:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 27
ERROR - 2018-12-06 13:03:12 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 80
ERROR - 2018-12-06 13:03:16 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 27
ERROR - 2018-12-06 13:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 27
ERROR - 2018-12-06 13:03:16 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 80
ERROR - 2018-12-06 13:03:49 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 27
ERROR - 2018-12-06 13:03:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 27
ERROR - 2018-12-06 13:03:49 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 80
ERROR - 2018-12-06 13:04:24 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 29
ERROR - 2018-12-06 13:04:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 29
ERROR - 2018-12-06 13:04:24 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 82
ERROR - 2018-12-06 13:06:14 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 13:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 13:06:25 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 13:06:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 13:07:13 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 13:07:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 13:07:22 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/credit_payment.php 120
ERROR - 2018-12-06 13:07:22 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/credit_payment.php 120
ERROR - 2018-12-06 13:09:36 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 31
ERROR - 2018-12-06 13:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 31
ERROR - 2018-12-06 13:09:36 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 84
ERROR - 2018-12-06 13:20:43 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 31
ERROR - 2018-12-06 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 31
ERROR - 2018-12-06 13:20:43 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 84
ERROR - 2018-12-06 13:21:06 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 13:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/credit_payment.php 107
ERROR - 2018-12-06 13:22:31 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 31
ERROR - 2018-12-06 13:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 31
ERROR - 2018-12-06 13:22:31 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 84
ERROR - 2018-12-06 13:23:32 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/admin/credit_payment.php 109
ERROR - 2018-12-06 13:27:19 --> Severity: Notice --> Undefined variable: ticketTotal /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 13:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 13:27:19 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 48
ERROR - 2018-12-06 13:27:50 --> Severity: Notice --> Undefined index: customerId /var/www/travel_app/application/views/admin/credit_payment.php 124
ERROR - 2018-12-06 13:27:51 --> Severity: Notice --> Undefined variable: ticketTotal /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 13:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/revenue_modal.php 23
ERROR - 2018-12-06 13:27:51 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 48
ERROR - 2018-12-06 13:28:52 --> Severity: Notice --> Undefined variable: customers /var/www/travel_app/application/views/user/revenue_modal.php 48
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: bookingDate /var/www/travel_app/application/views/user/revenue_modal.php 79
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/user/revenue_modal.php 83
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: priceCash /var/www/travel_app/application/views/user/revenue_modal.php 86
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/user/revenue_modal.php 89
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: bookingDate /var/www/travel_app/application/views/user/revenue_modal.php 79
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/user/revenue_modal.php 83
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: priceCash /var/www/travel_app/application/views/user/revenue_modal.php 86
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/user/revenue_modal.php 89
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: bookingDate /var/www/travel_app/application/views/user/revenue_modal.php 79
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/user/revenue_modal.php 83
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: priceCash /var/www/travel_app/application/views/user/revenue_modal.php 86
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/user/revenue_modal.php 89
ERROR - 2018-12-06 13:31:00 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: bookingDate /var/www/travel_app/application/views/user/revenue_modal.php 79
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/user/revenue_modal.php 83
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: priceCash /var/www/travel_app/application/views/user/revenue_modal.php 86
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/user/revenue_modal.php 89
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: bookingDate /var/www/travel_app/application/views/user/revenue_modal.php 79
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/user/revenue_modal.php 83
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: priceCash /var/www/travel_app/application/views/user/revenue_modal.php 86
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/user/revenue_modal.php 89
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: bookingDate /var/www/travel_app/application/views/user/revenue_modal.php 79
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: company /var/www/travel_app/application/views/user/revenue_modal.php 83
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: priceCash /var/www/travel_app/application/views/user/revenue_modal.php 86
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/user/revenue_modal.php 89
ERROR - 2018-12-06 13:31:40 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 14:18:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 14:19:38 --> Severity: Notice --> Undefined index: type /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 14:19:38 --> Severity: Notice --> Undefined index: type /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 14:19:38 --> Severity: Notice --> Undefined index: type /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 14:20:24 --> Severity: Notice --> Undefined index: type /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 14:20:24 --> Severity: Notice --> Undefined index: type /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 14:20:24 --> Severity: Notice --> Undefined index: type /var/www/travel_app/application/views/user/revenue_modal.php 92
ERROR - 2018-12-06 14:26:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 14:28:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:29:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:29:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:32:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:34:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:34:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:34:35 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 7
ERROR - 2018-12-06 14:34:35 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:34:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:34:35 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 49
ERROR - 2018-12-06 14:34:35 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:34:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:34:35 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 101
ERROR - 2018-12-06 14:35:06 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:35:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:35:06 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 49
ERROR - 2018-12-06 14:35:06 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:35:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:35:06 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 101
ERROR - 2018-12-06 14:36:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:36:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:36:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:36:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:36:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:36:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:36:59 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:36:59 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 49
ERROR - 2018-12-06 14:36:59 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:36:59 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 101
ERROR - 2018-12-06 14:37:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:37:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:37:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:37:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:37:32 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:37:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:37:32 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 49
ERROR - 2018-12-06 14:37:32 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:37:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:37:32 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 101
ERROR - 2018-12-06 14:37:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:37:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:37:49 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 24
ERROR - 2018-12-06 14:37:49 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 49
ERROR - 2018-12-06 14:37:49 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 76
ERROR - 2018-12-06 14:37:49 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 101
ERROR - 2018-12-06 14:39:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:39:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:39:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:40:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:40:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 14:40:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:40:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:41:06 --> Severity: Notice --> Undefined variable: cost_of_revenue /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 23
ERROR - 2018-12-06 14:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 23
ERROR - 2018-12-06 14:41:06 --> Severity: Notice --> Undefined variable: cost_of_revenue /var/www/travel_app/application/views/user/cost_of_revenue_modal.php 43
ERROR - 2018-12-06 14:41:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:41:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:41:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:41:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:42:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 14:44:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 14:46:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 14:47:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 14:49:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:49:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:51:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:51:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:51:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 14:51:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:51:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:55:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:55:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:55:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:55:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:55:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 14:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 14:55:38 --> Query error: Table 'travel_app_db.expenese' doesn't exist - Invalid query: SELECT sum(exp.debit) as totExpense  FROM `expenese` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) where exp.`expenseDate` >= '2018-12-06' and exp.`expenseDate` <='2018-12-06' and et.status = 0
ERROR - 2018-12-06 14:57:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 15:02:02 --> Severity: Error --> Call to undefined method CI_Session::flash_data() /var/www/travel_app/application/views/admin/credit_payment.php 26
ERROR - 2018-12-06 15:02:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:02:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 15:02:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:02:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 15:02:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:02:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 15:02:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:02:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 15:04:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:04:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 15:05:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 15:05:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 15:06:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 15:10:45 --> Severity: Notice --> Undefined variable: totExpense /var/www/travel_app/application/views/user/profit_loss.php 82
ERROR - 2018-12-06 15:20:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:20:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:21:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:21:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:23:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:23:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:23:50 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:25:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:26:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:30:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 15:30:29 --> Severity: Notice --> Use of undefined constant checked - assumed 'checked' /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:30:29 --> Severity: Notice --> Use of undefined constant checked - assumed 'checked' /var/www/travel_app/application/views/admin/income_report.php 61
ERROR - 2018-12-06 15:30:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:31:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:31:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 15:31:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:31:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:31:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:31:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:32:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:32:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:32:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:32:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:32:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:33:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:33:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:33:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:33:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:33:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:33:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 15:54:56 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Daybook.php 521
ERROR - 2018-12-06 15:55:26 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Daybook.php 521
ERROR - 2018-12-06 16:00:10 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/income_report.php 62
ERROR - 2018-12-06 16:00:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/income_report.php 62
ERROR - 2018-12-06 16:00:55 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Daybook.php 521
ERROR - 2018-12-06 16:03:07 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/income_report.php 62
ERROR - 2018-12-06 16:03:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/income_report.php 62
ERROR - 2018-12-06 16:04:58 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Daybook.php 521
ERROR - 2018-12-06 16:05:50 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Daybook.php 504
ERROR - 2018-12-06 16:38:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:38:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:38:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 16:39:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 16:39:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:39:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:40:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:40:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:40:32 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:40:32 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:41:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:41:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:42:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 16:42:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 17:06:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:06:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 17:07:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:07:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:10:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-06 17:12:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 17:12:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-06 17:17:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 17:17:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 17:17:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 17:17:30 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 17:17:30 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 17:22:49 --> 404 Page Not Found: Daybook/edit_income
ERROR - 2018-12-06 17:23:10 --> 404 Page Not Found: Daybook/edit_income
ERROR - 2018-12-06 17:27:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 17:42:34 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/edit_income.php 407
ERROR - 2018-12-06 17:42:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:43:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:44:35 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/edit_income.php 406
ERROR - 2018-12-06 17:44:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:44:39 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/edit_income.php 406
ERROR - 2018-12-06 17:44:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:44:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 17:45:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 17:45:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 17:47:50 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 116
ERROR - 2018-12-06 17:47:58 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 116
ERROR - 2018-12-06 19:48:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 19:59:07 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 24
ERROR - 2018-12-06 19:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/expense_modal.php 24
ERROR - 2018-12-06 19:59:07 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 49
ERROR - 2018-12-06 19:59:07 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 76
ERROR - 2018-12-06 19:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/expense_modal.php 76
ERROR - 2018-12-06 19:59:07 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 101
ERROR - 2018-12-06 19:59:22 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 24
ERROR - 2018-12-06 19:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/expense_modal.php 24
ERROR - 2018-12-06 19:59:22 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 49
ERROR - 2018-12-06 19:59:22 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 76
ERROR - 2018-12-06 19:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/expense_modal.php 76
ERROR - 2018-12-06 19:59:22 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 101
ERROR - 2018-12-06 20:14:23 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 24
ERROR - 2018-12-06 20:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/expense_modal.php 24
ERROR - 2018-12-06 20:14:23 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 49
ERROR - 2018-12-06 20:14:23 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 76
ERROR - 2018-12-06 20:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/expense_modal.php 76
ERROR - 2018-12-06 20:14:23 --> Severity: Notice --> Undefined variable: all_revenues /var/www/travel_app/application/views/user/expense_modal.php 101
ERROR - 2018-12-06 20:14:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-06 20:31:31 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:31:31 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:31:31 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:31:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 20:31:57 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:31:57 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:31:57 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:34:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 20:35:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 20:36:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 20:37:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 20:37:32 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:37:32 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:37:32 --> Severity: Notice --> Undefined index: expenseDate /var/www/travel_app/application/views/user/depreciation_modal.php 28
ERROR - 2018-12-06 20:39:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 20:40:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 20:43:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-06 20:46:13 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/depreciation_modal.php 22
ERROR - 2018-12-06 20:46:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/depreciation_modal.php 22
ERROR - 2018-12-06 20:46:13 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/depreciation_modal.php 42
ERROR - 2018-12-06 20:50:03 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 20:50:03 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-06 20:51:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
