<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-03 14:20:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-03 14:30:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-03 14:35:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-03 14:43:21 --> Severity: Warning --> Missing argument 2 for Report::cancel_booking() /var/www/travel_app/application/controllers/Report.php 224
ERROR - 2019-01-03 14:43:21 --> Severity: Warning --> Missing argument 3 for Report::cancel_booking() /var/www/travel_app/application/controllers/Report.php 224
ERROR - 2019-01-03 14:43:21 --> Severity: Notice --> Undefined variable: fromDate /var/www/travel_app/application/controllers/Report.php 226
ERROR - 2019-01-03 14:43:21 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/controllers/Report.php 226
ERROR - 2019-01-03 14:49:50 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Report_model.php 49
ERROR - 2019-01-03 14:49:50 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Report_model.php 50
ERROR - 2019-01-03 14:51:53 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/travel_app/application/models/Report_model.php 42
ERROR - 2019-01-03 14:52:40 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting function (T_FUNCTION) /var/www/travel_app/application/models/Report_model.php 62
ERROR - 2019-01-03 14:57:28 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/controllers/Report.php 233
ERROR - 2019-01-03 14:58:55 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/controllers/Report.php 233
ERROR - 2019-01-03 14:59:53 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Report.php 115
ERROR - 2019-01-03 15:14:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 107
ERROR - 2019-01-03 15:17:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 108
ERROR - 2019-01-03 15:18:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/user/customer_travel.php 68
ERROR - 2019-01-03 15:19:54 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/user/customer_travel.php 68
ERROR - 2019-01-03 15:23:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-03 19:40:33 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Report_model.php 44
ERROR - 2019-01-03 19:40:33 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Report_model.php 46
ERROR - 2019-01-03 19:42:20 --> Severity: Error --> Call to undefined method Report_model::booking_report_data() /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 19:42:42 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Report_model.php 83
ERROR - 2019-01-03 19:42:42 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Report_model.php 85
ERROR - 2019-01-03 20:01:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Report.php 233
ERROR - 2019-01-03 20:09:14 --> Severity: Notice --> Undefined variable: page_data /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 20:10:12 --> Severity: Notice --> Undefined variable: page_data /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 20:12:01 --> Severity: Notice --> Undefined variable: page_data /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 20:13:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 108
ERROR - 2019-01-03 20:22:04 --> Query error: Unknown column 'companyName' in 'where clause' - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyName` = 'RTwoCompany'
ERROR - 2019-01-03 20:22:23 --> Query error: Unknown column 'company' in 'where clause' - Invalid query: SELECT *
FROM `travel_customer`
WHERE `company` = 'RTwoCompany'
ERROR - 2019-01-03 20:22:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:25:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:27:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:27:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:34:32 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:35:08 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:35:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:36:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:37:32 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:38:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:42:32 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:42:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 20:49:14 --> Severity: Notice --> Undefined variable: page_data /var/www/travel_app/application/controllers/Report.php 129
ERROR - 2019-01-03 20:51:12 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Report.php 132
ERROR - 2019-01-03 20:55:31 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Report.php 110
ERROR - 2019-01-03 20:55:31 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 111
ERROR - 2019-01-03 20:55:31 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 113
ERROR - 2019-01-03 20:56:46 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Report.php 110
ERROR - 2019-01-03 20:56:46 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 111
ERROR - 2019-01-03 20:56:46 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 113
ERROR - 2019-01-03 20:56:46 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 20:56:46 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Report.php 118
ERROR - 2019-01-03 20:56:46 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 119
ERROR - 2019-01-03 20:56:46 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 121
ERROR - 2019-01-03 20:57:02 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 20:57:02 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Report.php 118
ERROR - 2019-01-03 20:57:02 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 119
ERROR - 2019-01-03 20:57:02 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 121
ERROR - 2019-01-03 20:59:14 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/controllers/Report.php 110
ERROR - 2019-01-03 20:59:14 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 111
ERROR - 2019-01-03 20:59:14 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 113
ERROR - 2019-01-03 20:59:14 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 21:00:01 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 21:00:42 --> Severity: Notice --> Undefined index: frDate /var/www/travel_app/application/controllers/Report.php 110
ERROR - 2019-01-03 21:00:42 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 111
ERROR - 2019-01-03 21:00:42 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 113
ERROR - 2019-01-03 21:00:42 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 21:01:16 --> Severity: Notice --> Undefined index: frDate /var/www/travel_app/application/controllers/Report.php 110
ERROR - 2019-01-03 21:01:16 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 111
ERROR - 2019-01-03 21:01:16 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 113
ERROR - 2019-01-03 21:01:16 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 21:01:16 --> Severity: Notice --> Undefined index: tDate /var/www/travel_app/application/controllers/Report.php 118
ERROR - 2019-01-03 21:01:16 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 119
ERROR - 2019-01-03 21:01:16 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 121
ERROR - 2019-01-03 21:03:21 --> Severity: Notice --> Undefined variable: toDate /var/www/travel_app/application/controllers/Report.php 117
ERROR - 2019-01-03 21:03:21 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 119
ERROR - 2019-01-03 21:03:21 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 121
ERROR - 2019-01-03 21:03:51 --> 404 Page Not Found: Report/index
ERROR - 2019-01-03 21:04:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 21:05:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/customer_travel.php 148
ERROR - 2019-01-03 21:38:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 143
ERROR - 2019-01-03 21:39:32 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 143
ERROR - 2019-01-03 21:39:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 143
ERROR - 2019-01-03 21:43:20 --> Severity: 4096 --> Object of class Report could not be converted to string /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:43:20 --> Severity: Notice --> Object of class Report to string conversion /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:43:20 --> Severity: Notice --> Undefined variable: Object /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:43:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:43:20 --> Severity: Error --> Call to a member function post() on null /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:56:12 --> Severity: 4096 --> Object of class Report could not be converted to string /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:56:12 --> Severity: Notice --> Object of class Report to string conversion /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:56:12 --> Severity: Notice --> Undefined variable: Object /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:56:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:56:12 --> Severity: Error --> Call to a member function post() on null /var/www/travel_app/application/controllers/Report.php 144
ERROR - 2019-01-03 21:57:22 --> Query error: Unknown column 'companyName' in 'where clause' - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyName` = 'RTwoCompany'
ERROR - 2019-01-03 22:02:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 108
ERROR - 2019-01-03 22:03:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 108
