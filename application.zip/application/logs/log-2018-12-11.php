<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-11 10:00:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:01:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:04:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:05:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:05:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:06:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:09:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Undefined property: stdClass::$companyName /var/www/travel_app/application/views/user/ticket_details.php 182
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:22:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Undefined property: stdClass::$companyName /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:22:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:24:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:25:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:25:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:25:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:25:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:25:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:25:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:28:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:28:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:28:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 186
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 187
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:30:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 10:30:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:36:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:37:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 10:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 10:47:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 10:47:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 10:47:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 10:47:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:47:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 10:47:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 10:47:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 10:47:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 11:08:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 11:08:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 11:08:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 11:08:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 11:08:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:08:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:08:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 11:08:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 11:08:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 11:10:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 11:11:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 11:11:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 11:11:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 11:11:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:11:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:11:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 11:11:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 11:11:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 11:12:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 11:12:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 11:12:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 11:12:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:12:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:12:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 11:12:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 11:12:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 11:13:25 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-11 11:14:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 11:14:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 11:14:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 11:14:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:14:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:14:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 11:14:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 11:14:16 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 11:15:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 11:17:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 11:17:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 11:17:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 11:17:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:17:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:17:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 11:17:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 11:17:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 11:19:50 --> Query error: Unknown column 'usercompany' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `travelTo`, `departureDateTime`, `arrivalDateTime`, `flightNo`, `pnr`, `priceCash`, `priceCredit`, `tax`, `bookingDate`, `usercompany`, `paymentType`, `airline`, `airline_cost`, `service_charge`, `companyId`, `createdBy`) VALUES ('CompanyRobert', 'robert passenger12', '1', '19', '2018-12-11 11:19', '2018-12-12 11:17', 'robertf1', 'pnrK02', '6500', '0', '1500', '2018-12-11', '', 1, '1', '500', '1000', '102', '2')
ERROR - 2018-12-11 11:28:01 --> Query error: Unknown column 'usercompany' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `travelTo`, `departureDateTime`, `arrivalDateTime`, `flightNo`, `pnr`, `priceCash`, `priceCredit`, `tax`, `bookingDate`, `usercompany`, `paymentType`, `airline`, `airline_cost`, `service_charge`, `companyId`, `createdBy`) VALUES ('CompanyRobert', 'robert passenger12', '1', '19', '2018-12-11 11:19', '2018-12-12 11:17', 'robertf1', 'pnrK02', '6500', '0', '1500', '2018-12-11', '', 1, '1', '500', '1000', '102', '2')
ERROR - 2018-12-11 11:31:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 11:31:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 11:31:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 11:31:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:31:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 11:31:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 11:31:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 11:31:13 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 11:32:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 11:51:03 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 25
ERROR - 2018-12-11 11:51:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and `bookingDate` >= '2018-12-06' and `bookingDate` <='2018-12-11' ORDER BY `b' at line 1 - Invalid query: SELECT sum(priceCash+creditPaid) as totTicket  FROM `travel_booking` WHERE `companyId` in () and `bookingDate` >= '2018-12-06' and `bookingDate` <='2018-12-11' ORDER BY `bookingId`  DESC
ERROR - 2018-12-11 11:53:26 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Banking.php 31
ERROR - 2018-12-11 11:53:26 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `banking`
WHERE `companyId` in (Array)
ERROR - 2018-12-11 11:54:27 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/travel_app/application/controllers/Banking.php 33
ERROR - 2018-12-11 11:54:49 --> Severity: Notice --> Undefined variable: CI /var/www/travel_app/application/views/admin/banking.php 312
ERROR - 2018-12-11 11:54:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/banking.php 312
ERROR - 2018-12-11 11:54:49 --> Severity: Error --> Call to a member function get_company_name() on null /var/www/travel_app/application/views/admin/banking.php 312
ERROR - 2018-12-11 11:55:37 --> Severity: Notice --> Undefined variable: CI /var/www/travel_app/application/views/admin/banking.php 313
ERROR - 2018-12-11 11:55:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/banking.php 313
ERROR - 2018-12-11 11:55:37 --> Severity: Error --> Call to a member function get_company_name() on null /var/www/travel_app/application/views/admin/banking.php 313
ERROR - 2018-12-11 12:08:25 --> Severity: Notice --> Undefined index: fDate /var/www/travel_app/application/controllers/Banking.php 87
ERROR - 2018-12-11 12:08:59 --> Severity: Notice --> Undefined variable: banking_details /var/www/travel_app/application/views/admin/banking_details.php 45
ERROR - 2018-12-11 12:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/banking_details.php 45
ERROR - 2018-12-11 12:08:59 --> Severity: Notice --> Undefined variable: banking_details /var/www/travel_app/application/views/admin/banking_details.php 80
ERROR - 2018-12-11 12:09:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`companyId=c`.`companyId`
WHERE `companyId` in(102,103)
AND b.date_format(creat' at line 2 - Invalid query: SELECT `b`.`companyId`, COUNT(b.bookingId) AS count, `c`.`companyId`, `c`.`companyName`
FROM `travel_booking b left join travel_company c on` `b`.`companyId=c`.`companyId`
WHERE `companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%m-%d") = '2018-12-11'
GROUP BY `b`.`companyId`
ERROR - 2018-12-11 12:09:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/banking_details.php 45
ERROR - 2018-12-11 12:10:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`companyId`
WHERE `companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%m-%d' at line 2 - Invalid query: SELECT `b`.`companyId`, COUNT(b.bookingId) AS count, `c`.`companyId`, `c`.`companyName`
FROM `travel_booking b left join travel_company c on c`.`companyId =` `b`.`companyId`
WHERE `companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%m-%d") = '2018-12-11'
GROUP BY `b`.`companyId`
ERROR - 2018-12-11 12:11:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 12:11:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`companyId`
WHERE `b`.`companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%' at line 2 - Invalid query: SELECT `b`.`companyId`, COUNT(b.bookingId) AS count, `c`.`companyId`, `c`.`companyName`
FROM `travel_booking b left join travel_company c on c`.`companyId =` `b`.`companyId`
WHERE `b`.`companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%m-%d") = '2018-12-11'
GROUP BY `b`.`companyId`
ERROR - 2018-12-11 12:11:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 12:20:22 --> Severity: Parsing Error --> syntax error, unexpected 'AS' (T_AS) /var/www/travel_app/application/models/First_model.php 102
ERROR - 2018-12-11 12:20:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`companyId`
WHERE `b`.`companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%' at line 2 - Invalid query: SELECT `b`.`companyId`, COUNT(b.bookingId) AS count, `c`.`companyId`, `c`.`companyName`
FROM `travel_booking b left join travel_company c on c`.`companyId =` `b`.`companyId`
WHERE `b`.`companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%m-%d") = '2018-12-11'
GROUP BY `b`.`companyId`
ERROR - 2018-12-11 12:23:42 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/travel_app/application/models/First_model.php 103
ERROR - 2018-12-11 12:23:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`companyId`
WHERE `b`.`companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%' at line 2 - Invalid query: SELECT `b`.`companyId`, COUNT(b.bookingId) AS count, `c`.`companyId`, `c`.`companyName`
FROM `travel_booking b left join travel_company c on c`.`companyId =` `b`.`companyId`
WHERE `b`.`companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%m-%d") = '2018-12-11'
GROUP BY `b`.`companyId`
ERROR - 2018-12-11 12:23:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`companyId`
WHERE `b`.`companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%' at line 2 - Invalid query: SELECT `b`.`companyId`, COUNT(b.bookingId) AS count, `c`.`companyId`, `c`.`companyName`
FROM `travel_booking b left join travel_company c on c`.`companyId =` `b`.`companyId`
WHERE `b`.`companyId` in(102,103)
AND b.date_format(createdAt,"%Y-%m-%d") = '2018-12-11'
GROUP BY `b`.`companyId`
ERROR - 2018-12-11 12:24:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 50
ERROR - 2018-12-11 12:25:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 50
ERROR - 2018-12-11 12:27:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 12:36:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/banking_details.php 45
ERROR - 2018-12-11 12:51:47 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 110
ERROR - 2018-12-11 12:51:52 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 110
ERROR - 2018-12-11 12:52:11 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 110
ERROR - 2018-12-11 12:55:41 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() /var/www/travel_app/application/models/First_model.php 111
ERROR - 2018-12-11 12:56:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 12:58:09 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() /var/www/travel_app/application/models/First_model.php 110
ERROR - 2018-12-11 12:58:11 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() /var/www/travel_app/application/models/First_model.php 110
ERROR - 2018-12-11 12:58:44 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() /var/www/travel_app/application/models/First_model.php 111
ERROR - 2018-12-11 12:58:45 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() /var/www/travel_app/application/models/First_model.php 111
ERROR - 2018-12-11 12:59:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 12:59:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 13:00:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:01:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:01:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 13:02:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:02:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:02:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 13:02:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:03:13 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/controllers/Banking.php 92
ERROR - 2018-12-11 13:03:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'' at line 3 - Invalid query: SELECT `companyId`
FROM `travel_users`
WHERE `transactionDate` >= `2018-12-01` and `transactionDate` < `IS` `NULL`
AND `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'
ERROR - 2018-12-11 13:03:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:03:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 13:03:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:03:38 --> Query error: Unknown column 'transactionDate' in 'where clause' - Invalid query: SELECT `companyId`
FROM `travel_users`
WHERE `transactionDate` >= `2018-12-01` and `transactionDate` <= `2018-12-11`
AND `userEmail` = 'Dr@dr.com'
AND `userRoll` = '1'
ERROR - 2018-12-11 13:04:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:04:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:04:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:04:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 13:04:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:04:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:04:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:05:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:05:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:05:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:05:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:05:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:06:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:06:40 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Banking.php 97
ERROR - 2018-12-11 13:06:40 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `banking`
WHERE `transactionDate` >= "2018-12-01" and `transactionDate` <= "2018-12-11"
AND `companyId` in(Array)
ERROR - 2018-12-11 13:06:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:10:50 --> Severity: Parsing Error --> syntax error, unexpected 'date' (T_STRING) /var/www/travel_app/application/models/First_model.php 110
ERROR - 2018-12-11 13:14:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:14:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:15:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:15:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:15:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:15:55 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() /var/www/travel_app/application/models/First_model.php 110
ERROR - 2018-12-11 13:16:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 13:19:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:24:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 13:25:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:17:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/dashboard.php 98
ERROR - 2018-12-11 14:17:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 186
ERROR - 2018-12-11 14:19:41 --> Severity: Notice --> Undefined index: totcash /var/www/travel_app/application/views/admin/dashboard.php 151
ERROR - 2018-12-11 14:19:41 --> Severity: Notice --> Undefined index: totcash /var/www/travel_app/application/views/admin/dashboard.php 151
ERROR - 2018-12-11 14:20:41 --> Severity: Notice --> Undefined index: totcash /var/www/travel_app/application/views/admin/dashboard.php 152
ERROR - 2018-12-11 14:20:41 --> Severity: Notice --> Undefined index: totcash /var/www/travel_app/application/views/admin/dashboard.php 152
ERROR - 2018-12-11 14:21:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 186
ERROR - 2018-12-11 14:21:30 --> Severity: Notice --> Undefined index: totcash /var/www/travel_app/application/views/admin/dashboard.php 153
ERROR - 2018-12-11 14:21:30 --> Severity: Notice --> Undefined index: totcash /var/www/travel_app/application/views/admin/dashboard.php 153
ERROR - 2018-12-11 14:24:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 14:24:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 14:24:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 14:24:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:24:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:24:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 14:24:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 14:24:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 14:24:53 --> 404 Page Not Found: Banking/capital_account
ERROR - 2018-12-11 14:25:04 --> Severity: Notice --> Undefined variable: banking_details /var/www/travel_app/application/views/admin/capital_details.php 114
ERROR - 2018-12-11 14:25:04 --> Severity: Notice --> Undefined variable: banking_details /var/www/travel_app/application/views/admin/capital_details.php 157
ERROR - 2018-12-11 14:26:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 14:27:27 --> Severity: Notice --> Undefined variable: banking_details /var/www/travel_app/application/views/admin/capital_details.php 145
ERROR - 2018-12-11 14:27:54 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 14:27:54 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 14:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 117
ERROR - 2018-12-11 14:29:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 14:29:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 14:29:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 242
ERROR - 2018-12-11 14:29:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 243
ERROR - 2018-12-11 14:31:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:31:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:31:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 14:31:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 14:31:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:31:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:31:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 14:31:45 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 14:32:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:33:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:33:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 14:33:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 14:34:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 14:36:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:36:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 14:36:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 14:36:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 14:36:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:36:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:36:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 14:36:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 14:36:48 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 14:37:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:38:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 14:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 14:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 14:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 14:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 14:38:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 14:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 158
ERROR - 2018-12-11 14:41:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:43:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 158
ERROR - 2018-12-11 14:43:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 117
ERROR - 2018-12-11 14:44:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:44:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 117
ERROR - 2018-12-11 14:46:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 14:46:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 14:46:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 14:46:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:46:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:46:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 14:46:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 14:46:27 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 14:46:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:46:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:46:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 14:46:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 14:46:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 14:46:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:46:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 14:46:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 14:46:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 14:46:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 14:47:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 242
ERROR - 2018-12-11 14:47:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 243
ERROR - 2018-12-11 14:47:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:47:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:47:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 14:47:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 14:47:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:47:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:47:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 14:47:23 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 14:47:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 242
ERROR - 2018-12-11 14:47:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 243
ERROR - 2018-12-11 14:47:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:47:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:47:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:47:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 14:47:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 14:47:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:47:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:47:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 14:47:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 14:49:15 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:49:15 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:49:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:49:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:49:36 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:49:36 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:49:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:49:46 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:49:46 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:49:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:49:50 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:49:50 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:49:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:52:23 --> 404 Page Not Found: Booking/invoices
ERROR - 2018-12-11 14:52:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:52:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:52:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:52:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 14:52:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 14:52:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:52:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:52:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 14:52:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 14:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 14:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 14:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 14:54:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 14:54:32 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 14:54:32 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 14:54:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:54:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 14:54:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 14:54:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 14:54:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:54:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 14:54:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 14:54:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 14:55:23 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:55:23 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:55:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:55:26 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:55:26 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 256
ERROR - 2018-12-11 14:55:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 4 - Invalid query: SELECT *
FROM `travel_users`
WHERE `userId` != '12'
AND `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:55:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:55:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:56:14 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:56:14 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:56:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:56:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:57:31 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:57:31 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:57:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:57:36 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:57:36 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:57:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:57:42 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:57:42 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:57:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:57:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 14:59:43 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 14:59:43 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 14:59:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 14:59:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:01:56 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 15:01:56 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 15:02:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:02:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:02:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:02:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:02:15 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 15:02:15 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 15:02:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:02:22 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 15:02:22 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 15:02:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:02:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:02:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:02:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:03:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:03:03 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 15:03:03 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 15:03:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:03:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:04:01 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 15:04:01 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 15:04:12 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 15:04:12 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 15:04:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:05:00 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 15:05:00 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 15:05:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:05:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:05:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:05:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:05:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:05:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:05:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:05:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:05:20 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:05:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:05:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:05:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:05:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:05:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:05:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:05:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:05:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:05:56 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:05:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:05:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:05:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:05:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:05:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:05:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:06:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:06:04 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 125
ERROR - 2018-12-11 15:06:04 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 132
ERROR - 2018-12-11 15:06:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:06:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:07:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:07:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:07:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:07:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:07:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:07:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:07:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:07:09 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:07:21 --> 404 Page Not Found: Dashboard/index
ERROR - 2018-12-11 15:07:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:08:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:08:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:08:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:08:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:08:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:08:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:08:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:08:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:09:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:09:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:09:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:09:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:09:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:09:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:09:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:09:21 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:09:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:09:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 53
ERROR - 2018-12-11 15:09:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:09:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:09:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:09:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 179
ERROR - 2018-12-11 15:09:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 183
ERROR - 2018-12-11 15:09:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:10:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:10:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:10:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:10:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:10:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-11 15:10:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2018-12-11 15:10:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2018-12-11 15:10:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:10:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2018-12-11 15:11:06 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 15:11:06 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 15:11:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 15:11:28 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 15:11:28 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 15:11:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 15:13:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:13:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:13:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:13:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-11 15:13:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2018-12-11 15:13:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2018-12-11 15:13:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:13:10 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2018-12-11 15:13:31 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 15:13:31 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 15:13:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 15:14:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:14:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2018-12-11 15:14:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2018-12-11 15:14:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2018-12-11 15:14:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2018-12-11 15:14:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2018-12-11 15:14:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2018-12-11 15:14:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2018-12-11 15:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 15:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 15:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 15:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 15:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 15:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 15:16:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:17:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:17:26 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 15:17:26 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 15:17:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 15:17:28 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-11 15:17:28 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-11 15:17:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-11 15:19:09 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:19:09 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:21:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:22:50 --> Severity: Notice --> Undefined index: gender /var/www/travel_app/application/models/User_model.php 179
ERROR - 2018-12-11 15:22:50 --> Severity: Notice --> Undefined index: age /var/www/travel_app/application/models/User_model.php 180
ERROR - 2018-12-11 15:23:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:23:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:23:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:24:10 --> Severity: Notice --> Undefined index: gender /var/www/travel_app/application/models/User_model.php 179
ERROR - 2018-12-11 15:24:10 --> Severity: Notice --> Undefined index: age /var/www/travel_app/application/models/User_model.php 180
ERROR - 2018-12-11 15:25:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 15:25:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 15:25:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 15:25:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:25:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:25:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 15:25:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 15:25:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 15:25:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:26:00 --> Severity: Warning --> Missing argument 4 for Booking_model::accounts_payable(), called in /var/www/travel_app/application/controllers/Booking.php on line 282 and defined /var/www/travel_app/application/models/Booking_model.php 241
ERROR - 2018-12-11 15:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 15:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 15:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 15:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 15:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 15:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 15:33:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:33:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:33:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 15:33:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 15:33:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 15:33:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:33:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:33:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 15:33:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 15:33:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 15:34:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:34:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:34:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:03 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:03 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:09 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:09 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:13 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:13 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 15:35:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 15:35:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:35:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:36:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 15:36:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 15:36:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 15:36:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:36:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:36:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 15:36:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 15:36:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 15:36:59 --> Severity: Parsing Error --> syntax error, unexpected '$customers' (T_VARIABLE) /var/www/travel_app/application/controllers/Admin.php 406
ERROR - 2018-12-11 15:37:04 --> Severity: Parsing Error --> syntax error, unexpected '$customers' (T_VARIABLE) /var/www/travel_app/application/controllers/Admin.php 406
ERROR - 2018-12-11 15:37:05 --> Severity: Parsing Error --> syntax error, unexpected '$customers' (T_VARIABLE) /var/www/travel_app/application/controllers/Admin.php 406
ERROR - 2018-12-11 15:37:05 --> Severity: Parsing Error --> syntax error, unexpected '$customers' (T_VARIABLE) /var/www/travel_app/application/controllers/Admin.php 406
ERROR - 2018-12-11 15:37:05 --> Severity: Parsing Error --> syntax error, unexpected '$customers' (T_VARIABLE) /var/www/travel_app/application/controllers/Admin.php 406
ERROR - 2018-12-11 15:37:08 --> Severity: Parsing Error --> syntax error, unexpected '$customers' (T_VARIABLE) /var/www/travel_app/application/controllers/Admin.php 406
ERROR - 2018-12-11 15:40:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:40:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 15:40:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:40:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:40:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:40:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 15:42:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:42:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 15:42:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:42:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:42:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:42:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:42:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-11 15:43:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:45:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:45:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 15:45:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 15:45:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 15:45:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:45:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 15:45:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 15:45:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 15:45:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 15:46:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:46:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:46:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:46:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 15:47:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:47:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 15:47:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:47:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:51:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 15:59:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 16:00:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 16:00:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 16:00:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 16:00:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 16:00:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 16:00:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 16:00:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 16:00:05 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 16:00:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 16:01:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 16:01:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 16:02:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 16:02:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 16:04:00 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-11 16:04:17 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-11 16:04:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 246
ERROR - 2018-12-11 16:04:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 247
ERROR - 2018-12-11 16:04:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 246
ERROR - 2018-12-11 16:04:44 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 247
ERROR - 2018-12-11 16:05:42 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:05:47 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 246
ERROR - 2018-12-11 16:06:03 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 247
ERROR - 2018-12-11 16:06:10 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:06:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 16:07:04 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:07:06 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:08:46 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:08:55 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-11 16:08:55 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-11 16:08:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-11' and exp.`expenseDate` <='2018-12-11' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-11 16:11:01 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:44:40 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:46:30 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:46:33 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:46:34 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:48:08 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:49:51 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:49:54 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:50:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 16:50:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 16:51:40 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:51:59 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:52:23 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-11 16:52:23 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-11 16:52:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-11' and exp.`expenseDate` <='2018-12-11' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-11 16:53:01 --> 404 Page Not Found: Daybook/daily_transactions_admin
ERROR - 2018-12-11 16:53:13 --> 404 Page Not Found: Report/daily_transactions_admin
ERROR - 2018-12-11 16:53:20 --> 404 Page Not Found: Report/daily_transactions_admin
ERROR - 2018-12-11 16:55:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 16:55:11 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-11 16:55:11 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 25
ERROR - 2018-12-11 16:55:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and `bookingDate` >= '2018-12-11' and `bookingDate` <='2018-12-11' ORDER BY `b' at line 1 - Invalid query: SELECT sum(priceCash+creditPaid) as totTicket  FROM `travel_booking` WHERE `companyId` in () and `bookingDate` >= '2018-12-11' and `bookingDate` <='2018-12-11' ORDER BY `bookingId`  DESC
ERROR - 2018-12-11 16:55:23 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-11 16:55:23 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-11 16:55:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-11' and exp.`expenseDate` <='2018-12-11' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-11 16:55:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 16:56:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-11 16:56:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-11 16:59:06 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-11 16:59:06 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-11 16:59:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-11' and exp.`expenseDate` <='2018-12-11' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-11 16:59:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 17:07:23 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-11 17:07:23 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-11 17:07:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-11' and exp.`expenseDate` <='2018-12-11' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-11 17:18:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-11 17:18:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-11 17:20:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 17:20:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-11 17:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 158
ERROR - 2018-12-11 18:46:24 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/models/Booking_model.php 254
ERROR - 2018-12-11 18:46:24 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/models/Booking_model.php 254
ERROR - 2018-12-11 18:46:24 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/models/Booking_model.php 254
ERROR - 2018-12-11 18:46:24 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/models/Booking_model.php 254
ERROR - 2018-12-11 18:46:24 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/models/Booking_model.php 254
ERROR - 2018-12-11 18:46:24 --> Severity: Notice --> Undefined variable: row /var/www/travel_app/application/models/Booking_model.php 254
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 18:52:56 --> Severity: Notice --> Undefined index: forOnedDay /var/www/travel_app/application/models/Booking_model.php 256
ERROR - 2018-12-11 19:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 158
ERROR - 2018-12-11 19:00:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and date_format(tb.`createdAt`,'%Y-%m-%d') >= '2018-12-01' AND date_format(tb.' at line 1 - Invalid query: SELECT GROUP_CONCAT(CONCAT(companyId, ',', totcount) SEPARATOR '|') as points,createdAt FROM (SELECT tb.companyId,COUNT(tb.bookingId) as totcount,date_format(tb.createdAt,'%Y-%m-%d') as createdAt FROM `travel_booking` as tb WHERE tb.companyId in () and date_format(tb.`createdAt`,'%Y-%m-%d') >= '2018-12-01' AND date_format(tb.`createdAt`,'%Y-%m-%d') <= '2018-12-13' group by date_format(tb.`createdAt`,'%Y-%m-%d'),tb.companyId) t group by date_format(`createdAt`,'%Y-%m-%d')
ERROR - 2018-12-11 19:04:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-11 19:15:29 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/models/User_model.php 236
ERROR - 2018-12-11 19:31:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:33:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:35:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:35:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:36:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:46:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:49:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-11 19:52:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:52:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:53:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-11 19:53:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:53:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-11 19:53:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:53:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:54:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 19:54:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 91
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 20:08:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 20:13:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-11 20:13:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-11 20:21:31 --> Severity: Notice --> Undefined variable: expenseList /var/www/travel_app/application/models/Booking_model.php 257
ERROR - 2018-12-11 20:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/models/Booking_model.php 257
ERROR - 2018-12-11 20:21:31 --> Severity: Notice --> Undefined variable: expenseList /var/www/travel_app/application/models/Booking_model.php 263
ERROR - 2018-12-11 20:55:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 20:55:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 20:55:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 20:55:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 20:55:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 20:55:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 20:55:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 20:55:43 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 20:57:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-11 20:57:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-11 20:57:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-11 20:57:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 20:57:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-11 20:57:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-11 20:57:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-11 20:57:35 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-11 21:08:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 21:13:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 21:15:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 21:17:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 21:19:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 21:21:34 --> Severity: Notice --> Undefined variable: totReceive /var/www/travel_app/application/views/user/balance_sheet.php 177
ERROR - 2018-12-11 21:21:34 --> Severity: Notice --> Undefined variable: totReceive /var/www/travel_app/application/views/user/balance_sheet.php 177
ERROR - 2018-12-11 21:21:34 --> Severity: Notice --> Undefined variable: totReceive /var/www/travel_app/application/views/user/balance_sheet.php 197
ERROR - 2018-12-11 21:21:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-11 21:23:04 --> Severity: Notice --> Undefined variable: totReceive /var/www/travel_app/application/views/user/balance_sheet.php 197
ERROR - 2018-12-11 21:23:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 21:23:30 --> Severity: Notice --> Undefined variable: totReceive /var/www/travel_app/application/views/user/balance_sheet.php 197
ERROR - 2018-12-11 21:24:27 --> Severity: Notice --> Undefined variable: totReceive /var/www/travel_app/application/views/user/balance_sheet.php 197
ERROR - 2018-12-11 21:24:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-11 21:24:52 --> Severity: Notice --> Undefined variable: totReceive /var/www/travel_app/application/views/user/balance_sheet.php 197
