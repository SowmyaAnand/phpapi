<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-29 11:18:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 11:21:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:21:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:21:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:21:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 11:26:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:26:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:26:25 --> 404 Page Not Found: Daybook/daybook
ERROR - 2018-11-29 11:35:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:35:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:35:57 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/daily_transactions.php 6
ERROR - 2018-11-29 11:40:12 --> 404 Page Not Found: Login/index
ERROR - 2018-11-29 11:40:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:40:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:40:25 --> 404 Page Not Found: Login/index
ERROR - 2018-11-29 11:40:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:40:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:40:55 --> Severity: Notice --> Undefined property: Daybook::$fee_model /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:40:55 --> Severity: Error --> Call to a member function daily_expense_per_date() on null /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:44:25 --> Severity: Notice --> Undefined property: Daybook::$fee_model /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:44:25 --> Severity: Error --> Call to a member function daily_expense_per_date() on null /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:44:26 --> Severity: Notice --> Undefined property: Daybook::$fee_model /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:44:26 --> Severity: Error --> Call to a member function daily_expense_per_date() on null /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:44:28 --> Severity: Notice --> Undefined property: Daybook::$fee_model /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:44:28 --> Severity: Error --> Call to a member function daily_expense_per_date() on null /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:44:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:44:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 11:44:36 --> Severity: Notice --> Undefined property: Daybook::$fee_model /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:44:36 --> Severity: Error --> Call to a member function daily_expense_per_date() on null /var/www/travel_app/application/controllers/Daybook.php 315
ERROR - 2018-11-29 11:45:00 --> Query error: Table 'travel_app_db.expenses' doesn't exist - Invalid query: SELECT *
FROM `expenses`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = '2018-11-29'
ORDER BY `created_at` DESC
ERROR - 2018-11-29 11:45:52 --> Query error: Table 'travel_app_db.fee' doesn't exist - Invalid query: SELECT `total_fee` as `amount`, `student_id` as `paid_by`, `remarks` as `particulars`, `receipt_no`, `created` as `created_date`
FROM `fee`
WHERE DATE_FORMAT(created,'%Y-%m-%d') = '2018-11-29'
AND `payment_type` = 'cash'
ORDER BY `created` DESC
ERROR - 2018-11-29 11:54:54 --> Query error: Unknown column 'created' in 'where clause' - Invalid query: SELECT *
FROM `expense`
WHERE DATE_FORMAT(created,'%Y-%m-%d') = '2018-11-29'
AND `payment_type` = 'cash'
ORDER BY `created_at` DESC
ERROR - 2018-11-29 11:55:47 --> Query error: Table 'travel_app_db.cash_balance' doesn't exist - Invalid query: SELECT *
FROM `cash_balance`
WHERE `created_at` = '29/11/2018'
ERROR - 2018-11-29 12:05:43 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/daily_transactions.php 6
ERROR - 2018-11-29 12:10:07 --> Severity: Error --> Call to undefined function get_phrase() /var/www/travel_app/application/views/user/daily_transactions.php 6
ERROR - 2018-11-29 12:10:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 12:16:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 12:16:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 12:17:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 12:23:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:24:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:24:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:24:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:24:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 195
ERROR - 2018-11-29 12:25:07 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 199
ERROR - 2018-11-29 12:25:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:26:35 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:26:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 133
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: amount /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:26:41 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:26:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:29:11 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:29:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:32:03 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:32:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:32:23 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:32:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:32:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:33:38 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:33:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:34:30 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:34:30 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:34:30 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:34:30 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:34:30 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:34:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:35:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:35:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 12:35:30 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:35:30 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:35:30 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:35:30 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/daily_transactions.php 192
ERROR - 2018-11-29 12:35:30 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:35:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 12:35:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:39:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:39:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 12:40:34 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:40:34 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:40:34 --> Severity: Notice --> Undefined index: paid_by /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:40:34 --> Severity: Notice --> Undefined index: particulars /var/www/travel_app/application/views/user/daily_transactions.php 194
ERROR - 2018-11-29 12:40:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 12:40:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:43:46 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:43:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:43:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:43:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:43:48 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:43:48 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:43:48 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:43:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:45:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:45:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:45:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:46:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:46:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:46:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 12:49:21 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:49:21 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:49:21 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:51:18 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:51:18 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:51:18 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:51:32 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:51:32 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:51:32 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:51:39 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:51:39 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:51:39 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:57:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM `income`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = '2018-11-29'
ORDER BY' at line 1 - Invalid query: SELECT `amount`, `description`, `cash_from` as `paid_by`, `voucher_no` as `receipt_no`, `created_at`, `payment_type`, *
FROM `income`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = '2018-11-29'
ORDER BY `created_at` DESC
ERROR - 2018-11-29 12:57:33 --> Query error: Unknown column 'amount' in 'field list' - Invalid query: SELECT `amount`, `description`, `cash_from` as `paid_by`, `voucher_no` as `receipt_no`, `created_at`, `payment_type`
FROM `income`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = '2018-11-29'
ORDER BY `created_at` DESC
ERROR - 2018-11-29 12:58:08 --> Query error: Unknown column 'voucher_no' in 'field list' - Invalid query: SELECT `credit` as `debit`, `description`, `cash_from` as `paid_by`, `voucher_no` as `receipt_no`, `created_at`, `payment_type`
FROM `income`
WHERE DATE_FORMAT(created_at,'%Y-%m-%d') = '2018-11-29'
ORDER BY `created_at` DESC
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 12:59:46 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 13:00:26 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 13:01:59 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:13:04 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:15:48 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:15:48 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:15:48 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:19:14 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:19:14 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:19:14 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:19:14 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:19:14 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:20:11 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 134
ERROR - 2018-11-29 14:21:15 --> Severity: Notice --> Undefined index: credit /var/www/travel_app/application/views/user/daily_transactions.php 137
ERROR - 2018-11-29 14:22:47 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:22:47 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:22:47 --> Severity: Notice --> Undefined index: cash_from /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: receipt_no /var/www/travel_app/application/views/user/daily_transactions.php 131
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:24:38 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:25:21 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:48:28 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:50:00 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/daily_transactions.php 132
ERROR - 2018-11-29 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-29 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-29 14:53:34 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-29 14:53:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-29 14:53:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-29 14:54:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 109
ERROR - 2018-11-29 14:54:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 117
ERROR - 2018-11-29 14:54:27 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 127
ERROR - 2018-11-29 14:54:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-29 14:54:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 139
ERROR - 2018-11-29 14:55:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 14:55:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 14:55:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 14:55:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 15:47:05 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 44
ERROR - 2018-11-29 15:47:05 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 46
ERROR - 2018-11-29 15:47:05 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 94
ERROR - 2018-11-29 15:58:20 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/travel_app/application/views/user/customer_travel.php 97
ERROR - 2018-11-29 15:58:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:22:07 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/travel_app/application/views/user/customer_travel.php 95
ERROR - 2018-11-29 16:22:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:22:24 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/travel_app/application/views/user/customer_travel.php 95
ERROR - 2018-11-29 16:22:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:28:55 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/travel_app/application/views/user/customer_travel.php 95
ERROR - 2018-11-29 16:28:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:29:03 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/travel_app/application/views/user/customer_travel.php 95
ERROR - 2018-11-29 16:29:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:30:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:30:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:31:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:31:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:45:54 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 98
ERROR - 2018-11-29 16:45:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:47:02 --> Severity: Notice --> Undefined variable: users /var/www/travel_app/application/views/user/customer_travel.php 121
ERROR - 2018-11-29 16:47:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:47:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:48:20 --> Severity: Notice --> Undefined variable: users /var/www/travel_app/application/views/user/customer_travel.php 119
ERROR - 2018-11-29 16:48:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:48:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:49:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:49:58 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 44
ERROR - 2018-11-29 16:49:58 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 46
ERROR - 2018-11-29 16:49:58 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 94
ERROR - 2018-11-29 16:50:03 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 44
ERROR - 2018-11-29 16:50:03 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 46
ERROR - 2018-11-29 16:50:03 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 94
ERROR - 2018-11-29 16:50:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 16:50:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 16:50:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:50:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:50:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:51:23 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 44
ERROR - 2018-11-29 16:51:23 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 46
ERROR - 2018-11-29 16:51:23 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/daily_transactions.php 94
ERROR - 2018-11-29 16:51:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:51:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:52:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:52:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:52:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:52:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:52:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:54:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:54:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:54:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 16:54:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:54:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:54:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 16:54:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:54:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:55:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:55:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:55:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:55:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:55:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 16:55:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 16:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-29 17:11:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 18:41:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 18:41:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 18:42:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 18:51:03 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/travel_app/application/controllers/Daybook.php 42
ERROR - 2018-11-29 18:52:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-29 19:25:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 19:35:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 19:36:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:43:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-29 19:43:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:44:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-29 19:44:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:45:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-29 19:45:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 108
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 116
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/transaction_report.php 126
ERROR - 2018-11-29 19:47:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-29 19:47:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 138
ERROR - 2018-11-29 19:48:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 19:48:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:48:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 19:48:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:49:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 19:49:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 107
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined index: voucher_id /var/www/travel_app/application/views/user/income_report.php 115
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: modules /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined variable: login_data /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/travel_app/application/views/user/income_report.php 120
ERROR - 2018-11-29 19:50:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 19:50:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 142
ERROR - 2018-11-29 20:49:21 --> Severity: Parsing Error --> syntax error, unexpected '$', expecting ',' or ';' /var/www/travel_app/application/views/user/expenses.php 84
ERROR - 2018-11-29 20:49:48 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting variable (T_VARIABLE) or '$' /var/www/travel_app/application/views/user/expenses.php 84
