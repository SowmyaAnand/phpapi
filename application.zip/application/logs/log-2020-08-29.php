<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-29 02:33:05 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 215
ERROR - 2020-08-29 15:29:02 --> Severity: Notice --> Undefined index: image /home/dailyest/public_html/dailyestore/application/controllers/Api.php 434
ERROR - 2020-08-29 15:29:02 --> Query error: Column 'image' cannot be null - Invalid query: INSERT INTO `itemdetails` (`typeId`, `subId`, `itemTypeName`, `subName`, `itemName`, `description`, `quantity`, `price`, `status`, `image`, `createdBy`) VALUES ('1', '1', 'Food', 'Bakers', 'HPLaptop', 'laptops', '1', '60000', '1', NULL, 'sowmya')
ERROR - 2020-08-29 15:40:35 --> Severity: Notice --> Undefined index: image /home/dailyest/public_html/dailyestore/application/controllers/Api.php 434
ERROR - 2020-08-29 15:40:35 --> Query error: Column 'image' cannot be null - Invalid query: INSERT INTO `itemdetails` (`typeId`, `subId`, `itemTypeName`, `subName`, `itemName`, `description`, `quantity`, `price`, `status`, `image`, `createdBy`) VALUES ('1', '1', 'Food', 'Bakers', 'HP', 'test', '1', '250', '1', NULL, 'sowmya')
ERROR - 2020-08-29 15:58:55 --> Severity: Notice --> Undefined index: image /home/dailyest/public_html/dailyestore/application/controllers/Api.php 434
ERROR - 2020-08-29 15:58:55 --> Query error: Column 'image' cannot be null - Invalid query: INSERT INTO `itemdetails` (`typeId`, `subId`, `itemTypeName`, `subName`, `itemName`, `description`, `quantity`, `price`, `status`, `image`, `createdBy`) VALUES ('1', '1', 'Food', 'Bakers', 'HPLaptop', 'laptops', '1', '60000', '1', NULL, '1')
ERROR - 2020-08-29 20:34:58 --> 404 Page Not Found: Api/conatactUs
ERROR - 2020-08-29 20:35:30 --> 404 Page Not Found: Api/conatactUs
