<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-16 19:57:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 19:57:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-16 19:58:31 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 19:58:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 19:58:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 19:58:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:03:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:05:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:05:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:06:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:06:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:07:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:07:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:10:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:10:14 --> 404 Page Not Found: Customer_travel_report/index
ERROR - 2019-01-16 20:10:48 --> 404 Page Not Found: Customer_travel_report/index
ERROR - 2019-01-16 20:10:51 --> 404 Page Not Found: Customer_travel_report/index
ERROR - 2019-01-16 20:10:56 --> 404 Page Not Found: Customer_travel_report/index
ERROR - 2019-01-16 20:12:34 --> 404 Page Not Found: Customer_travel_report/index
ERROR - 2019-01-16 20:12:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:12:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:12:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:14:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:15:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:16:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:17:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:18:31 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:18:34 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:22:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:22:29 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/user/air_travel_report.php 69
ERROR - 2019-01-16 20:22:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/air_travel_report.php 69
ERROR - 2019-01-16 20:22:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:25:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:25:10 --> Severity: Compile Error --> Cannot redeclare Report::get_all_company() /var/www/travel_app/application/controllers/Report.php 342
ERROR - 2019-01-16 20:25:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:25:53 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-16 20:25:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-16 20:28:37 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-16 20:28:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-16 20:28:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:30:33 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-16 20:30:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-16 20:30:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 20:31:33 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-16 20:31:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-16 20:31:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-01-16 21:05:30 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-16 21:05:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-16 21:05:30 --> 404 Page Not Found: Assets/img
