<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-10 16:11:42 --> 404 Page Not Found: Daybook/index.html
ERROR - 2019-01-10 16:11:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 16:12:12 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-10 16:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-10 16:12:12 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-10 16:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-10 16:14:29 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 16:15:30 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 16:15:55 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 16:46:52 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:04:45 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:04:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 17:20:17 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:28:31 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:28:37 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:31:27 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:31:33 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:31:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 17:31:44 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:32:13 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:32:27 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:32:31 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:33:19 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:33:26 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:33:32 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:33:42 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:34:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 17:34:27 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:34:47 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:34:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 17:34:53 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:35:05 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:37:17 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:37:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-10 17:38:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 17:41:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 17:41:32 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:42:41 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:44:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 17:44:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-10 17:44:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 233
ERROR - 2019-01-10 17:53:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:56:28 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 17:57:40 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 18:00:59 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 18:01:37 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 18:02:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 18:02:56 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 18:03:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 18:07:29 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-10 18:07:29 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-10 18:07:29 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-10 18:07:29 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-10 18:07:29 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-10 18:07:29 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-10 18:07:29 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-10 18:07:29 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-10 18:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-10 18:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-10 18:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-10 18:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-10 18:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-10 18:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-10 18:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-10 18:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-10 19:19:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 19:20:30 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 19:20:33 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 19:20:36 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 19:20:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 19:20:44 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-10 19:20:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 19:30:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-10 19:57:19 --> Query error: Duplicate entry '0' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('jgjgjgj', 'ggjgj', 'gjgjgj', '46464646', 'gjgjgj@fs.fsf', '')
ERROR - 2019-01-10 20:01:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
