<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-01 08:57:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 08:57:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 08:57:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 08:58:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 08:58:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 08:59:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 08:59:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 09:00:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 09:00:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 09:00:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 09:01:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 09:01:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 09:30:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 09:30:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 09:30:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 09:30:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 09:32:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 09:32:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 09:36:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:36:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:36:31 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:36:31 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:37:13 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:37:13 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:37:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:37:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: voucher_no /var/www/travel_app/application/views/user/edit_income.php 85
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:39:34 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/edit_income.php 125
ERROR - 2018-12-01 09:40:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:40:50 --> Severity: Notice --> Undefined index: pay_to /var/www/travel_app/application/views/user/edit_income.php 125
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:41:29 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_income.php 114
ERROR - 2018-12-01 09:46:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:46:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:46:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:46:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:48:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 09:48:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 09:48:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-01 09:49:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:17 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:17 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:49:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:50:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:50:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:50:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 09:50:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-01 09:50:31 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:50:31 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:50:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:50:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:51:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:51:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:51:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:51:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 09:54:06 --> Query error: Unknown column 'receipt_no' in 'field list' - Invalid query: UPDATE `expense` SET `customerId` = '1', `companyId` = '101', `receipt_no` = 'IN1506044921', `incomId` = '16', `incomeType` = '6', `cash_from` = 'jithin', `phone` = '2147483647', `credit` = '250', `payment_type` = 'cash', `bank_name` = 'Canara', `chequeno` = '123', `dd_date` = '2018-11-07', `description` = 'Fee', `approved_by` = 'User ABC'
WHERE `incomId` = '16'
ERROR - 2018-12-01 09:56:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 09:56:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-01 10:00:00 --> Query error: Unknown column 'receipt_no' in 'field list' - Invalid query: UPDATE `expense` SET `customerId` = '1', `companyId` = '101', `receipt_no` = 'IN1506044921', `incomId` = '16', `incomeType` = '6', `cash_from` = 'jithin', `phone` = '2147483647', `credit` = '250', `payment_type` = 'cash', `bank_name` = 'Canara', `chequeno` = '123', `dd_date` = '2018-11-07', `description` = 'Fee', `approved_by` = 'User ABC'
WHERE `incomId` = '16'
ERROR - 2018-12-01 10:00:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 10:00:30 --> Query error: Unknown column 'receipt_no' in 'field list' - Invalid query: UPDATE `expense` SET `customerId` = '1', `companyId` = '101', `receipt_no` = 'IN1506044921', `incomId` = '16', `incomeType` = '6', `cash_from` = 'jithin', `phone` = '2147483647', `credit` = '250', `payment_type` = 'cash', `bank_name` = 'Canara', `chequeno` = '123', `dd_date` = '2018-11-07', `description` = 'Fee', `approved_by` = 'User ABC'
WHERE `incomId` = '16'
ERROR - 2018-12-01 10:00:48 --> Query error: Unknown column 'receipt_no' in 'field list' - Invalid query: UPDATE `expense` SET `customerId` = '1', `companyId` = '101', `receipt_no` = 'IN1774629349', `incomId` = '19', `incomeType` = '6', `cash_from` = 'Test income2', `phone` = '2147483647', `credit` = '5000', `payment_type` = 'cheque', `bank_name` = 'Canara', `chequeno` = 'sad', `dd_date` = '2018-11-29', `description` = 'cheque', `approved_by` = 'User ABC'
WHERE `incomId` = '19'
ERROR - 2018-12-01 10:01:36 --> Query error: Unknown column 'receipt_no' in 'field list' - Invalid query: UPDATE `expense` SET `customerId` = '1', `companyId` = '101', `receipt_no` = 'IN1774629349', `incomId` = '19', `incomeType` = '6', `cash_from` = 'Test income2', `phone` = '2147483647', `credit` = '5000', `payment_type` = 'cash', `bank_name` = 'Canara', `chequeno` = 'sad', `dd_date` = '2018-11-29', `description` = 'cheque', `approved_by` = 'User ABC'
WHERE `incomId` = '19'
ERROR - 2018-12-01 10:02:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 10:02:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-01 10:02:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 10:03:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 10:04:43 --> Query error: Unknown column 'approved_by' in 'field list' - Invalid query: UPDATE `income` SET `customerId` = '1', `companyId` = '101', `receipt_no` = 'IN1774629349', `incomId` = '19', `incomeType` = '6', `cash_from` = 'Test income2', `phone` = '2147483647', `credit` = '5000', `payment_type` = 'cash', `bank_name` = 'Canara', `chequeno` = 'sad', `dd_date` = '2018-11-29', `description` = 'cheque', `approved_by` = 'User ABC'
WHERE `incomId` = '19'
ERROR - 2018-12-01 10:05:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 10:05:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 10:07:19 --> Query error: Unknown column 'receipt_no' in 'field list' - Invalid query: UPDATE `expense` SET `customerId` = '1', `companyId` = '101', `receipt_no` = 'IN1506044921', `incomId` = '16', `incomeType` = '6', `cash_from` = 'jithin', `phone` = '2147483647', `credit` = '250', `payment_type` = 'cash', `bank_name` = 'Canara', `chequeno` = '123', `dd_date` = '2018-11-07', `description` = 'Fee', `approved_by` = 'User ABC'
WHERE `incomId` = '16'
ERROR - 2018-12-01 10:07:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:07:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:11:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:11:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:11:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:11:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:11:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 10:11:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-01 10:11:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:11:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:11:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:11:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 169
ERROR - 2018-12-01 10:13:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 10:13:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 10:13:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 10:13:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 163
ERROR - 2018-12-01 10:14:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 10:14:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 10:15:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 10:15:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-01 10:15:28 --> Query error: Unknown column 'receipt_no' in 'field list' - Invalid query: UPDATE `expense` SET `customerId` = '1', `companyId` = '101', `receipt_no` = 'IN1506044921', `incomId` = '16', `incomeType` = '6', `cash_from` = 'jithin', `phone` = '2147483647', `credit` = '250', `payment_type` = 'cash', `bank_name` = 'Canara', `chequeno` = '123', `dd_date` = '2018-11-07', `description` = 'Fee', `approved_by` = 'User ABC'
WHERE `incomId` = '16'
ERROR - 2018-12-01 10:15:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 10:15:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 10:15:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 10:17:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:17:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:17:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:17:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:18:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:18:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:18:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:18:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:18:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 10:18:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 10:20:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:20:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:21:03 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:21:03 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 10:21:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 10:21:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 10:27:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 10:27:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-01 10:29:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 10:29:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-01 10:53:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 11:23:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:23:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:47:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:47:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:47:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:47:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:48:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:48:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:48:25 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:48:25 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:50:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:50:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:52:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:52:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:52:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:52:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:57:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:57:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:57:32 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:57:32 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 11:59:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:59:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:59:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:59:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:59:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:59:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:59:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 11:59:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 168
ERROR - 2018-12-01 12:02:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 12:02:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 12:03:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 12:03:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 12:27:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 189
ERROR - 2018-12-01 12:27:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 189
ERROR - 2018-12-01 12:28:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 191
ERROR - 2018-12-01 12:28:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 191
ERROR - 2018-12-01 12:29:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:29:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:29:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:29:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:30:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:30:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:30:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:30:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:30:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:30:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 196
ERROR - 2018-12-01 12:31:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:31:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:31:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:31:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:32:03 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:32:03 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:32:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:32:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:33:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:33:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:33:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:33:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:33:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 12:33:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 162
ERROR - 2018-12-01 12:34:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-12-01 12:34:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-12-01 12:34:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-12-01 12:34:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-12-01 12:35:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-12-01 12:35:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-12-01 12:35:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-12-01 12:35:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 182
ERROR - 2018-12-01 12:36:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 189
ERROR - 2018-12-01 12:36:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 189
ERROR - 2018-12-01 12:36:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 189
ERROR - 2018-12-01 12:36:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 189
ERROR - 2018-12-01 12:37:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:37:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:48:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:48:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 12:56:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 12:56:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 12:58:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 13:01:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 13:01:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 13:06:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 13:11:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 13:29:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 13:29:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 13:31:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 13:34:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 13:34:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 13:34:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 13:45:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 13:45:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 13:46:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 14:37:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 189
ERROR - 2018-12-01 14:37:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 189
ERROR - 2018-12-01 14:40:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 14:43:31 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 14:43:31 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 206
ERROR - 2018-12-01 14:44:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 189
ERROR - 2018-12-01 14:44:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 189
ERROR - 2018-12-01 14:50:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:50:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:50:50 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:50:50 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:51:22 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:51:22 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:51:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 14:52:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 14:53:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:53:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:53:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 14:54:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 14:55:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:55:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:56:34 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) /var/www/travel_app/application/views/user/edit_expense.php 114
ERROR - 2018-12-01 14:58:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 14:58:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:05:49 --> Severity: Notice --> Undefined index: expenseType /var/www/travel_app/application/views/user/edit_expense.php 121
ERROR - 2018-12-01 15:08:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:08:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:09:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:09:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:09:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:09:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:09:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:09:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:09:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:09:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:09:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:09:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:13:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:17:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:17:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:17:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:17:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:17:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:18:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:18:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:18:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:18:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:18:54 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:19:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 15:19:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 15:19:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:19:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:19:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:19:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:19:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 15:20:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-01 15:20:45 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:20:45 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:21:30 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:21:30 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:22:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:22:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:23:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:23:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:23:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:23:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:23:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:23:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:27:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:27:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:27:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:27:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:29:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:29:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:29:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:29:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:30:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:30:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:30:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:30:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:31:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:31:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:31:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:31:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:31:23 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:31:23 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:31:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:31:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:31:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:31:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:32:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:32:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:34:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:34:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:34:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:34:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:35:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:35:17 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:35:17 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 15:35:25 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:35:25 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:35:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:35:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:36:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:36:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:36:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:36:29 --> Severity: Notice --> Undefined variable: user /var/www/travel_app/application/models/Daybook_model.php 229
ERROR - 2018-12-01 15:36:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:36:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:36:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:36:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:36:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:39:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:40:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:42:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:42:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:42:55 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:42:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:44:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 15:44:09 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 15:44:09 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:00:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:00:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:13:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 16:13:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 16:45:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:19 --> Severity: Notice --> Undefined variable: user /var/www/travel_app/application/models/Daybook_model.php 230
ERROR - 2018-12-01 16:45:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:44 --> Severity: Notice --> Undefined variable: user /var/www/travel_app/application/models/Daybook_model.php 230
ERROR - 2018-12-01 16:45:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:45:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:46:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:46:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:46:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:46:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:46:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:46:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:46:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:46:42 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:47:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:47:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-01 16:50:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 16:51:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 16:53:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 16:56:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 16:56:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 16:57:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 16:58:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 16:59:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 16:59:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 17:00:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 273
ERROR - 2018-12-01 17:00:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 17:38:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-01 17:38:25 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 17:38:25 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-01 17:39:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
