<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-25 13:20:33 --> Severity: Notice --> Undefined variable: total_questions C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 21
ERROR - 2020-06-25 13:20:33 --> Severity: Notice --> Undefined variable: total_polls C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 50
ERROR - 2020-06-25 13:20:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 13:20:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 13:20:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 13:20:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 13:21:58 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-06-25 13:21:58 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-06-25 13:21:58 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-06-25 13:21:59 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-06-25 13:21:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 13:23:33 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-06-25 13:23:33 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-06-25 13:23:33 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-06-25 13:23:34 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 90
ERROR - 2020-06-25 13:23:34 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 13:30:36 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 13:38:05 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 13:41:49 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 13:42:27 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 13:43:23 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 15:14:20 --> Severity: Notice --> Undefined variable: total_questions C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 21
ERROR - 2020-06-25 15:14:20 --> Severity: Notice --> Undefined variable: total_polls C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 50
ERROR - 2020-06-25 15:14:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:14:27 --> Severity: Notice --> Undefined variable: total_questions C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 21
ERROR - 2020-06-25 15:14:27 --> Severity: Notice --> Undefined variable: total_polls C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 50
ERROR - 2020-06-25 15:14:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:14:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:15:17 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-25 15:15:17 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-25 15:15:17 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-25 15:15:17 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-25 15:15:17 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-25 15:15:17 --> Severity: Notice --> Undefined variable: total_cash C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-25 15:15:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:15:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:16:58 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-25 15:16:58 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-25 15:16:58 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-25 15:16:58 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-25 15:16:58 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-25 15:16:58 --> Severity: Notice --> Undefined variable: total_cash C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-25 15:16:58 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:17:04 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-25 15:17:04 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-25 15:17:04 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-25 15:17:04 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-25 15:17:04 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-25 15:17:04 --> Severity: Notice --> Undefined variable: total_cash C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-25 15:17:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:17:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:17:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:28:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:29:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:31:50 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:31:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:32:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:34:58 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:35:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:35:40 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:36:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:36:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:38:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:38:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:39:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:39:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:41:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:43:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:43:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:44:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:44:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:45:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:45:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:45:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:45:34 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 15:49:58 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:50:41 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 15:52:25 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 15:52:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:52:44 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 15:52:44 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 15:52:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 16:00:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 16:01:05 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 16:42:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 17:00:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 17:00:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 17:17:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 17:20:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 17:21:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 17:21:14 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 17:52:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:34:34 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:37:29 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\assignment\application\views\admin\edit_question.php 37
ERROR - 2020-06-25 18:38:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:40:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:40:31 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:42:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:42:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:42:57 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 18:43:01 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 18:43:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:43:45 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 18:43:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:43:57 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 18:43:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:45:10 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-25 18:45:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-25 18:45:36 --> 404 Page Not Found: Assets/img
