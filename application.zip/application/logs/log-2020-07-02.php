<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-02 12:51:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 12:51:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 12:52:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 12:59:41 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 12:59:46 --> Query error: Table 'ipoll.questionnaire' doesn't exist - Invalid query: SELECT *
FROM `questionnaire`
ERROR - 2020-07-02 13:02:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 13:02:52 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\ipoll\application\views\admin\list_questionnaire.php 71
ERROR - 2020-07-02 13:02:52 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\list_questionnaire.php 74
ERROR - 2020-07-02 13:02:52 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\ipoll\application\views\admin\list_questionnaire.php 74
ERROR - 2020-07-02 13:02:52 --> Severity: Notice --> Undefined index: qId C:\xampp\htdocs\ipoll\application\views\admin\list_questionnaire.php 86
ERROR - 2020-07-02 13:02:52 --> Severity: Notice --> Undefined index: qId C:\xampp\htdocs\ipoll\application\views\admin\list_questionnaire.php 87
ERROR - 2020-07-02 13:02:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 13:05:07 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 13:06:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 13:06:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 13:29:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 13:32:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-02 22:44:49 --> 404 Page Not Found: Assets/img
