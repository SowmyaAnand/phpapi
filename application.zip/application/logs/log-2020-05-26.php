<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-26 12:38:39 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-26 12:38:39 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 12:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 12:38:39 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-26 12:38:39 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 12:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 12:38:39 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-26 12:38:39 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 12:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 12:38:40 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 14:41:10 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-26 14:41:10 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 14:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 14:41:10 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-26 14:41:10 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 14:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 14:41:10 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-26 14:41:10 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 14:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 14:41:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 14:41:59 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-26 14:41:59 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 14:41:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 14:41:59 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-26 14:41:59 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 14:41:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 14:41:59 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-26 14:41:59 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 14:41:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 14:41:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 14:42:34 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\assignment\application\controllers\Welcome.php 699
ERROR - 2020-05-26 14:42:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT *
FROM `travel_company`
WHERE `companyId` in()
ERROR - 2020-05-26 14:42:37 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-26 14:42:37 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 14:42:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 14:42:37 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-26 14:42:37 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 14:42:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 14:42:37 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-26 14:42:37 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 14:42:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 14:42:43 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\assignment\application\models\Admin_model.php 119
ERROR - 2020-05-26 14:42:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2020-05-26 14:42:46 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-26 14:42:46 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 14:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-26 14:42:46 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-26 14:42:46 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 14:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-26 14:42:46 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-26 14:42:46 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 14:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-26 14:42:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 14:42:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 21:19:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 335
ERROR - 2020-05-26 21:19:14 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 21:19:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 21:24:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 21:24:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 22:08:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 22:09:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 22:11:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 22:11:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 22:11:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 22:11:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 22:11:58 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:14:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:14:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:26:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:26:34 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:27:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:27:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:29:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:30:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:31:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:32:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:34:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:43:53 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-26 23:43:53 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-26 23:43:53 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 57
ERROR - 2020-05-26 23:43:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:46:49 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:46:49 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:46:49 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:46:49 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:48:16 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:48:16 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:48:16 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:48:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:50:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-26 23:51:21 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:51:21 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:51:21 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\assignment\application\views\admin\list_questions.php 59
ERROR - 2020-05-26 23:51:22 --> 404 Page Not Found: Assets/img
