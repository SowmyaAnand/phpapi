<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-10 09:28:51 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-10 09:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-10 09:30:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 158
ERROR - 2018-12-10 09:30:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-10 09:34:06 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-10 09:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-10 09:37:03 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-10 09:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-10 09:37:35 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-10 09:37:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_customer.php 197
ERROR - 2018-12-10 09:46:05 --> Query error: Unknown column 'userEmail' in 'where clause' - Invalid query: SELECT `travel_company`.`companyId`, `travel_company`.`companyName`
FROM `travel_customer`
LEFT JOIN `travel_company` ON `travel_company`.`companyId`=`travel_company`.`companyId`
WHERE `userEmail` = 'Dr@dr.com'
ERROR - 2018-12-10 09:47:20 --> Query error: Unknown column 'userEmail' in 'where clause' - Invalid query: SELECT `travel_company`.`companyId`, `travel_company`.`companyName`
FROM `travel_customer`
LEFT JOIN `travel_company` ON `travel_company`.`companyId`=`travel_company`.`companyId`
WHERE `userEmail` = 'Dr@dr.com'
ERROR - 2018-12-10 09:47:59 --> Severity: Notice --> Undefined variable: userId /var/www/travel_app/application/controllers/Admin.php 126
ERROR - 2018-12-10 09:47:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 129
ERROR - 2018-12-10 09:47:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 130
ERROR - 2018-12-10 09:47:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 131
ERROR - 2018-12-10 09:47:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 132
ERROR - 2018-12-10 09:47:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 133
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 09:58:35 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 10:09:23 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/travel_app/application/controllers/Admin.php 127
ERROR - 2018-12-10 10:09:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-10 10:09:52 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/travel_app/application/controllers/Admin.php 127
ERROR - 2018-12-10 10:09:53 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/travel_app/application/controllers/Admin.php 127
ERROR - 2018-12-10 10:21:20 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/travel_app/application/controllers/Admin.php 122
ERROR - 2018-12-10 10:27:41 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 10:27:41 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 10:28:54 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/edit_customer.php 277
ERROR - 2018-12-10 10:29:27 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/admin/edit_customer.php 277
ERROR - 2018-12-10 10:29:44 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 202
ERROR - 2018-12-10 10:29:44 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 202
ERROR - 2018-12-10 10:30:38 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 203
ERROR - 2018-12-10 10:30:38 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 203
ERROR - 2018-12-10 10:30:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-10 10:31:43 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 203
ERROR - 2018-12-10 10:31:43 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 203
ERROR - 2018-12-10 10:43:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 131
ERROR - 2018-12-10 10:44:01 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 131
ERROR - 2018-12-10 10:44:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 131
ERROR - 2018-12-10 10:46:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Admin.php 131
ERROR - 2018-12-10 10:47:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:47:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:47:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:48:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:48:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:52:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:54:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:54:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:54:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:54:54 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 10:54:54 --> Severity: Notice --> Undefined variable: companyId /var/www/travel_app/application/views/admin/edit_customer.php 200
ERROR - 2018-12-10 10:54:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 10:55:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 11:03:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 11:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 11:40:53 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-10 11:42:12 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-10 11:44:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 11:44:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 11:46:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 11:46:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 11:47:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 11:47:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 11:54:00 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 11:54:00 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 11:55:30 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-10 11:58:00 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-10 11:58:35 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-10 11:59:17 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-10 12:03:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 233
ERROR - 2018-12-10 12:03:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 234
ERROR - 2018-12-10 12:08:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 117
ERROR - 2018-12-10 12:08:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 117
ERROR - 2018-12-10 12:10:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 233
ERROR - 2018-12-10 12:10:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 234
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 12:18:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 12:19:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 12:20:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 12:24:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 12:45:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 12:45:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-10 12:51:11 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-10 12:56:48 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-10 12:56:50 --> 404 Page Not Found: Daybook/expenses
ERROR - 2018-12-10 12:57:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-10 12:57:30 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-10 13:00:35 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 13:56:53 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 14:03:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-10 14:30:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-10 14:39:13 --> Query error: Unknown column 'expensDate' in 'field list' - Invalid query: INSERT INTO `expense` (`customerId`, `companyId`, `voucher_no`, `expenseType`, `pay_to`, `phone`, `debit`, `payment_type`, `bank_name`, `chequeno`, `dd_date`, `description`, `approved_by`, `expensDate`) VALUES ('12', '102', 'TN1346082371', '7', 'robert', '1234567890', '10000', 'cheque', 'HDFC', 'HDFC987', '2018-12-10', 'robert', '12', NULL)
ERROR - 2018-12-10 14:47:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 14:47:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 14:48:28 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 14:48:28 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 14:58:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 14:58:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:00:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:00:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:01:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:01:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:02:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:02:06 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:03:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:03:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:03:47 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:03:47 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:03:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:03:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:04:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:04:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:04:32 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:04:32 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:09:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:09:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:09:43 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:09:43 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:09:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:09:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:10:41 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-10 15:19:08 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-10 15:20:01 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-10 15:20:04 --> 404 Page Not Found: Daybook/income
ERROR - 2018-12-10 15:20:31 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:20:31 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:20:37 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:20:37 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:22:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:22:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:22:26 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:22:26 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:22:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:22:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:34:02 --> 404 Page Not Found: Daybook/edit_income_user
ERROR - 2018-12-10 15:34:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-10 15:36:10 --> 404 Page Not Found: Daybook/edit_income_user
ERROR - 2018-12-10 15:37:36 --> 404 Page Not Found: Daybook/edit_income_user
ERROR - 2018-12-10 15:39:03 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:39:03 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:39:13 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:39:13 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:39:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:39:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:39:43 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:39:43 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:40:08 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:40:08 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:40:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:40:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:40:25 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:40:25 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:41:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:41:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:46:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:46:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:47:53 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:47:53 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:50:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 233
ERROR - 2018-12-10 15:50:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 234
ERROR - 2018-12-10 15:50:53 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 217
ERROR - 2018-12-10 15:50:53 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-10 15:50:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-10' and exp.`expenseDate` <='2018-12-10' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-10 15:51:13 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 217
ERROR - 2018-12-10 15:51:13 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 25
ERROR - 2018-12-10 15:51:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and `bookingDate` >= '2018-12-10' and `bookingDate` <='2018-12-10' ORDER BY `b' at line 1 - Invalid query: SELECT sum(priceCash+creditPaid) as totTicket  FROM `travel_booking` WHERE `companyId` in () and `bookingDate` >= '2018-12-10' and `bookingDate` <='2018-12-10' ORDER BY `bookingId`  DESC
ERROR - 2018-12-10 15:51:20 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 217
ERROR - 2018-12-10 15:51:20 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-10 15:51:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-10' and exp.`expenseDate` <='2018-12-10' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-10 15:51:44 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:51:44 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:51:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:51:51 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:52:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:52:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-10 15:52:19 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:52:19 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-10 15:55:39 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-10 15:55:39 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-10 15:55:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-10 16:08:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-10 16:40:27 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-10 16:40:27 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-10 16:40:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-10 16:40:32 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-10 16:40:32 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-10 16:40:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
ERROR - 2018-12-10 16:41:26 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/Admin_model.php 344
ERROR - 2018-12-10 16:41:26 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Admin_model.php 55
ERROR - 2018-12-10 16:41:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `travel_customer`
WHERE `companyId` in()
 LIMIT 5
