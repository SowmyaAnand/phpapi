<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-26 14:32:04 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-26 14:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-26 14:32:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-26 14:33:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-26 15:00:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-26 15:00:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-26 15:00:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-26 15:00:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:00:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:00:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-26 15:00:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-26 15:00:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-26 15:05:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-26 15:05:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-26 15:05:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-26 15:05:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:05:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:05:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-26 15:05:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-26 15:05:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-26 15:09:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-26 15:09:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-26 15:09:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-26 15:09:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:09:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:09:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-26 15:09:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-26 15:09:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-26 15:13:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-26 15:13:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-26 15:13:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-26 15:13:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:13:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:13:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-26 15:13:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-26 15:13:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-26 15:13:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-26 15:13:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-26 15:13:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-26 15:13:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:13:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-26 15:13:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-26 15:13:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-26 15:13:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-26 15:16:14 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-26 15:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-26 15:35:16 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-26 15:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 82
ERROR - 2018-12-26 16:06:50 --> Severity: Error --> Call to undefined method Admin::get_companies() /var/www/travel_app/application/controllers/Admin.php 210
ERROR - 2018-12-26 16:09:14 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/travel_app/application/views/admin/profile.php 57
ERROR - 2018-12-26 16:10:11 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 49
ERROR - 2018-12-26 16:10:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 49
ERROR - 2018-12-26 16:10:11 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 98
ERROR - 2018-12-26 16:10:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 98
ERROR - 2018-12-26 16:11:17 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 98
ERROR - 2018-12-26 16:11:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 98
ERROR - 2018-12-26 16:11:17 --> 404 Page Not Found: Admin/uploads
ERROR - 2018-12-26 16:11:17 --> 404 Page Not Found: Admin/uploads
ERROR - 2018-12-26 16:11:17 --> 404 Page Not Found: Admin/uploads
ERROR - 2018-12-26 16:15:22 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 96
ERROR - 2018-12-26 16:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 96
ERROR - 2018-12-26 16:17:07 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:17:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:17:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-26 16:43:57 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:43:58 --> 404 Page Not Found: First/index
ERROR - 2018-12-26 16:43:58 --> 404 Page Not Found: Uploads/bioscore.png
ERROR - 2018-12-26 16:43:58 --> 404 Page Not Found: Uploads/god-813799_1280.jpg
ERROR - 2018-12-26 16:43:58 --> 404 Page Not Found: First/index
ERROR - 2018-12-26 16:43:58 --> 404 Page Not Found: Uploads/bioscore.png
ERROR - 2018-12-26 16:43:58 --> 404 Page Not Found: Uploads/god-813799_1280.jpg
ERROR - 2018-12-26 16:45:47 --> Query error: Unknown column 'userEmail' in 'where clause' - Invalid query: SELECT *
FROM `travel_company`
WHERE `userEmail` = 'Druser@dr.com'
ERROR - 2018-12-26 16:47:31 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:47:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:50:33 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:50:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:53:45 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:53:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:54:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:54:46 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:55:08 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:55:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:57:26 --> Severity: Parsing Error --> syntax error, unexpected '$value' (T_VARIABLE), expecting ',' or ';' /var/www/travel_app/application/views/admin/profile.php 54
ERROR - 2018-12-26 16:57:54 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:57:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:57:54 --> 404 Page Not Found: Uploads/So-Chic-2.pngNEW%20Company
ERROR - 2018-12-26 16:57:54 --> 404 Page Not Found: Uploads/Ksoft%20Board.jpgThrssr%20Company
ERROR - 2018-12-26 16:57:54 --> 404 Page Not Found: Uploads/banner%203.jpgPkd%20Company
ERROR - 2018-12-26 16:58:52 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:58:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:59:37 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 16:59:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:00:04 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:00:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:03:25 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:03:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:05:31 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:05:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:05:57 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:05:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:06:20 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:07:37 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:07:37 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:07:55 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:07:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:07:55 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:07:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:08:00 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:08:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:08:00 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:08:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:19:30 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:19:30 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:19:45 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-26 17:19:45 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-26 17:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
