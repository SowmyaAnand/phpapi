<!DOCTYPE html>
<html>
<head>
	<title>dailyEstore</title>

	<!-- Latest compiled and minified CSS -->
<link href="<?php echo base_url();?>assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/lib/jquery/jquery.min.js"></script>
<link href="<?php echo base_url();?>assets/css/css.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/custom_style.css" >
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/ipoll.css" >

</head>
<body>
    

    <img src="<?php echo base_url();?>assets/img/dash.jpeg" alt="dailyEstore" />

         <footer>
        &copy; iPoll 2020
      </footer>
  </body>
 
</html>