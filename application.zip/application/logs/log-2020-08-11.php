<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-11 22:55:23 --> Severity: Notice --> Undefined variable: typeId /home/dailyest/public_html/dailyestore/application/models/Api_model.php 60
