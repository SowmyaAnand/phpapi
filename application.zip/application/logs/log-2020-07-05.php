<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-05 15:03:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 15:11:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 15:12:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 15:12:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 15:12:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 17:10:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 17:10:07 --> Query error: Table 'ipoll.travel_users' doesn't exist - Invalid query: SELECT DISTINCT(`travel_company`.`companyId`), `travel_company`.`companyName`
FROM `travel_users`
JOIN `travel_company` ON `travel_company`.`companyId`=`travel_users`.`companyId`
WHERE `travel_users`.`userEmail` IS NULL
ERROR - 2020-07-05 18:10:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 22:03:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 22:03:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 23:16:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 23:17:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 23:18:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 23:18:09 --> 404 Page Not Found: Assets/img
