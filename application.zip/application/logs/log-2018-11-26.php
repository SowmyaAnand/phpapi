<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-26 11:48:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 11:49:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 11:53:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 11:54:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 12:02:32 --> 404 Page Not Found: User/search_user
ERROR - 2018-11-26 12:09:59 --> Severity: Notice --> Undefined variable: thi /var/www/travel_app/application/controllers/Welcome.php 312
ERROR - 2018-11-26 12:09:59 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 312
ERROR - 2018-11-26 12:09:59 --> Severity: Error --> Call to a member function userdata() on null /var/www/travel_app/application/controllers/Welcome.php 312
ERROR - 2018-11-26 12:16:48 --> 404 Page Not Found: Admin/list_customer
ERROR - 2018-11-26 12:19:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 12:21:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 12:33:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 12:48:15 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:50:27 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:51:02 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:52:42 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:53:04 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:53:08 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:53:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 12:53:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 12:53:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 12:53:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 12:53:49 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:55:16 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:55:30 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 12:55:36 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/travel_app/application/views/user/ticket_details.php 101
ERROR - 2018-11-26 12:56:07 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 13:01:56 --> Could not find the language line "form_validation_creditlimit_check"
ERROR - 2018-11-26 13:03:18 --> Severity: Notice --> Undefined property: Booking::$CI /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:03:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:03:18 --> Severity: Error --> Call to a member function get_where() on null /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:03:36 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:03:51 --> Severity: Notice --> Undefined property: Booking::$CI /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:03:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:03:51 --> Severity: Error --> Call to a member function get_where() on null /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:05:33 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:08:29 --> 404 Page Not Found: User/tickets
ERROR - 2018-11-26 13:08:38 --> 404 Page Not Found: Use/index
ERROR - 2018-11-26 13:09:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 13:09:34 --> Severity: Notice --> Undefined property: Booking::$CI /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:09:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:09:34 --> Severity: Error --> Call to a member function post() on null /var/www/travel_app/application/controllers/Booking.php 127
ERROR - 2018-11-26 13:12:27 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/travel_app/application/controllers/Booking.php 133
ERROR - 2018-11-26 13:12:44 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:13:34 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:13:49 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:14:47 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:15:03 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:15:30 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:15:42 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 13:58:11 --> Could not find the language line "form_validation_creditlimt_check"
ERROR - 2018-11-26 14:02:33 --> Query error: Unknown column 'payment_type' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`customerId`, `travelFrom`, `departureDateTime`, `departureTerminal`, `pnr`, `travelTo`, `arrivalDateTime`, `arrivalTerminal`, `flightNo`, `price`, `payment_type`, `companyId`, `createdBy`) VALUES ('10', '21', '2018-11-08 12:53', 'a', '234', '1559', '2018-11-08 12:53', 'a', '234', '234', '2', '102', '2')
ERROR - 2018-11-26 14:03:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 14:03:43 --> Query error: Column 'paymentType' cannot be null - Invalid query: INSERT INTO `travel_booking` (`customerId`, `travelFrom`, `departureDateTime`, `departureTerminal`, `pnr`, `travelTo`, `arrivalDateTime`, `arrivalTerminal`, `flightNo`, `price`, `paymentType`, `companyId`, `createdBy`) VALUES ('10', '21', '2018-11-08 12:53', 'a', '234', '1559', '2018-11-08 12:53', 'a', '234', '234', NULL, '102', '2')
ERROR - 2018-11-26 14:05:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 14:06:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 14:15:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 14:15:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 14:21:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 14:21:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 14:23:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 14:23:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 14:23:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 14:32:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 14:32:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 14:33:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 14:33:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 14:38:30 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/login.php 69
ERROR - 2018-11-26 14:38:34 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/login.php 69
ERROR - 2018-11-26 14:47:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 14:47:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 14:48:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 14:52:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 14:53:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 15:11:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 15:30:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 15:59:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 15:59:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 17:04:31 --> Severity: Error --> Call to undefined function date_diffdate() /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:05:21 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:06:03 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:06:05 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:06:06 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:06:22 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:07:15 --> Severity: 4096 --> Object of class DateInterval could not be converted to string /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:07:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 17:07:42 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:08:38 --> Severity: Notice --> Use of undefined constant absolute - assumed 'absolute' /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:08:38 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:09:00 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:09:28 --> Severity: Error --> Call to undefined function date_diffdate() /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:09:52 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, string given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:11:39 --> Severity: Warning --> abs() expects exactly 1 parameter, 2 given /var/www/travel_app/application/views/user/ticket_details.php 74
ERROR - 2018-11-26 17:37:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 17:38:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 17:44:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 18:52:09 --> Query error: Unknown column 'companyCode' in 'where clause' - Invalid query: SELECT *
FROM `travel_users`
WHERE `companyCode` = '110'
AND `userEmail` = 'Druser@dr.com'
AND `password` = '123456'
ERROR - 2018-11-26 19:29:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 19:29:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-26 19:29:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 19:29:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 19:37:14 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 30
ERROR - 2018-11-26 19:37:38 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 30
ERROR - 2018-11-26 19:38:01 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/views/user/customer_travel.php 30
ERROR - 2018-11-26 19:39:58 --> Severity: Notice --> Undefined variable: customerName /var/www/travel_app/application/views/user/customer_travel.php 21
ERROR - 2018-11-26 19:48:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 19:48:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 19:50:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 19:50:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 19:59:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 19:59:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:01:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:02:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:02:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:02:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:06:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:06:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:06:26 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:06:27 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:06:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:06:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:06:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:06:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:06:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:06:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:07:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:07:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:07:30 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:07:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:07:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:11:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:11:37 --> Severity: Notice --> Undefined offset: 0 /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:11:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:11:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:37 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:38 --> Severity: Notice --> Undefined offset: 0 /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:11:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:11:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:38 --> Severity: Notice --> Undefined offset: 0 /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:11:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 133
ERROR - 2018-11-26 20:11:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:38 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:11:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:11:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/User.php 134
ERROR - 2018-11-26 20:12:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:12:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-26 20:13:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-26 20:13:05 --> 404 Page Not Found: Assets/css
