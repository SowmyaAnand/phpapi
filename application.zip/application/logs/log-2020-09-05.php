<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-05 20:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 20
ERROR - 2020-09-05 20:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 20
ERROR - 2020-09-05 20:36:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dailyest/public_html/dailyestore/application/controllers/Api.php 20
