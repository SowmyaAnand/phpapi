<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-27 18:10:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\travel_app\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-03-27 18:10:24 --> Unable to connect to the database
ERROR - 2020-03-27 18:14:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-27 18:14:55 --> Severity: Notice --> Undefined variable: company_image C:\xampp\htdocs\travel_app\application\views\admin\profile.php 51
ERROR - 2020-03-27 18:14:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\travel_app\application\views\admin\profile.php 51
ERROR - 2020-03-27 18:14:55 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\travel_app\application\views\admin\profile.php 94
ERROR - 2020-03-27 18:14:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\travel_app\application\views\admin\profile.php 94
ERROR - 2020-03-27 18:14:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-27 20:09:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-27 20:45:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 354
ERROR - 2020-03-27 20:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 354
ERROR - 2020-03-27 21:23:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-03-27 21:23:24 --> Severity: Notice --> Undefined variable: company_image C:\xampp\htdocs\assignment\application\views\admin\profile.php 51
ERROR - 2020-03-27 21:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\profile.php 51
ERROR - 2020-03-27 21:23:24 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\profile.php 94
ERROR - 2020-03-27 21:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\profile.php 94
ERROR - 2020-03-27 21:23:24 --> 404 Page Not Found: Assets/img
