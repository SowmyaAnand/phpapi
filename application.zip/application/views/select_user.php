<!DOCTYPE html>
<html>
<head>
	<title>iPoll::User </title>

<link href="<?php echo base_url();?>assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/lib/jquery/jquery.min.js"></script>
<link href="<?php echo base_url();?>assets/css/css.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>assets/js/custom_validation.js"></script>
<noscript>Your browser does not support JavaScript!</noscript>
</head>
<body> 
  <div class="col-md-12">
    <div class="col-md-5">
      <img src="<?php echo base_url();?>assets/img/care.png">
    </div>
    <div class="col-md-6">
     <div align="center" style="margin-top: 200px">
             <a href="<?php echo base_url();?>admin/login" class="btn btn-primary" style="width:300px">Admin</a><br><br>
             <a href="<?php echo base_url();?>user/login" class="btn btn-primary" style="width: 300px;">User</a>

            </div>
          </div>
  </div>
</body>
</html>