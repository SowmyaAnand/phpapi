<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-05 09:06:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 09:12:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 09:24:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 09:25:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 09:32:33 --> Query error: Duplicate entry '0' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('ewdfewf', 'erewrfr', 'erfdewrfew', '4567891230', 'ggf@gmail.com', 'uploads/22a956201bd28b31bac0e65001e30dc2.jpg')
ERROR - 2019-01-05 09:32:48 --> Query error: Duplicate entry '0' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('ewdfewf', 'erewrfr', 'erfdewrfew', '4567891230', 'ggf@gmail.com', 'uploads/22a956201bd28b31bac0e65001e30dc2.jpg')
ERROR - 2019-01-05 09:33:04 --> Query error: Duplicate entry '112' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('ewdfewf', 'erewrfr', '112', '4567891230', 'ggf@gmail.com', 'uploads/22a956201bd28b31bac0e65001e30dc2.jpg')
ERROR - 2019-01-05 09:33:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 09:39:39 --> Query error: Duplicate entry '118' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('sagar', 'Cherpulassery', '118', '1230654789', 'sagar@gmail.com', 'uploads/windows-7-end-of-support-sse2.jpg')
ERROR - 2019-01-05 09:40:04 --> Query error: Duplicate entry '118' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('sagar', 'Cherpulassery', '118', '1230654789', 'sagar@gmail.com', 'uploads/windows-7-end-of-support-sse2.jpg')
ERROR - 2019-01-05 09:40:26 --> Query error: Duplicate entry '118' for key 'companyCode' - Invalid query: INSERT INTO `travel_company` (`companyName`, `companyAddress`, `companyCode`, `companyPhone`, `companyEmail`, `companyLogo`) VALUES ('sagar', 'Cherpulassery', '118', '1230654789', 'sagar@gmail.com', 'uploads/windows-7-end-of-support-sse2.jpg')
ERROR - 2019-01-05 10:16:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 10:31:13 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-05 10:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-05 10:31:13 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-05 10:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-05 10:34:29 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-05 10:34:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-05 10:34:29 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-05 10:34:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-05 10:51:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 11:07:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-05 11:07:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-05 11:07:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-05 11:07:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-05 11:07:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-05 11:07:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-05 11:07:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-05 11:07:46 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-05 11:23:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 11:24:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 11:27:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 11:50:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 11:54:03 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-05 11:59:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 12:01:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 12:06:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 12:06:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 12:08:13 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 305
ERROR - 2019-01-05 12:08:16 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 305
ERROR - 2019-01-05 12:10:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 12:17:06 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 302
ERROR - 2019-01-05 12:17:23 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 305
ERROR - 2019-01-05 12:17:25 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 305
ERROR - 2019-01-05 12:18:23 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 302
ERROR - 2019-01-05 12:18:32 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 305
ERROR - 2019-01-05 12:18:34 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 305
ERROR - 2019-01-05 12:18:36 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 305
ERROR - 2019-01-05 12:22:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 12:25:08 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 302
ERROR - 2019-01-05 12:26:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 12:42:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 12:53:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 13:00:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-05 13:06:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-05 13:06:00 --> 404 Page Not Found: Assets/css
