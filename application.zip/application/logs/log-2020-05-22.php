<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-22 14:01:25 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-22 14:01:25 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-22 14:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-22 14:01:25 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-22 14:01:25 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-22 14:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-22 14:01:25 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-22 14:01:25 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-22 14:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-22 14:01:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-22 14:01:48 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-22 14:01:48 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-22 14:01:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-22 14:01:48 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-22 14:01:48 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-22 14:01:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-22 14:01:48 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-22 14:01:48 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-22 14:01:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-22 14:01:49 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-22 14:01:54 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-22 14:01:54 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-22 14:01:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-22 14:01:54 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-22 14:01:54 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-22 14:01:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-22 14:01:54 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-22 14:01:54 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-22 14:01:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-22 14:01:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-22 14:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 338
ERROR - 2020-05-22 14:01:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-22 14:02:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 338
ERROR - 2020-05-22 14:02:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-22 14:02:03 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-22 14:02:03 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-22 14:02:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-22 14:02:03 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-22 14:02:03 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-22 14:02:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-22 14:02:03 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-22 14:02:03 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-22 14:02:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-22 14:46:51 --> Query error: Unknown column 'userType' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'ambikabalan1992@gmail.com'
AND `password` = '123456'
AND `userType` = '0'
ERROR - 2020-05-22 14:46:58 --> Query error: Unknown column 'userType' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'ambikabalan1992@gmail.com'
AND `password` = '123456'
AND `userType` = '0'
