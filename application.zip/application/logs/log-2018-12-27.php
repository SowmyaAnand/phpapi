<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-27 09:22:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-27 09:22:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-27 09:24:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-27 09:30:55 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-27 09:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-27 09:30:55 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-27 09:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-27 09:32:28 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-27 09:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2018-12-27 09:32:28 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2018-12-27 09:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
