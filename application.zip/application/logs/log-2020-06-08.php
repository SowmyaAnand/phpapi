<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-08 21:58:48 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-06-08 21:58:48 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-06-08 21:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-06-08 21:58:48 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-06-08 21:58:48 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-06-08 21:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-06-08 21:58:48 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-06-08 21:58:48 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-06-08 21:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-06-08 21:58:49 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:58:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 328
ERROR - 2020-06-08 21:59:47 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:50 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 21:59:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 22:02:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-08 22:02:41 --> 404 Page Not Found: Assets/img
