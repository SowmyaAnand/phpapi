<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-01 12:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-01 12:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-01 12:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-01 12:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 12:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 12:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-01 12:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-01 12:25:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-01 12:55:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-01 12:55:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-01 12:55:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-01 12:55:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 12:55:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 12:55:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-01 12:55:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-01 12:55:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-01 12:56:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-01 12:56:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-01 12:56:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-01 12:56:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 12:56:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 12:56:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-01 12:56:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-01 12:56:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-01 12:58:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-01 12:58:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-01 12:58:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-01 12:58:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 12:58:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 12:58:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-01 12:58:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-01 12:58:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-01 13:04:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2019-01-01 13:04:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2019-01-01 13:04:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 13:04:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2019-01-01 13:04:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:04:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:04:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:04:54 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 13:08:54 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2019-01-01 13:08:54 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2019-01-01 13:08:54 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 13:08:54 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2019-01-01 13:08:54 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:08:54 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:08:54 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:08:54 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 13:12:10 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 13:12:19 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 13:12:20 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 13:14:29 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2019-01-01 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2019-01-01 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2019-01-01 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 13:16:57 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 54
ERROR - 2019-01-01 13:16:57 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 13:16:57 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 56
ERROR - 2019-01-01 13:16:57 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:16:57 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:16:57 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:16:57 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 13:17:56 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:17:56 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:17:56 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:17:56 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 13:18:27 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:18:27 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:18:27 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:18:27 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 13:21:26 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:21:26 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:21:26 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:21:26 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 13:22:02 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:22:02 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:22:02 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:22:02 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 13:25:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 13:25:58 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:25:58 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 13:25:58 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 13:25:58 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:09:05 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:09:05 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:09:05 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:09:05 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:09:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 14:09:42 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:09:42 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:09:42 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:09:42 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:10:15 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 14:10:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 14:10:28 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:10:28 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:10:28 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:10:28 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:14:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 14:14:19 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:14:19 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:14:19 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:14:19 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:15:37 --> Severity: Notice --> Undefined property: stdClass::$companyAddress /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 14:15:37 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:15:37 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:15:37 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:15:37 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:15:57 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 14:15:57 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:15:57 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:15:57 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:15:57 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:17:30 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:17:30 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:17:30 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:17:30 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:17:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-01 14:18:02 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/invoice.php 55
ERROR - 2019-01-01 14:18:02 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:18:02 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:18:02 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:18:02 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:18:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-01 14:18:37 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:18:37 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:18:37 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:18:37 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:19:09 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:19:09 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:19:09 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:19:09 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:19:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-01 14:19:13 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:19:13 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 180
ERROR - 2019-01-01 14:19:13 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 184
ERROR - 2019-01-01 14:19:13 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:22:34 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 181
ERROR - 2019-01-01 14:22:34 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 181
ERROR - 2019-01-01 14:22:34 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:22:34 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 186
ERROR - 2019-01-01 14:23:29 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 181
ERROR - 2019-01-01 14:23:29 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 181
ERROR - 2019-01-01 14:23:29 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 185
ERROR - 2019-01-01 14:23:29 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 186
ERROR - 2019-01-01 14:24:20 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 182
ERROR - 2019-01-01 14:24:20 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 182
ERROR - 2019-01-01 14:24:20 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 186
ERROR - 2019-01-01 14:24:20 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 187
ERROR - 2019-01-01 14:26:51 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 168
ERROR - 2019-01-01 14:26:51 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 168
ERROR - 2019-01-01 14:26:51 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 172
ERROR - 2019-01-01 14:26:51 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 173
ERROR - 2019-01-01 14:27:12 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 168
ERROR - 2019-01-01 14:27:12 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 168
ERROR - 2019-01-01 14:27:12 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 172
ERROR - 2019-01-01 14:27:12 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 173
ERROR - 2019-01-01 14:28:22 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 170
ERROR - 2019-01-01 14:28:22 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 170
ERROR - 2019-01-01 14:28:22 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 174
ERROR - 2019-01-01 14:28:22 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 175
ERROR - 2019-01-01 14:29:11 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:29:11 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:29:11 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 14:29:11 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 14:30:14 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 129
ERROR - 2019-01-01 14:30:14 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 129
ERROR - 2019-01-01 14:30:14 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 14:30:14 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 134
ERROR - 2019-01-01 14:30:26 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 129
ERROR - 2019-01-01 14:30:26 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 129
ERROR - 2019-01-01 14:30:26 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 14:30:26 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 134
ERROR - 2019-01-01 14:32:10 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 130
ERROR - 2019-01-01 14:32:10 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 130
ERROR - 2019-01-01 14:32:10 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 134
ERROR - 2019-01-01 14:32:10 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 135
ERROR - 2019-01-01 14:32:35 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 130
ERROR - 2019-01-01 14:32:35 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 130
ERROR - 2019-01-01 14:32:35 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 134
ERROR - 2019-01-01 14:32:35 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 135
ERROR - 2019-01-01 14:32:50 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 130
ERROR - 2019-01-01 14:32:50 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 130
ERROR - 2019-01-01 14:32:50 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 134
ERROR - 2019-01-01 14:32:50 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 135
ERROR - 2019-01-01 14:34:57 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 14:34:57 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 14:34:57 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 14:34:57 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 14:35:13 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 111
ERROR - 2019-01-01 14:35:13 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 111
ERROR - 2019-01-01 14:35:13 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 115
ERROR - 2019-01-01 14:35:13 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 116
ERROR - 2019-01-01 14:35:41 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 108
ERROR - 2019-01-01 14:35:41 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 108
ERROR - 2019-01-01 14:35:41 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 112
ERROR - 2019-01-01 14:35:41 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 113
ERROR - 2019-01-01 14:36:15 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 109
ERROR - 2019-01-01 14:36:15 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 109
ERROR - 2019-01-01 14:36:15 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 113
ERROR - 2019-01-01 14:36:15 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 114
ERROR - 2019-01-01 14:37:23 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 113
ERROR - 2019-01-01 14:37:23 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 113
ERROR - 2019-01-01 14:37:23 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 117
ERROR - 2019-01-01 14:37:23 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:37:40 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 113
ERROR - 2019-01-01 14:37:40 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 113
ERROR - 2019-01-01 14:37:40 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 117
ERROR - 2019-01-01 14:37:40 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 113
ERROR - 2019-01-01 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 113
ERROR - 2019-01-01 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 117
ERROR - 2019-01-01 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:38:54 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 117
ERROR - 2019-01-01 14:38:54 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 117
ERROR - 2019-01-01 14:38:54 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 121
ERROR - 2019-01-01 14:38:54 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 122
ERROR - 2019-01-01 14:39:03 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 117
ERROR - 2019-01-01 14:39:03 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 117
ERROR - 2019-01-01 14:39:03 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 121
ERROR - 2019-01-01 14:39:03 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 122
ERROR - 2019-01-01 14:47:14 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:47:14 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:47:14 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 122
ERROR - 2019-01-01 14:47:14 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:47:36 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:47:36 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:47:36 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 122
ERROR - 2019-01-01 14:47:36 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:47:52 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:47:52 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:47:52 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 122
ERROR - 2019-01-01 14:47:52 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:48:11 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:48:11 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:48:11 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 122
ERROR - 2019-01-01 14:48:11 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:48:25 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:48:25 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 118
ERROR - 2019-01-01 14:48:25 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 122
ERROR - 2019-01-01 14:48:25 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:49:27 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 119
ERROR - 2019-01-01 14:49:27 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 119
ERROR - 2019-01-01 14:49:27 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:49:27 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2019-01-01 14:49:54 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 119
ERROR - 2019-01-01 14:49:54 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 119
ERROR - 2019-01-01 14:49:54 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 123
ERROR - 2019-01-01 14:49:54 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 124
ERROR - 2019-01-01 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:11:31 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:11:31 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:11:31 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 15:11:31 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:12:10 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:12:10 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:12:10 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 15:12:10 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:12:37 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:12:37 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:12:37 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 15:12:37 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:13:06 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:13:06 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:13:06 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 15:13:06 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:13:09 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 15:13:52 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:13:52 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:13:52 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 15:13:52 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:13:52 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 15:13:58 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 15:14:22 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:14:22 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:14:22 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 15:14:22 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:14:22 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 15:15:20 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:15:20 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 127
ERROR - 2019-01-01 15:15:20 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 131
ERROR - 2019-01-01 15:15:20 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:17:43 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:17:43 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:17:43 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:17:43 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:17:56 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:17:56 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:17:56 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:17:56 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:18:24 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:18:24 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:18:24 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:18:24 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:19:24 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:19:24 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:19:24 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:19:24 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:19:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-01 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:23:10 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:23:31 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:23:31 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:23:31 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:23:31 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:23:45 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:23:45 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:23:45 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:23:45 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:24:02 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:24:02 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:24:02 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:24:02 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:27:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-01 15:27:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-01 15:27:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-01 15:27:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 15:27:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-01 15:27:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-01 15:27:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-01 15:27:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-01 15:28:54 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:28:54 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 128
ERROR - 2019-01-01 15:28:54 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 132
ERROR - 2019-01-01 15:28:54 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 129
ERROR - 2019-01-01 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 129
ERROR - 2019-01-01 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 134
ERROR - 2019-01-01 15:30:54 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 129
ERROR - 2019-01-01 15:30:54 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 129
ERROR - 2019-01-01 15:30:54 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 133
ERROR - 2019-01-01 15:30:54 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 134
ERROR - 2019-01-01 15:32:28 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 139
ERROR - 2019-01-01 15:32:28 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 139
ERROR - 2019-01-01 15:32:28 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 143
ERROR - 2019-01-01 15:32:28 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 144
ERROR - 2019-01-01 15:33:22 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 141
ERROR - 2019-01-01 15:33:22 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 141
ERROR - 2019-01-01 15:33:22 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 145
ERROR - 2019-01-01 15:33:22 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:33:23 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 141
ERROR - 2019-01-01 15:33:23 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 141
ERROR - 2019-01-01 15:33:23 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 145
ERROR - 2019-01-01 15:33:23 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:33:41 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:33:41 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:33:41 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:33:41 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:33:58 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:33:58 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:33:58 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:33:58 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:34:13 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:34:13 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:34:13 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:34:13 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:35:06 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:35:06 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:35:06 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:35:06 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:35:25 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:35:25 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:35:25 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:35:25 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:35:43 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 15:36:02 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:36:02 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:36:02 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:36:02 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:36:22 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:36:22 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:36:22 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:36:22 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:39:38 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:39:38 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:39:38 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:39:38 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:42:31 --> Severity: Error --> Call to undefined function round_to_2dp() /var/www/travel_app/application/views/user/invoice.php 107
ERROR - 2019-01-01 15:43:29 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:43:29 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:43:29 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:43:29 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:43:50 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:43:50 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:43:50 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:43:50 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:44:12 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/travel_app/application/views/user/invoice.php 107
ERROR - 2019-01-01 15:44:20 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:44:20 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:44:20 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:44:20 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:49:45 --> Severity: Error --> Call to undefined function no_to_words() /var/www/travel_app/application/views/user/invoice.php 106
ERROR - 2019-01-01 15:50:28 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:50:28 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:50:28 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:50:28 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:51:04 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:04 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:04 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:51:04 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:51:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-01 15:51:06 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:06 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:06 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:51:06 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:51:06 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:06 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:06 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:51:06 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:51:20 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:20 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:20 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:51:20 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:51:22 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:22 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:51:22 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:51:22 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:52:19 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:52:19 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:52:19 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:52:19 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:53:56 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:53:56 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:53:56 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:53:56 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:54:32 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:54:32 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:54:32 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:54:32 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:54:44 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:54:44 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:54:44 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:54:44 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 15:55:08 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:55:08 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 15:55:08 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 15:55:08 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 16:05:06 --> Severity: Error --> Access to undeclared static property: Booking::$dictionary /var/www/travel_app/application/controllers/Booking.php 311
ERROR - 2019-01-01 16:07:04 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 16:07:04 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 16:07:04 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:07:04 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 16:07:41 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 16:07:41 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 16:07:41 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:07:41 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 16:08:15 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 16:08:15 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 142
ERROR - 2019-01-01 16:08:15 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:08:15 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 16:19:25 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:19:25 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:19:25 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:19:25 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:19:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 369
ERROR - 2019-01-01 16:19:25 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 370
ERROR - 2019-01-01 16:20:29 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:20:29 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:20:29 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:20:29 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:20:40 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:20:40 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:20:40 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:20:40 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:21:21 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:21:21 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:21:21 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:21:21 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:41:36 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:41:36 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:41:36 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:41:36 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:41:48 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:41:48 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:41:48 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:41:48 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:42:21 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 143
ERROR - 2019-01-01 16:42:21 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 143
ERROR - 2019-01-01 16:42:21 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 16:42:21 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 148
ERROR - 2019-01-01 16:42:45 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 143
ERROR - 2019-01-01 16:42:45 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 143
ERROR - 2019-01-01 16:42:45 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 147
ERROR - 2019-01-01 16:42:45 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 148
ERROR - 2019-01-01 16:43:01 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-01 16:43:01 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-01 16:43:01 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-01 16:43:01 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 162
ERROR - 2019-01-01 16:43:25 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-01 16:43:25 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 157
ERROR - 2019-01-01 16:43:25 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 161
ERROR - 2019-01-01 16:43:25 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 162
ERROR - 2019-01-01 16:52:29 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:52:29 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:52:29 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:52:29 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:53:32 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:53:32 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:53:32 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:53:32 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:53:41 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 16:55:00 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:55:00 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:55:00 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:55:00 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:55:01 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 16:56:27 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:56:27 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:56:27 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:56:27 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:56:27 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 16:56:50 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:56:50 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:56:50 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:56:50 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:56:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-01 16:56:50 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 16:57:10 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:57:10 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:57:10 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:57:10 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:57:10 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 16:58:09 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:58:09 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:58:09 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:58:09 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:58:41 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:58:41 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:58:41 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:58:41 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:58:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-01 16:59:03 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:59:03 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 16:59:03 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 16:59:03 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 16:59:10 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-01 17:00:47 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 17:00:47 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 146
ERROR - 2019-01-01 17:00:47 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 150
ERROR - 2019-01-01 17:00:47 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 151
ERROR - 2019-01-01 17:10:10 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:10:10 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:10:10 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:10:10 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 17:10:41 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:10:41 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:10:41 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:10:41 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 17:11:25 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:11:25 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:11:25 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:11:25 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 17:12:20 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:12:20 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:12:20 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:12:20 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 17:13:26 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:13:26 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:13:26 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:13:26 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 17:15:02 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:15:02 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:15:02 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:15:02 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 17:15:44 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:15:44 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:15:44 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:15:44 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 17:16:52 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:16:52 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 17:16:52 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 17:16:52 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 20:30:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-01 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 20:36:50 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 20:36:50 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 20:36:50 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 20:36:50 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
ERROR - 2019-01-01 20:38:05 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Booking.php 391
ERROR - 2019-01-01 21:00:09 --> Severity: Notice --> Undefined variable: add_booking /var/www/travel_app/application/controllers/Report.php 207
ERROR - 2019-01-01 21:21:38 --> Severity: Notice --> Undefined variable: add_booking /var/www/travel_app/application/controllers/Report.php 207
ERROR - 2019-01-01 21:24:13 --> Severity: Notice --> Undefined property: stdClass::$customerFirstname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 21:24:13 --> Severity: Notice --> Undefined property: stdClass::$customerLastname /var/www/travel_app/application/views/user/invoice.php 149
ERROR - 2019-01-01 21:24:13 --> Severity: Notice --> Undefined property: stdClass::$customerEmail /var/www/travel_app/application/views/user/invoice.php 153
ERROR - 2019-01-01 21:24:13 --> Severity: Notice --> Undefined property: stdClass::$customerPhone /var/www/travel_app/application/views/user/invoice.php 154
