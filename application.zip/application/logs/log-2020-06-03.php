<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 14:26:25 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-03 14:26:56 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-03 14:28:59 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-03 14:29:16 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-03 14:30:18 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-03 14:31:10 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-03 14:31:30 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-03 14:31:55 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-03 23:34:34 --> Query error: Table 'ipoll.option' doesn't exist - Invalid query: SELECT *
FROM `option`
WHERE `qId` = '4'
ERROR - 2020-06-03 23:41:02 --> Query error: Table 'ipoll.option' doesn't exist - Invalid query: SELECT *
FROM `option`
WHERE `qId` = '4'
