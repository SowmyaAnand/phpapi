<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-19 00:35:04 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-19 00:35:04 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-19 00:35:04 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-19 00:35:04 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-19 00:35:04 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-19 00:35:04 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-19 00:35:05 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-19 00:35:13 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 205
ERROR - 2020-08-19 14:25:37 --> Severity: Notice --> Undefined variable: array_of_event1 /home/dailyest/public_html/dailyestore/application/controllers/Api.php 212
