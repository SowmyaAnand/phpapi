<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-12 09:49:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 09:50:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 09:50:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 09:56:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 09:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-12 10:00:07 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-12 10:00:07 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-12 10:00:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-12' and exp.`expenseDate` <='2018-12-12' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-12 10:01:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-12 10:14:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 10:14:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-12 10:14:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-12 10:14:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-12 10:14:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-12 10:14:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-12 10:14:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-12 10:14:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-12 10:14:55 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-12 10:23:42 --> Severity: Parsing Error --> syntax error, unexpected '>' /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-12 10:24:22 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 35
ERROR - 2018-12-12 10:25:26 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 34
ERROR - 2018-12-12 10:30:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 10:33:37 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/dashboard.php 37
ERROR - 2018-12-12 10:40:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 10:40:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 10:41:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 10:43:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-12 10:43:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-12 10:43:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-12 10:43:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-12 10:43:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-12 10:43:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-12 10:43:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-12 10:43:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-12 11:34:47 --> Severity: Notice --> Undefined variable: toDays /var/www/travel_app/application/views/user/balance_sheet.php 183
ERROR - 2018-12-12 11:35:39 --> Severity: Notice --> Undefined variable: toDays /var/www/travel_app/application/views/user/balance_sheet.php 183
ERROR - 2018-12-12 11:36:12 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/accurals_provision_modal.php 22
ERROR - 2018-12-12 11:36:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accurals_provision_modal.php 22
ERROR - 2018-12-12 11:36:12 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/accurals_provision_modal.php 39
ERROR - 2018-12-12 11:37:27 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/accurals_provision_modal.php 23
ERROR - 2018-12-12 11:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/accurals_provision_modal.php 23
ERROR - 2018-12-12 11:37:27 --> Severity: Notice --> Undefined variable: all_expense /var/www/travel_app/application/views/user/accurals_provision_modal.php 40
ERROR - 2018-12-12 11:38:49 --> Severity: Notice --> Undefined index: type /var/www/travel_app/application/views/user/accurals_provision_modal.php 30
ERROR - 2018-12-12 11:38:49 --> Severity: Notice --> Undefined index: totDebit /var/www/travel_app/application/views/user/accurals_provision_modal.php 33
ERROR - 2018-12-12 11:38:49 --> Severity: Notice --> Undefined index: totDebit /var/www/travel_app/application/views/user/accurals_provision_modal.php 36
ERROR - 2018-12-12 11:39:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 11:43:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 11:48:18 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 23
ERROR - 2018-12-12 11:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/loan_advance_modal.php 23
ERROR - 2018-12-12 11:48:18 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 42
ERROR - 2018-12-12 11:49:39 --> Severity: Notice --> Undefined variable: todate /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 11:51:13 --> Severity: Notice --> Undefined variable: todate /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 11:51:55 --> Severity: Notice --> Undefined index: totReceive /var/www/travel_app/application/models/Booking_model.php 280
ERROR - 2018-12-12 11:51:55 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 23
ERROR - 2018-12-12 11:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/loan_advance_modal.php 23
ERROR - 2018-12-12 11:51:55 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 42
ERROR - 2018-12-12 11:52:12 --> Severity: Notice --> Undefined variable: todate /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 11:52:24 --> Severity: Notice --> Undefined variable: todate /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 11:52:25 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 23
ERROR - 2018-12-12 11:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/loan_advance_modal.php 23
ERROR - 2018-12-12 11:52:25 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 42
ERROR - 2018-12-12 11:53:46 --> Severity: Notice --> Undefined variable: todate /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 11:53:51 --> Severity: Notice --> Undefined variable: todate /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 12:00:09 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 50
ERROR - 2018-12-12 12:00:25 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 50
ERROR - 2018-12-12 12:00:54 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 50
ERROR - 2018-12-12 12:02:00 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 50
ERROR - 2018-12-12 12:02:10 --> Severity: Notice --> Undefined variable: accurals_provisions /var/www/travel_app/application/views/user/loan_advance_modal.php 50
ERROR - 2018-12-12 12:14:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 12:27:09 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/models/Daybook_model.php 517
ERROR - 2018-12-12 12:29:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 12:35:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 12:49:16 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-12 12:49:16 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-12 12:49:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) left join travel_company as tc on(tc.companyId = exp.companyId) where exp.`expenseDate` >= '2018-12-12' and exp.`expenseDate` <='2018-12-12' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-12 12:50:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 12:50:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 12:55:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 12:57:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 13:01:09 --> Query error: Unknown column 'income_date' in 'where clause' - Invalid query: SELECT `credit` as `debit`, `description`, `cash_from` as `pay_to`, `receipt_no` as `voucher_no`, `created_at`, `payment_type`, `credit`
FROM `income`
WHERE `companyId` = '102'
AND DATE_FORMAT(income_date,'%Y-%m-%d') >= '2018-12-11'
AND DATE_FORMAT(income_date,'%Y-%m-%d') <= '2018-12-12'
ORDER BY `created_at` DESC
ERROR - 2018-12-12 14:18:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 14:18:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 14:19:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 14:23:02 --> Severity: Parsing Error --> syntax error, unexpected 'cash_in_hand' (T_STRING) /var/www/travel_app/application/models/Daybook_model.php 509
ERROR - 2018-12-12 14:23:02 --> Severity: Parsing Error --> syntax error, unexpected 'cash_in_hand' (T_STRING) /var/www/travel_app/application/models/Daybook_model.php 509
ERROR - 2018-12-12 14:23:32 --> Severity: Parsing Error --> syntax error, unexpected 'cash_in_hand' (T_STRING) /var/www/travel_app/application/models/Daybook_model.php 509
ERROR - 2018-12-12 14:24:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 14:26:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 14:30:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 14:41:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 14:45:00 --> 404 Page Not Found: Daybook/trial_balance
ERROR - 2018-12-12 15:00:26 --> Query error: Unknown column 'exp.companyId' in 'on clause' - Invalid query: SELECT sum(tb.priceCash+tb.creditPaid) as totTicket, tc.companyName as company  FROM `travel_booking` as tb left join travel_company as tc on(tc.companyId = exp.companyId) WHERE tb.`companyId` in (102,103) and tb.`bookingDate` >= '2018-12-12' and tb.`bookingDate` <='2018-12-12'
ERROR - 2018-12-12 15:02:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT (tb.priceCash+tb.creditPaid) as totTicket, tc.companyName as company  FROM `travel_booking` as tb left join travel_company as tc on(tc.companyId = tb.companyId) WHERE tb.`companyId` in (102,103) and tb.`bookingDate` >= '2018-12-12' and tb.`bookingDate` <='2018-12-12' group by 
ERROR - 2018-12-12 15:02:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT tb.priceCash+tb.creditPaid as totTicket, tc.companyName as company  FROM `travel_booking` as tb left join travel_company as tc on(tc.companyId = tb.companyId) WHERE tb.`companyId` in (102,103) and tb.`bookingDate` >= '2018-12-12' and tb.`bookingDate` <='2018-12-12' group by 
ERROR - 2018-12-12 15:09:54 --> Query error: Duplicate entry '2' for key 'cb_id' - Invalid query: INSERT INTO `cash_balance` (`cash_in_hand`, `created_at`, `created_by`, `companyId`) VALUES ('5600', '2018-12-12', '12', '102')
ERROR - 2018-12-12 15:09:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 15:14:59 --> Severity: Parsing Error --> syntax error, unexpected 'cash_in_hand' (T_STRING) /var/www/travel_app/application/models/Daybook_model.php 510
ERROR - 2018-12-12 15:15:13 --> Severity: Error --> Call to undefined function SUM() /var/www/travel_app/application/models/Daybook_model.php 510
ERROR - 2018-12-12 15:23:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '%m-%d') >= '12-12-2018' AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '12-12-2018'' at line 1 - Invalid query: SELECT SUM(`cash_in_hand`) AS `cash_in_hand` FROM `cash_balance` WHERE `companyId` = '102'' AND DATE_FORMAT(created_at,'%Y-%m-%d') >= '12-12-2018' AND DATE_FORMAT(created_at,'%Y-%m-%d') <= '12-12-2018' 
ERROR - 2018-12-12 15:24:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM `income` as inc left join income_type as it on(it.inc_type_id = inc.incomeT' at line 1 - Invalid query: SELECT SUM(inc.credit) as totIncome,it.type, FROM `income` as inc left join income_type as it on(it.inc_type_id = inc.incomeType) WHERE inc.`companyId` in (102,103) and inc.`incomeDate` >= '2018-12-12' and inc.`incomeDate` <='2018-12-12' and it.status in (0,1) group by inc.incomeType
ERROR - 2018-12-12 15:25:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '%m-%d') >= '12-12-2018' AND DATE_FORMAT(`created_at`,'%Y-%m-%d') <= '12-12-2018'' at line 1 - Invalid query: SELECT SUM(`cash_in_hand`) AS `cash_in_hand` FROM `cash_balance` WHERE `companyId` = '102'' AND DATE_FORMAT(`created_at`,'%Y-%m-%d') >= '12-12-2018' AND DATE_FORMAT(`created_at`,'%Y-%m-%d') <= '12-12-2018' 
ERROR - 2018-12-12 15:28:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '%m-%d') >= '12-12-2018' AND DATE_FORMAT(`created_at`,'%Y-%m-%d') <= '12-12-2018'' at line 1 - Invalid query: SELECT SUM(`cash_in_hand`) AS `cash_in_hand` FROM `cash_balance` WHERE `companyId` = '102'' AND DATE_FORMAT(`created_at`,'%Y-%m-%d') >= '12-12-2018' AND DATE_FORMAT(`created_at`,'%Y-%m-%d') <= '12-12-2018' 
ERROR - 2018-12-12 15:33:35 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/models/Daybook_model.php 513
ERROR - 2018-12-12 15:33:35 --> Severity: Notice --> A non well formed numeric value encountered /var/www/travel_app/application/models/Daybook_model.php 514
ERROR - 2018-12-12 15:38:21 --> Severity: Notice --> Undefined index: cash_in_hand /var/www/travel_app/application/models/Daybook_model.php 524
ERROR - 2018-12-12 15:38:35 --> Severity: Notice --> Undefined index: cash_in_hand /var/www/travel_app/application/models/Daybook_model.php 524
ERROR - 2018-12-12 15:39:18 --> Severity: Notice --> Undefined index: cash_in_hand /var/www/travel_app/application/models/Daybook_model.php 524
ERROR - 2018-12-12 15:46:36 --> Severity: Notice --> Undefined index: cash_in_hand /var/www/travel_app/application/models/Daybook_model.php 524
ERROR - 2018-12-12 15:47:13 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/trial_balance.php 87
ERROR - 2018-12-12 15:47:13 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/trial_balance.php 89
ERROR - 2018-12-12 15:47:13 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/trial_balance.php 143
ERROR - 2018-12-12 15:47:13 --> Severity: Notice --> Undefined variable: todate /var/www/travel_app/application/views/user/trial_balance.php 143
ERROR - 2018-12-12 15:47:31 --> Severity: Notice --> Undefined index: cash_in_hand /var/www/travel_app/application/models/Daybook_model.php 524
ERROR - 2018-12-12 15:48:59 --> Severity: Notice --> Undefined index: cash_in_hand /var/www/travel_app/application/models/Daybook_model.php 524
ERROR - 2018-12-12 15:49:41 --> Severity: Notice --> Undefined index: cash_in_hand /var/www/travel_app/application/models/Daybook_model.php 524
ERROR - 2018-12-12 15:49:47 --> Severity: Notice --> Undefined variable: date /var/www/travel_app/application/views/user/trial_balance.php 111
ERROR - 2018-12-12 15:49:47 --> Severity: Notice --> Undefined variable: todate /var/www/travel_app/application/views/user/trial_balance.php 111
ERROR - 2018-12-12 15:50:23 --> Severity: Notice --> Undefined index: cash_in_hand /var/www/travel_app/application/models/Daybook_model.php 525
ERROR - 2018-12-12 15:50:57 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 87
ERROR - 2018-12-12 15:50:57 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 15:50:57 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 173
ERROR - 2018-12-12 15:52:05 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 87
ERROR - 2018-12-12 15:52:05 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 15:52:05 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 173
ERROR - 2018-12-12 15:52:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 15:53:05 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 87
ERROR - 2018-12-12 15:53:05 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 15:53:05 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 173
ERROR - 2018-12-12 15:54:09 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 195
ERROR - 2018-12-12 15:54:09 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 195
ERROR - 2018-12-12 15:54:09 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 196
ERROR - 2018-12-12 15:54:09 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 196
ERROR - 2018-12-12 15:54:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-12 15:54:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 15:55:37 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 143
ERROR - 2018-12-12 15:55:37 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 173
ERROR - 2018-12-12 15:57:48 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 174
ERROR - 2018-12-12 15:58:53 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 201
ERROR - 2018-12-12 16:00:10 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 202
ERROR - 2018-12-12 16:00:32 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 207
ERROR - 2018-12-12 16:00:59 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 208
ERROR - 2018-12-12 16:01:16 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 253
ERROR - 2018-12-12 16:01:16 --> Severity: Error --> Unsupported operand types /var/www/travel_app/application/views/user/daily_transactions.php 285
ERROR - 2018-12-12 16:01:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 16:01:40 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 253
ERROR - 2018-12-12 16:01:40 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 292
ERROR - 2018-12-12 16:03:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 253
ERROR - 2018-12-12 16:03:09 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:03:51 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:04:20 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:04:26 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:04:38 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:04:43 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:06:02 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-12 16:06:02 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-12 16:06:15 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:06:21 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:11:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:11:15 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 173
ERROR - 2018-12-12 16:11:15 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 174
ERROR - 2018-12-12 16:11:15 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 201
ERROR - 2018-12-12 16:11:15 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 202
ERROR - 2018-12-12 16:11:15 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 207
ERROR - 2018-12-12 16:11:15 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 208
ERROR - 2018-12-12 16:11:15 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 253
ERROR - 2018-12-12 16:11:15 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 286
ERROR - 2018-12-12 16:11:15 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:11:25 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 173
ERROR - 2018-12-12 16:11:25 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 174
ERROR - 2018-12-12 16:11:25 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 201
ERROR - 2018-12-12 16:11:25 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 202
ERROR - 2018-12-12 16:11:25 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 207
ERROR - 2018-12-12 16:11:25 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 208
ERROR - 2018-12-12 16:11:25 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 253
ERROR - 2018-12-12 16:11:25 --> Severity: Warning --> Illegal string offset 'cash_in_hand' /var/www/travel_app/application/views/user/daily_transactions.php 286
ERROR - 2018-12-12 16:11:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:11:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/travel_app/application/views/user/daily_transactions.php 293
ERROR - 2018-12-12 16:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 87
ERROR - 2018-12-12 16:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 169
ERROR - 2018-12-12 16:14:43 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 173
ERROR - 2018-12-12 16:14:43 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 174
ERROR - 2018-12-12 16:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 198
ERROR - 2018-12-12 16:14:43 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 201
ERROR - 2018-12-12 16:14:43 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 202
ERROR - 2018-12-12 16:14:43 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 207
ERROR - 2018-12-12 16:14:43 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 208
ERROR - 2018-12-12 16:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 250
ERROR - 2018-12-12 16:14:43 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 253
ERROR - 2018-12-12 16:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 270
ERROR - 2018-12-12 16:14:43 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 286
ERROR - 2018-12-12 16:14:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 87
ERROR - 2018-12-12 16:14:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 169
ERROR - 2018-12-12 16:14:54 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 173
ERROR - 2018-12-12 16:14:54 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 174
ERROR - 2018-12-12 16:14:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 198
ERROR - 2018-12-12 16:14:54 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 201
ERROR - 2018-12-12 16:14:54 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 202
ERROR - 2018-12-12 16:14:54 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 207
ERROR - 2018-12-12 16:14:54 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 208
ERROR - 2018-12-12 16:14:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 250
ERROR - 2018-12-12 16:14:54 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 253
ERROR - 2018-12-12 16:14:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 270
ERROR - 2018-12-12 16:14:54 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 286
ERROR - 2018-12-12 16:17:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-12 16:18:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/user/daily_transactions.php 198
ERROR - 2018-12-12 16:18:17 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 201
ERROR - 2018-12-12 16:18:17 --> Severity: Notice --> Undefined variable: value /var/www/travel_app/application/views/user/daily_transactions.php 202
ERROR - 2018-12-12 16:40:59 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-12 16:40:59 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-12 16:40:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) where exp.`expenseDate` >= '2018-12-12' and exp.`expenseDate` <='2018-12-12' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-12 16:45:54 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-12 16:45:54 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-12 16:45:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) where exp.`expenseDate` >= '2018-12-12' and exp.`expenseDate` <='2018-12-12' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-12 16:51:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-12 16:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-12 16:53:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 125
ERROR - 2018-12-12 16:55:57 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-12 16:55:57 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 25
ERROR - 2018-12-12 16:55:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and `bookingDate` >= '2018-12-12' and `bookingDate` <='2018-12-12' ORDER BY `b' at line 1 - Invalid query: SELECT sum(priceCash+creditPaid) as totTicket  FROM `travel_booking` WHERE `companyId` in () and `bookingDate` >= '2018-12-12' and `bookingDate` <='2018-12-12' ORDER BY `bookingId`  DESC
ERROR - 2018-12-12 16:56:00 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-12 16:56:00 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-12 16:56:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) where exp.`expenseDate` >= '2018-12-12' and exp.`expenseDate` <='2018-12-12' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-12 16:57:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-12 16:57:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 194
ERROR - 2018-12-12 19:41:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Advancepayment.php 44
ERROR - 2018-12-12 19:41:40 --> Query error: Column 'airline_id' cannot be null - Invalid query: INSERT INTO `advance_payment` (`amount`, `companyId`, `date`, `txn_no`, `airline_id`) VALUES ('2134', '102', '2018-12-12', '23432', NULL)
