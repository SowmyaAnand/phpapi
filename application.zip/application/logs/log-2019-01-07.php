<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-07 08:52:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 09:11:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 09:11:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 09:13:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 09:14:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 09:32:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 09:48:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 09:55:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 10:02:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 10:04:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2019-01-07 10:04:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2019-01-07 10:04:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2019-01-07 10:04:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-07 10:04:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2019-01-07 10:04:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2019-01-07 10:04:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2019-01-07 10:04:17 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2019-01-07 10:21:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-07 10:21:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-07 10:26:56 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-07 10:26:56 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-07 10:33:34 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-07 10:33:34 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-07 10:53:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-07 10:53:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-07 10:54:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-07 14:19:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
