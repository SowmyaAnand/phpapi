<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-05 09:13:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:14:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:14:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:15:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:15:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:16:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:18:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:18:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:21:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:04 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:36 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:36 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:41 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:21:41 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 09:27:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:27:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:32:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:33:02 --> Severity: Notice --> Undefined index: todate /var/www/travel_app/application/models/Daybook_model.php 145
ERROR - 2018-12-05 09:33:02 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 146
ERROR - 2018-12-05 09:33:02 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 147
ERROR - 2018-12-05 09:33:31 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 160
ERROR - 2018-12-05 09:34:54 --> Query error: Unknown column 'Airline' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `departureDateTime`, `Airline`, `flightNo`, `priceCash`, `airlinecoast`, `servicecharge`, `travelTo`, `arrivalDateTime`, `pnr`, `priceCredit`, `tax`, `paymentType`, `companyId`, `createdBy`) VALUES ('Graphix', 'test', '2', '2018-12-06 09:34', 'qwert', '123', '123', '1', '2', '3', '2018-12-07 09:34', '123', '', '12', 1, '102', '2')
ERROR - 2018-12-05 09:35:48 --> Severity: Notice --> Undefined index: todate /var/www/travel_app/application/models/Daybook_model.php 145
ERROR - 2018-12-05 09:35:48 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 146
ERROR - 2018-12-05 09:35:48 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 147
ERROR - 2018-12-05 09:35:49 --> Severity: Notice --> Undefined index: todate /var/www/travel_app/application/models/Daybook_model.php 145
ERROR - 2018-12-05 09:35:49 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 146
ERROR - 2018-12-05 09:35:49 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 147
ERROR - 2018-12-05 09:35:55 --> Severity: Notice --> Undefined index: todate /var/www/travel_app/application/models/Daybook_model.php 145
ERROR - 2018-12-05 09:35:55 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 146
ERROR - 2018-12-05 09:35:55 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 147
ERROR - 2018-12-05 09:35:57 --> Severity: Notice --> Undefined index: todate /var/www/travel_app/application/models/Daybook_model.php 145
ERROR - 2018-12-05 09:35:57 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/models/Daybook_model.php 146
ERROR - 2018-12-05 09:35:57 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/models/Daybook_model.php 147
ERROR - 2018-12-05 09:36:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:36:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:36:48 --> Query error: Unknown column 'airlinecoast' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `departureDateTime`, `flightNo`, `priceCash`, `airlinecoast`, `servicecharge`, `travelTo`, `arrivalDateTime`, `pnr`, `priceCredit`, `tax`, `paymentType`, `airline`, `companyId`, `createdBy`) VALUES ('Graphix', 'test', '2', '2018-12-06 09:34', '123', '123', '1', '2', '3', '2018-12-07 09:34', '123', '', '12', 1, 'qwert', '102', '2')
ERROR - 2018-12-05 09:37:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:37:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:37:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:37:36 --> Query error: Unknown column 'servicecharge' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `departureDateTime`, `flightNo`, `priceCash`, `servicecharge`, `travelTo`, `arrivalDateTime`, `pnr`, `priceCredit`, `tax`, `paymentType`, `airline`, `airline_coast`, `companyId`, `createdBy`) VALUES ('Graphix', 'test', '2', '2018-12-06 09:34', '123', '123', '2', '3', '2018-12-07 09:34', '123', '', '12', 1, 'qwert', '1', '102', '2')
ERROR - 2018-12-05 09:37:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 09:37:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 09:37:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:37:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:38:03 --> Query error: Unknown column 'servicecharge' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `departureDateTime`, `flightNo`, `priceCash`, `servicecharge`, `travelTo`, `arrivalDateTime`, `pnr`, `priceCredit`, `tax`, `paymentType`, `airline`, `airline_coast`, `service_charge`, `companyId`, `createdBy`) VALUES ('Graphix', 'test', '2', '2018-12-06 09:34', '123', '123', '2', '3', '2018-12-07 09:34', '123', '', '12', 1, 'qwert', '1', '2', '102', '2')
ERROR - 2018-12-05 09:38:08 --> Query error: Unknown column 'servicecharge' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `departureDateTime`, `flightNo`, `priceCash`, `servicecharge`, `travelTo`, `arrivalDateTime`, `pnr`, `priceCredit`, `tax`, `paymentType`, `airline`, `airline_coast`, `service_charge`, `companyId`, `createdBy`) VALUES ('Graphix', 'test', '2', '2018-12-06 09:34', '123', '123', '2', '3', '2018-12-07 09:34', '123', '', '12', 1, 'qwert', '1', '2', '102', '2')
ERROR - 2018-12-05 09:38:14 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 09:38:14 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-05 09:38:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-05 09:40:07 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:40:07 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:40:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:40:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:43:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:44:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 09:44:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 09:44:52 --> Query error: Unknown column 'company' in 'where clause' - Invalid query: SELECT `customerPhone`, `creditLimit`
FROM `travel_customer`
WHERE `company` = 'Graphix'
ERROR - 2018-12-05 09:44:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:48:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 09:48:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 09:49:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 09:49:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 09:51:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 09:51:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 09:51:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 09:56:17 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:56:17 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:56:21 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:56:21 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 09:57:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 10:01:25 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 10:01:25 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 230
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: first company /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: ABC /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: Robert Tucker /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: NEW Company /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: htfhytrfyt /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: company xyz /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: sdfdgdgfdgdfdhdfggh /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: sdfdgdgfdgdfdhdfgghhfghfhfg /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: COMPANY /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: COMPANY1 /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: COMPANY12 /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: COMPANY123 /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: Test company /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: Test company123 /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined variable: shr company /var/www/travel_app/application/views/user/income_report.php 72
ERROR - 2018-12-05 10:39:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 245
ERROR - 2018-12-05 10:39:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 245
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: first company /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: ABC /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: Robert Tucker /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: NEW Company /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: htfhytrfyt /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: company xyz /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: sdfdgdgfdgdfdhdfggh /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: sdfdgdgfdgdfdhdfgghhfghfhfg /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: COMPANY /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: COMPANY1 /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: COMPANY12 /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: COMPANY123 /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: Test company /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: Test company123 /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined variable: shr company /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:40:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 246
ERROR - 2018-12-05 10:40:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 246
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: first company /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: ABC /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: Robert Tucker /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: NEW Company /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: htfhytrfyt /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: company xyz /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: sdfdgdgfdgdfdhdfggh /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: sdfdgdgfdgdfdhdfgghhfghfhfg /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: COMPANY /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: COMPANY1 /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: COMPANY12 /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: COMPANY123 /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: Test company /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: Test company123 /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined variable: shr company /var/www/travel_app/application/views/user/income_report.php 73
ERROR - 2018-12-05 10:41:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 246
ERROR - 2018-12-05 10:41:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 246
ERROR - 2018-12-05 10:43:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 246
ERROR - 2018-12-05 10:43:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 246
ERROR - 2018-12-05 10:44:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 246
ERROR - 2018-12-05 10:44:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 246
ERROR - 2018-12-05 10:52:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 10:52:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 10:52:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 11:19:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 11:19:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 11:20:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 11:20:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 11:20:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 11:20:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 11:53:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 11:53:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 11:54:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 11:54:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 11:56:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 11:57:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 11:57:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 11:57:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 12:02:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 12:02:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:06:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:17:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 12:18:00 --> 404 Page Not Found: Booking/advancepayment
ERROR - 2018-12-05 12:18:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:18:52 --> Severity: Error --> Call to undefined function pr() /var/www/travel_app/application/controllers/Daybook.php 309
ERROR - 2018-12-05 12:18:53 --> Severity: Error --> Call to undefined function pr() /var/www/travel_app/application/controllers/Daybook.php 309
ERROR - 2018-12-05 12:19:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:22:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:24:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:30:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:30:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:31:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:31:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:34:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 12:35:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:41:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 12:43:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:43:16 --> 404 Page Not Found: Daybook/income_report_admin
ERROR - 2018-12-05 12:43:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:43:49 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-05 12:43:51 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-05 12:43:53 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-05 12:45:19 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-05 12:45:21 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-05 12:47:38 --> 404 Page Not Found: Daybook/income_report
ERROR - 2018-12-05 12:50:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:50:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:50:24 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 12:50:24 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 12:50:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:50:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:50:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 12:50:35 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 12:50:35 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 12:50:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:50:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:50:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:54:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:54:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:54:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 12:54:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 12:54:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:55:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:55:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 12:56:01 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/travel_app/application/controllers/Daybook.php 383
ERROR - 2018-12-05 12:56:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 13:06:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 13:07:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 13:09:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 13:09:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 13:46:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 13:46:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 13:46:32 --> Query error: Unknown column '$company' in 'where clause' - Invalid query: SELECT `firstName` FROM `travel_users`
        WHERE `companyId` in ($company)
ERROR - 2018-12-05 13:46:33 --> Query error: Unknown column '$company' in 'where clause' - Invalid query: SELECT `firstName` FROM `travel_users`
        WHERE `companyId` in ($company)
ERROR - 2018-12-05 13:56:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 13:57:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 13:59:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:00:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:00:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 14:01:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 14:01:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:01:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/travel_app/application/controllers/Daybook.php 389
ERROR - 2018-12-05 14:01:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/travel_app/application/controllers/Daybook.php 389
ERROR - 2018-12-05 14:02:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:02:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 14:02:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:03:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:05:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:06:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:08:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:09:07 --> Severity: Notice --> Undefined variable: areas /var/www/travel_app/application/controllers/Daybook.php 388
ERROR - 2018-12-05 14:09:09 --> Severity: Notice --> Undefined variable: areas /var/www/travel_app/application/controllers/Daybook.php 388
ERROR - 2018-12-05 14:09:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:09:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:10:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:10:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 14:11:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:11:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:12:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-05 14:12:19 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-05 14:14:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:20:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:21:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:21:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:21:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:21:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:21:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:22:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:22:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:22:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:23:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:23:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:23:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:23:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:24:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:24:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:25:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:25:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:25:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:25:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:29:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:32:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:33:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:34:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:36:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:38:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:38:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:41:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:41:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:43:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:43:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:43:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:43:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 14:44:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:44:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 14:46:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:46:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:46:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 14:46:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:47:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:51:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:52:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:54:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:57:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 14:59:46 --> 404 Page Not Found: Advance_apayment/index
ERROR - 2018-12-05 14:59:48 --> 404 Page Not Found: Advanceapayment/index
ERROR - 2018-12-05 15:00:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:06:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:07:39 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:07:39 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:08:15 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:08:15 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:08:40 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:08:40 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:09:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:09:46 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:09:46 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:09:57 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:09:57 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/transaction_report.php 196
ERROR - 2018-12-05 15:10:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:11:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 15:12:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:12:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:17:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:19:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:25:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:39:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 15:44:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 15:45:12 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 15:45:12 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 15:45:18 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 15:45:18 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 15:46:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 15:46:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 15:46:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 15:46:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 15:48:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 15:48:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 15:49:11 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 15:49:11 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 15:50:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 15:55:26 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 165
ERROR - 2018-12-05 15:56:14 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 165
ERROR - 2018-12-05 15:56:35 --> 404 Page Not Found: Report/day_report
ERROR - 2018-12-05 15:56:37 --> 404 Page Not Found: Report/day_report
ERROR - 2018-12-05 15:56:39 --> 404 Page Not Found: Report/day_report
ERROR - 2018-12-05 16:05:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:05:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:34:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 16:34:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:34:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 16:37:54 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/user/customer_travel.php 23
ERROR - 2018-12-05 16:37:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:37:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 16:37:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:38:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:38:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 16:38:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:38:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 16:38:37 --> Query error: Unknown column 'customerCompany' in 'where clause' - Invalid query: SELECT *
FROM `travel_booking`
WHERE `customerCompany` = 'Graphix'
ERROR - 2018-12-05 16:40:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:40:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:40:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 16:41:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 16:41:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 16:42:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:43:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:44:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:44:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:44:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:44:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:44:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:45:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:46:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:46:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:47:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:48:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:48:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:48:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:49:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:49:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:50:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:51:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:51:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:51:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:52:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:52:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:52:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:52:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:52:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:52:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:53:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:53:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:54:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:54:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:54:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:54:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:55:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:55:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:56:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:56:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:56:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:57:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:57:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 16:58:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:58:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 16:58:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 16:59:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 16:59:26 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 395
ERROR - 2018-12-05 16:59:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:00:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:00:11 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 395
ERROR - 2018-12-05 17:00:28 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 395
ERROR - 2018-12-05 17:00:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 17:01:42 --> 404 Page Not Found: Daybook/transaction_report
ERROR - 2018-12-05 17:01:44 --> 404 Page Not Found: Daybook/transaction_report
ERROR - 2018-12-05 17:01:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:01:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:01:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:03:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:04:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:04:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:04:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:05:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 17:05:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:05:34 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 461
ERROR - 2018-12-05 17:05:37 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 461
ERROR - 2018-12-05 17:07:04 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 461
ERROR - 2018-12-05 17:07:10 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 461
ERROR - 2018-12-05 17:08:17 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 461
ERROR - 2018-12-05 17:08:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 17:08:34 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 461
ERROR - 2018-12-05 17:08:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '102","114"]")' at line 2 - Invalid query: SELECT `firstName` FROM `travel_users`
        WHERE `companyId` in ("["102","114"]")
ERROR - 2018-12-05 17:08:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 17:08:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:09:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:10:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:10:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:10:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '102"]")' at line 2 - Invalid query: SELECT `firstName` FROM `travel_users`
        WHERE `companyId` in ("["102"]")
ERROR - 2018-12-05 17:10:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:11:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:11:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:11:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ']")' at line 2 - Invalid query: SELECT `firstName` FROM `travel_users`
        WHERE `companyId` in ("[102"]")
ERROR - 2018-12-05 17:12:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 17:12:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:13:38 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 461
ERROR - 2018-12-05 17:14:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:15:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:15:34 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 462
ERROR - 2018-12-05 17:15:39 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/controllers/Daybook.php 462
ERROR - 2018-12-05 17:16:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:16:32 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/controllers/Daybook.php 463
ERROR - 2018-12-05 17:16:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 17:16:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:17:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:19:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:19:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 17:21:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:21:59 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Daybook.php 472
ERROR - 2018-12-05 17:22:02 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Daybook.php 472
ERROR - 2018-12-05 17:22:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:22:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:22:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:22:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 17:22:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:23:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:24:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:26:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:30:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:30:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 17:36:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 17:36:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 17:40:39 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 84
ERROR - 2018-12-05 17:40:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 17:40:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 84
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 180
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 184
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 185
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 254
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 255
ERROR - 2018-12-05 17:42:41 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-05 19:03:18 --> Severity: Error --> Call to undefined function pr() /var/www/travel_app/application/controllers/Booking.php 248
ERROR - 2018-12-05 19:15:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:15:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:15:17 --> Severity: Error --> Call to undefined method User_model::select() /var/www/travel_app/application/models/User_model.php 216
ERROR - 2018-12-05 19:15:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:15:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:22:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:23:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:33:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:33:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:35:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:35:18 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Report.php 86
ERROR - 2018-12-05 19:37:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:37:15 --> Severity: Notice --> Undefined index: customerCompany /var/www/travel_app/application/controllers/Report.php 69
ERROR - 2018-12-05 19:37:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:39:06 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/models/Booking_model.php 24
ERROR - 2018-12-05 19:39:06 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT sum(priceCash+creditPaid) as totRevenue  FROM `travel_booking` WHERE `companyId` in (Array) and bookingDate >= '2018-12-05' and bookingDate <='2018-12-05' ORDER BY `bookingId`  DESC
ERROR - 2018-12-05 19:39:39 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/models/Booking_model.php 25
ERROR - 2018-12-05 19:39:39 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT sum(priceCash+creditPaid) as totRevenue  FROM `travel_booking` WHERE `companyId` in (Array) and bookingDate >= '2018-12-05' and bookingDate <='2018-12-05' ORDER BY `bookingId`  DESC
ERROR - 2018-12-05 19:39:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 19:39:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:39:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 19:40:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 19:40:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:48:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 19:48:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-05 19:53:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 19:53:32 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Daybook.php 472
ERROR - 2018-12-05 19:53:32 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT userId,`firstName` FROM `travel_users`
        WHERE `companyId` in (Array)
ERROR - 2018-12-05 19:53:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 19:53:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/transaction_report.php 106
ERROR - 2018-12-05 19:53:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/transaction_report.php 107
ERROR - 2018-12-05 19:53:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/transaction_report.php 108
ERROR - 2018-12-05 19:53:33 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/transaction_report.php 109
ERROR - 2018-12-05 19:53:33 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 222
ERROR - 2018-12-05 19:53:33 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 222
ERROR - 2018-12-05 19:53:59 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:53:59 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:54:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:54:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:54:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:54:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:54:20 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:54:20 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:55:05 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:55:05 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:55:10 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:55:10 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 19:57:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-05 19:57:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-05 19:57:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-05 19:57:49 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-05 20:08:16 --> Query error: Unknown column 'incomeId' in 'order clause' - Invalid query: SELECT sum(credit) as totIncome  FROM `income` WHERE `companyId` in (102,103) and `incomeDate` >= '2018-12-05' and `incomeDate` <='2018-12-08' ORDER BY `incomeId`  DESC
ERROR - 2018-12-05 20:09:01 --> Severity: Error --> Call to undefined method CI_Loader::get_company_name() /var/www/travel_app/application/views/admin/transaction_report.php 116
ERROR - 2018-12-05 20:09:32 --> Severity: Error --> Call to undefined function get_company_name() /var/www/travel_app/application/views/admin/transaction_report.php 116
ERROR - 2018-12-05 20:11:09 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:11:09 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:11:16 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:11:16 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:11:26 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Daybook.php 474
ERROR - 2018-12-05 20:11:26 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT userId,`firstName` FROM `travel_users`
        WHERE `companyId` in (Array)
ERROR - 2018-12-05 20:11:27 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:11:27 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:19:28 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Daybook.php 479
ERROR - 2018-12-05 20:19:28 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT userId,`firstName` FROM `travel_users`
        WHERE `companyId` in (Array)
ERROR - 2018-12-05 20:19:29 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:19:29 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:19:35 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Daybook.php 479
ERROR - 2018-12-05 20:19:35 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT userId,`firstName` FROM `travel_users`
        WHERE `companyId` in (Array)
ERROR - 2018-12-05 20:19:37 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/controllers/Daybook.php 479
ERROR - 2018-12-05 20:19:37 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT userId,`firstName` FROM `travel_users`
        WHERE `companyId` in (Array)
ERROR - 2018-12-05 20:19:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-05 20:19:38 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:19:38 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 196
ERROR - 2018-12-05 20:20:48 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 20:20:48 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/user/income_report.php 214
ERROR - 2018-12-05 20:39:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 20:46:11 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/controllers/Daybook.php 723
ERROR - 2018-12-05 20:46:51 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/controllers/Daybook.php 723
ERROR - 2018-12-05 20:47:12 --> Query error: Column 'companyId' in field list is ambiguous - Invalid query: SELECT `companyId`, `companyName`
FROM `travel_users`
JOIN `travel_company` ON `travel_company`.`companyId`=`travel_users`.`companyId`
WHERE `travel_users`.`userEmail` = 'Dr@dr.com'
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:31 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:47:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:53 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:48:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyId' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:17 --> Severity: Warning --> Illegal string offset 'companyName' /var/www/travel_app/application/views/user/income.php 191
ERROR - 2018-12-05 20:50:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 21:17:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-05 21:17:47 --> 404 Page Not Found: Assets/lib
