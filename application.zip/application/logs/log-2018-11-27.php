<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-27 09:18:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 09:19:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 09:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 09:19:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 09:19:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 09:19:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 09:21:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 09:21:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 09:21:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 09:29:24 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 09:29:24 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 09:36:50 --> Severity: Notice --> Undefined property: stdClass::$creditLimit /var/www/travel_app/application/controllers/Booking.php 144
ERROR - 2018-11-27 09:38:18 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/travel_app/application/controllers/Booking.php 147
ERROR - 2018-11-27 09:38:44 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 09:38:44 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 09:39:38 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 09:39:38 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 09:43:16 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 09:43:16 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 09:45:34 --> Severity: Notice --> Undefined index: price /var/www/travel_app/application/views/user/customer_travel.php 71
ERROR - 2018-11-27 09:45:34 --> Severity: Notice --> Undefined index: price /var/www/travel_app/application/views/user/customer_travel.php 71
ERROR - 2018-11-27 09:45:34 --> Severity: Notice --> Undefined index: price /var/www/travel_app/application/views/user/customer_travel.php 71
ERROR - 2018-11-27 09:45:34 --> Severity: Notice --> Undefined index: price /var/www/travel_app/application/views/user/customer_travel.php 71
ERROR - 2018-11-27 09:45:34 --> Severity: Notice --> Undefined index: price /var/www/travel_app/application/views/user/customer_travel.php 71
ERROR - 2018-11-27 09:45:34 --> Severity: Notice --> Undefined index: price /var/www/travel_app/application/views/user/customer_travel.php 71
ERROR - 2018-11-27 09:45:34 --> Severity: Notice --> Undefined index: price /var/www/travel_app/application/views/user/customer_travel.php 71
ERROR - 2018-11-27 09:51:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 09:51:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 09:53:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 09:53:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:16:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:16:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:16:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:16:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:16:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:29:30 --> Severity: Notice --> Undefined variable: customerName /var/www/travel_app/application/views/user/flight_update.php 21
ERROR - 2018-11-27 10:29:30 --> Severity: Notice --> Undefined variable: customerName /var/www/travel_app/application/views/user/flight_update.php 27
ERROR - 2018-11-27 10:43:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:44:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:44:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:44:51 --> 404 Page Not Found: User/get_flightNumber
ERROR - 2018-11-27 10:44:52 --> 404 Page Not Found: User/get_flightNumber
ERROR - 2018-11-27 10:45:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:45:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:45:30 --> Severity: Warning --> Missing argument 1 for User::get_flightNumber() /var/www/travel_app/application/controllers/User.php 144
ERROR - 2018-11-27 10:45:30 --> Severity: Notice --> Undefined variable: flightNumber /var/www/travel_app/application/controllers/User.php 147
ERROR - 2018-11-27 10:45:30 --> Query error: Table 'travel_app_db.travel_BOOKING' doesn't exist - Invalid query: SELECT DISTINCT(flightNo)
FROM `travel_BOOKING`
WHERE `flightNo` IS NULL
ERROR - 2018-11-27 10:45:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:45:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:45:50 --> Severity: Notice --> Undefined variable: flightNumber /var/www/travel_app/application/controllers/User.php 147
ERROR - 2018-11-27 10:45:50 --> Query error: Table 'travel_app_db.travel_BOOKING' doesn't exist - Invalid query: SELECT DISTINCT(flightNo)
FROM `travel_BOOKING`
WHERE `flightNo` IS NULL
ERROR - 2018-11-27 10:46:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:47:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:47:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:58:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:59:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:59:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:59:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:59:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 10:59:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 10:59:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:03:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:03:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:10:05 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::group_by() /var/www/travel_app/application/controllers/User.php 156
ERROR - 2018-11-27 11:29:09 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 11:29:09 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 11:29:15 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/controllers/User.php 171
ERROR - 2018-11-27 11:29:53 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/travel_app/application/controllers/User.php 171
ERROR - 2018-11-27 11:31:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:31:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:32:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:32:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:32:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:32:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:35:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:36:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:36:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:36:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:36:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:38:26 --> 404 Page Not Found: Report/day_book
ERROR - 2018-11-27 11:40:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:40:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:40:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:41:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:42:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:42:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:42:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:43:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:43:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:43:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:44:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:45:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:46:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:49:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:49:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:49:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:49:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:49:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:49:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:49:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:49:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 11:51:19 --> Severity: Notice --> Undefined variable: customerName /var/www/travel_app/application/views/user/day_book.php 24
ERROR - 2018-11-27 11:51:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:52:11 --> Severity: Notice --> Undefined variable: customerName /var/www/travel_app/application/views/user/day_book.php 24
ERROR - 2018-11-27 11:52:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:53:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:55:33 --> Severity: Error --> Call to undefined method CI_Session::get_flashdata() /var/www/travel_app/application/views/user/flight_update.php 19
ERROR - 2018-11-27 11:55:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:56:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:57:26 --> Severity: Error --> Call to undefined method CI_Session::get_flashdata() /var/www/travel_app/application/views/user/flight_update.php 19
ERROR - 2018-11-27 11:57:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:58:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:58:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 11:58:34 --> Severity: Error --> Call to undefined method CI_Session::get_flashdata() /var/www/travel_app/application/views/user/flight_update.php 19
ERROR - 2018-11-27 11:59:36 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/travel_app/application/views/user/flight_update.php 19
ERROR - 2018-11-27 11:59:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 12:00:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:03:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:03:46 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-11-27 12:03:46 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_customer`
WHERE `customerFirstname` = Array
ERROR - 2018-11-27 12:05:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:05:07 --> Severity: Notice --> Array to string conversion /var/www/travel_app/system/database/DB_query_builder.php 2442
ERROR - 2018-11-27 12:05:07 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `travel_customer`
WHERE `customerFirstname` = Array
ERROR - 2018-11-27 12:06:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:06:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:07:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:07:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:07:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:09:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:11:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:16:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:16:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:17:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:17:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:17:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:17:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:18:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:18:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:22:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:22:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:22:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:22:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:24:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:24:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:24:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:24:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:24:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:24:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:25:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:25:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:25:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:25:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:26:01 --> 404 Page Not Found: Report/day_book
ERROR - 2018-11-27 12:26:01 --> Severity: Notice --> Undefined index: user /var/www/travel_app/application/controllers/Report.php 89
ERROR - 2018-11-27 12:26:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:26:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:26:24 --> Severity: Notice --> Undefined index: user /var/www/travel_app/application/controllers/Report.php 89
ERROR - 2018-11-27 12:26:24 --> Severity: Notice --> Undefined index: user /var/www/travel_app/application/controllers/Report.php 89
ERROR - 2018-11-27 12:26:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:27:15 --> Severity: Warning --> Missing argument 1 for Report_model::day_book(), called in /var/www/travel_app/application/controllers/Report.php on line 89 and defined /var/www/travel_app/application/models/Report_model.php 19
ERROR - 2018-11-27 12:27:15 --> Severity: Notice --> Undefined variable: data /var/www/travel_app/application/models/Report_model.php 22
ERROR - 2018-11-27 12:27:15 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Report_model.php 22
ERROR - 2018-11-27 12:27:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:27:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:27:43 --> Severity: Warning --> Illegal string offset 'customers' /var/www/travel_app/application/models/Report_model.php 22
ERROR - 2018-11-27 12:27:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:27:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:27:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:27:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:27:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:27:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:27:49 --> Severity: Warning --> Illegal string offset 'customers' /var/www/travel_app/application/models/Report_model.php 22
ERROR - 2018-11-27 12:27:49 --> Severity: Warning --> Illegal string offset 'customers' /var/www/travel_app/application/models/Report_model.php 22
ERROR - 2018-11-27 12:27:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:27:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:28:26 --> Severity: Warning --> Illegal string offset 'users' /var/www/travel_app/application/models/Report_model.php 22
ERROR - 2018-11-27 12:28:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:28:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:28:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:28:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:29:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:31:09 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 12:31:09 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 12:31:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:31:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:31:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:31:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:31:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:31:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:32:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:32:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:33:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:33:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:33:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:33:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:33:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 12:33:38 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 12:33:38 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 12:33:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:33:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:33:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:34:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:34:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:34:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:35:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:35:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:37:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:37:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:37:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 12:38:34 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 12:38:34 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 12:38:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:40:26 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 122
ERROR - 2018-11-27 12:40:26 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 12:40:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 12:41:57 --> Severity: Notice --> Undefined property: stdClass::$price /var/www/travel_app/application/views/user/ticket_details.php 134
ERROR - 2018-11-27 12:44:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:45:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:46:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:49:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:49:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:51:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:52:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:53:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:53:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:54:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:54:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:54:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 12:54:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:55:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 12:55:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:55:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 12:55:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:56:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 12:56:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:56:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:57:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:57:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:57:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 12:57:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 12:58:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:00:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:00:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:04:18 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:05:00 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:05:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 121
ERROR - 2018-11-27 13:05:28 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:05:54 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:06:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:06:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:06:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:06:41 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:06:42 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:06:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:06:44 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Booking.php 121
ERROR - 2018-11-27 13:06:58 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:07:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:07:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:07:22 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:07:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:07:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:08:02 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:08:05 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:08:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:08:29 --> 404 Page Not Found: Admin/admin
ERROR - 2018-11-27 13:08:58 --> 404 Page Not Found: Admin/admin
ERROR - 2018-11-27 13:09:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:09:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:09:03 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`travel_app_db`.`travel_customer`, CONSTRAINT `travel_customer_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: UPDATE `travel_company` SET `notification_status` = 0, `companyId` = '102'
ERROR - 2018-11-27 13:09:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:09:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:10:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:10:48 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:11:41 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:11:43 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 13:12:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 13:12:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:13:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:13:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:13:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:13:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:13:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 13:14:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:15:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:16:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 13:16:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:16:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:16:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:16:52 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`travel_app_db`.`travel_customer`, CONSTRAINT `travel_customer_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: UPDATE `travel_company` SET `notification_status` = 0, `companyId` = '102'
ERROR - 2018-11-27 13:17:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:17:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:17:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:17:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:18:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:18:12 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`travel_app_db`.`travel_customer`, CONSTRAINT `travel_customer_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: UPDATE `travel_company` SET `notification_status` = 1, `companyId` = '102'
ERROR - 2018-11-27 13:18:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:18:51 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`travel_app_db`.`travel_customer`, CONSTRAINT `travel_customer_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: UPDATE `travel_company` SET `notification_status` = 0, `companyId` = '102'
ERROR - 2018-11-27 13:18:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:19:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:19:29 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`travel_app_db`.`travel_customer`, CONSTRAINT `travel_customer_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: UPDATE `travel_company` SET `notification_status` = 0, `companyId` = '102'
ERROR - 2018-11-27 13:19:38 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`travel_app_db`.`travel_customer`, CONSTRAINT `travel_customer_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `travel_company` (`companyId`) ON DELETE CASCADE ON UPDATE NO ACTION) - Invalid query: UPDATE `travel_company` SET `notification_status` = 0, `companyId` = '102'
ERROR - 2018-11-27 13:20:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:20:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:20:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:21:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:21:23 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$last_query /var/www/travel_app/application/controllers/Admin.php 116
ERROR - 2018-11-27 13:21:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:21:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:21:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:21:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:22:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:22:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:22:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:22:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:22:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:23:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:23:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:23:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:23:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:23:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:23:54 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 13:24:31 --> Severity: Notice --> Undefined property: Welcome::$user_model /var/www/travel_app/application/controllers/Welcome.php 331
ERROR - 2018-11-27 13:24:31 --> Severity: Error --> Call to a member function total_booking() on null /var/www/travel_app/application/controllers/Welcome.php 331
ERROR - 2018-11-27 14:08:14 --> Severity: Error --> Call to undefined function MONTH() /var/www/travel_app/application/models/First_model.php 75
ERROR - 2018-11-27 14:08:42 --> Severity: Error --> Call to undefined function MONTH() /var/www/travel_app/application/models/First_model.php 75
ERROR - 2018-11-27 14:08:46 --> Severity: Error --> Call to undefined function MONTH() /var/www/travel_app/application/models/First_model.php 75
ERROR - 2018-11-27 14:08:47 --> Severity: Error --> Call to undefined function MONTH() /var/www/travel_app/application/models/First_model.php 75
ERROR - 2018-11-27 14:08:54 --> Severity: Error --> Call to undefined function MONTH() /var/www/travel_app/application/models/First_model.php 75
ERROR - 2018-11-27 14:13:04 --> Severity: Notice --> Undefined property: Welcome::$user_model /var/www/travel_app/application/controllers/Welcome.php 333
ERROR - 2018-11-27 14:13:04 --> Severity: Error --> Call to a member function total_redit() on null /var/www/travel_app/application/controllers/Welcome.php 333
ERROR - 2018-11-27 14:13:37 --> Severity: Notice --> Undefined property: Welcome::$user_model /var/www/travel_app/application/controllers/Welcome.php 333
ERROR - 2018-11-27 14:13:37 --> Severity: Error --> Call to a member function total_redit() on null /var/www/travel_app/application/controllers/Welcome.php 333
ERROR - 2018-11-27 14:13:38 --> Severity: Notice --> Undefined property: Welcome::$user_model /var/www/travel_app/application/controllers/Welcome.php 333
ERROR - 2018-11-27 14:13:38 --> Severity: Error --> Call to a member function total_redit() on null /var/www/travel_app/application/controllers/Welcome.php 333
ERROR - 2018-11-27 14:14:38 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 14:15:38 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 14:15:39 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 14:16:14 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 14:16:39 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 14:16:42 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/ticket_details.php 559
ERROR - 2018-11-27 14:16:51 --> Severity: Notice --> Undefined variable: cid /var/www/travel_app/application/views/user/ticket_details.php 163
ERROR - 2018-11-27 14:16:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-27 14:20:34 --> Severity: Notice --> Undefined variable: cid /var/www/travel_app/application/views/user/ticket_details.php 163
ERROR - 2018-11-27 14:20:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-27 14:22:47 --> Severity: Notice --> Undefined variable: cid /var/www/travel_app/application/views/user/ticket_details.php 163
ERROR - 2018-11-27 14:22:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/First_model.php 17
ERROR - 2018-11-27 14:26:32 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/travel_app/application/models/First_model.php 97
ERROR - 2018-11-27 14:26:38 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/travel_app/application/models/First_model.php 97
ERROR - 2018-11-27 14:26:42 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/travel_app/application/models/First_model.php 97
ERROR - 2018-11-27 14:26:52 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/travel_app/application/models/First_model.php 97
ERROR - 2018-11-27 14:27:07 --> 404 Page Not Found: Report/index
ERROR - 2018-11-27 14:27:10 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/travel_app/application/models/First_model.php 97
ERROR - 2018-11-27 14:27:11 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/travel_app/application/models/First_model.php 97
ERROR - 2018-11-27 14:27:31 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/travel_app/application/models/First_model.php 97
ERROR - 2018-11-27 14:28:23 --> Severity: Error --> Call to undefined method First_model::total_redit() /var/www/travel_app/application/controllers/Welcome.php 333
ERROR - 2018-11-27 14:28:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:29:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:29:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:30:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:30:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:30:42 --> Severity: Error --> Call to undefined method First_model::total_cash() /var/www/travel_app/application/controllers/Welcome.php 335
ERROR - 2018-11-27 14:31:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:31:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:32:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:37:42 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/travel_app/application/models/Notification_model.php 62
ERROR - 2018-11-27 14:38:19 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/travel_app/application/models/Notification_model.php 62
ERROR - 2018-11-27 14:40:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:41:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:42:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 14:44:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 14:45:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:07:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 176
ERROR - 2018-11-27 15:07:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 176
ERROR - 2018-11-27 15:11:13 --> Severity: Parsing Error --> syntax error, unexpected 'font' (T_STRING) /var/www/travel_app/application/models/Notification_model.php 172
ERROR - 2018-11-27 15:12:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 15
ERROR - 2018-11-27 15:12:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 15
ERROR - 2018-11-27 15:12:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 15
ERROR - 2018-11-27 15:12:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 15
ERROR - 2018-11-27 15:13:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:13:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:13:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 16
ERROR - 2018-11-27 15:13:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 16
ERROR - 2018-11-27 15:13:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 16
ERROR - 2018-11-27 15:13:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 16
ERROR - 2018-11-27 15:14:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 17
ERROR - 2018-11-27 15:14:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 17
ERROR - 2018-11-27 15:14:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 17
ERROR - 2018-11-27 15:14:49 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 17
ERROR - 2018-11-27 15:16:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 17
ERROR - 2018-11-27 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 17
ERROR - 2018-11-27 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 17
ERROR - 2018-11-27 15:16:40 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 17
ERROR - 2018-11-27 15:17:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:17:22 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 16
ERROR - 2018-11-27 15:17:22 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/models/Notification_model.php 16
ERROR - 2018-11-27 15:18:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:18:41 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:18:41 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:18:42 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:18:42 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:18:42 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:20:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:21:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:21:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:21:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:33:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:36:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:37:12 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:37:12 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:37:13 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:37:13 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:37:13 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:37:13 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:38:26 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:38:26 --> 404 Page Not Found: User/images
ERROR - 2018-11-27 15:41:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:41:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 15:44:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:44:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 15:44:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:50:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:56:00 --> 404 Page Not Found: Admin/add_customer
ERROR - 2018-11-27 15:56:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:56:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:57:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 15:57:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 15:58:08 --> Severity: Error --> Call to undefined method First_model::total_booking_graph() /var/www/travel_app/application/controllers/Welcome.php 350
ERROR - 2018-11-27 15:58:10 --> Severity: Error --> Call to undefined method First_model::total_booking_graph() /var/www/travel_app/application/controllers/Welcome.php 350
ERROR - 2018-11-27 15:59:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:02:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:03:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:03:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:03:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:05:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 16:05:44 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:05:44 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:05:45 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:05:45 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:05:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:07:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:08:41 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/travel_app/application/controllers/Welcome.php 92
ERROR - 2018-11-27 16:09:53 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/travel_app/application/controllers/Welcome.php 92
ERROR - 2018-11-27 16:10:29 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/travel_app/application/controllers/Welcome.php 92
ERROR - 2018-11-27 16:10:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:12:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:12:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:12:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 16:12:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:14:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:15:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:16:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:16:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/css
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/css
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/css
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:50 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/css
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/css
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/css
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:51 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:52 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:52 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:52 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:52 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:52 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:52 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:52 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:16:52 --> 404 Page Not Found: Welcome/lib
ERROR - 2018-11-27 16:18:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 16:18:22 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:22 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:23 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:18:24 --> 404 Page Not Found: Welcome/show_data.php
ERROR - 2018-11-27 16:18:24 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:20:41 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:20:41 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:20:42 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:20:42 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:20:42 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:20:43 --> 404 Page Not Found: Welcome/img
ERROR - 2018-11-27 16:21:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:24:28 --> Severity: 4096 --> Object of class Welcome could not be converted to string /var/www/travel_app/application/controllers/Welcome.php 62
ERROR - 2018-11-27 16:24:28 --> Severity: Notice --> Object of class Welcome to string conversion /var/www/travel_app/application/controllers/Welcome.php 62
ERROR - 2018-11-27 16:24:28 --> Severity: Notice --> Undefined property: Welcome::$Object /var/www/travel_app/application/controllers/Welcome.php 62
ERROR - 2018-11-27 16:24:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 62
ERROR - 2018-11-27 16:24:28 --> Severity: Error --> Call to a member function send_reset_mail() on null /var/www/travel_app/application/controllers/Welcome.php 62
ERROR - 2018-11-27 16:43:28 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:43:30 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:43:33 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:43:50 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:43:53 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:39 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:40 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:40 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:40 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:41 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:41 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:41 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:41 --> Severity: Parsing Error --> syntax error, unexpected '%' /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:51 --> Severity: Parsing Error --> syntax error, unexpected 'Y' (T_STRING) /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:52 --> Severity: Parsing Error --> syntax error, unexpected 'Y' (T_STRING) /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:44:53 --> Severity: Parsing Error --> syntax error, unexpected 'Y' (T_STRING) /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:45:50 --> Severity: Parsing Error --> syntax error, unexpected 'Y' (T_STRING) /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:45:50 --> Severity: Parsing Error --> syntax error, unexpected 'Y' (T_STRING) /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:45:51 --> Severity: Parsing Error --> syntax error, unexpected 'Y' (T_STRING) /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:45:51 --> Severity: Parsing Error --> syntax error, unexpected 'Y' (T_STRING) /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:45:51 --> Severity: Parsing Error --> syntax error, unexpected 'Y' (T_STRING) /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:46:15 --> Severity: Notice --> Undefined property: Welcome::$notification_model /var/www/travel_app/application/controllers/Welcome.php 62
ERROR - 2018-11-27 16:46:15 --> Severity: Error --> Call to a member function send_reset_mail() on null /var/www/travel_app/application/controllers/Welcome.php 62
ERROR - 2018-11-27 16:48:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:48:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:48:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:49:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:49:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:49:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:38 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::get() /var/www/travel_app/application/models/First_model.php 99
ERROR - 2018-11-27 16:50:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:42 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:50:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 16:52:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:02:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:02:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:03:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:04:22 --> Severity: Notice --> Undefined variable: userEmail /var/www/travel_app/application/models/Notification_model.php 392
ERROR - 2018-11-27 17:04:22 --> Severity: Error --> Cannot access empty property /var/www/travel_app/application/models/Notification_model.php 392
ERROR - 2018-11-27 17:09:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:10:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:11:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:11:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:11:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:13:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:13:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:13:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:14:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:14:17 --> 404 Page Not Found: Welcome/assets
ERROR - 2018-11-27 17:14:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:14:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:14:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:14:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:15:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:15:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:15:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:15:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:17:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:17:04 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:17:11 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:17:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:17:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:17:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:17:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:19:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:19:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:20:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:21:31 --> 404 Page Not Found: Assets/img
ERROR - 2018-11-27 17:26:51 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:26:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:27:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:27:15 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:27:21 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:27:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:27:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:29:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:29:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:29:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:29:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:29:08 --> Severity: Notice --> Undefined variable: POST /var/www/travel_app/application/controllers/Report.php 106
ERROR - 2018-11-27 17:31:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:31:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:31:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:31:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:31:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:33:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:33:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:33:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:33:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:33:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:33:17 --> 404 Page Not Found: Welcome/assets
ERROR - 2018-11-27 17:33:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:33:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:33:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:33:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:34:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:34:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:40:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:40:35 --> 404 Page Not Found: Welcome/assets
ERROR - 2018-11-27 17:43:06 --> 404 Page Not Found: Assets/img
ERROR - 2018-11-27 17:43:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:43:37 --> 404 Page Not Found: Assets/img
ERROR - 2018-11-27 17:43:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:44:02 --> 404 Page Not Found: Assets/img
ERROR - 2018-11-27 17:45:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:45:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:46:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:46:01 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:46:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:46:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:46:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:46:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:46:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:47:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:47:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:47:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:47:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:48:57 --> 404 Page Not Found: Assets/img
ERROR - 2018-11-27 17:49:05 --> Severity: Notice --> Undefined variable: user /var/www/travel_app/application/views/user/customer_travel.php 102
ERROR - 2018-11-27 17:49:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:49:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:49:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:49:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:49:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:49:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:49:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:49:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:50:47 --> 404 Page Not Found: Assets/img
ERROR - 2018-11-27 17:51:50 --> 404 Page Not Found: Assets/img
ERROR - 2018-11-27 17:53:51 --> Severity: Parsing Error --> syntax error, unexpected 'Verification' (T_STRING), expecting ',' or ';' /var/www/travel_app/application/controllers/Welcome.php 67
ERROR - 2018-11-27 17:54:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:55:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:55:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:55:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 17:55:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 17:55:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 17:58:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` = ''' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` = ''
ERROR - 2018-11-27 18:02:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` IS NULL' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` IS NULL
ERROR - 2018-11-27 18:02:08 --> Severity: Notice --> Undefined variable: id /var/www/travel_app/application/views/reset_pass.php 30
ERROR - 2018-11-27 18:02:08 --> Severity: Notice --> Undefined variable: id /var/www/travel_app/application/views/reset_pass.php 30
ERROR - 2018-11-27 18:03:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` IS NULL' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` IS NULL
ERROR - 2018-11-27 18:04:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` IS NULL' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` IS NULL
ERROR - 2018-11-27 18:04:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` IS NULL' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` IS NULL
ERROR - 2018-11-27 18:04:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` IS NULL' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` IS NULL
ERROR - 2018-11-27 18:05:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` IS NULL' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` IS NULL
ERROR - 2018-11-27 18:06:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` IS NULL' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` IS NULL
ERROR - 2018-11-27 18:06:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 18:06:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` = '1'' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` = '1'
ERROR - 2018-11-27 18:07:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '123 = ''
WHERE `userId` = '1'' at line 1 - Invalid query: UPDATE `travel_users` SET 123 = ''
WHERE `userId` = '1'
ERROR - 2018-11-27 18:07:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 18:08:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 18:08:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:09:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:12:42 --> Query error: Unknown column 'priceCredit=' in 'field list' - Invalid query: UPDATE `travel_booking` SET `priceCredit=` = 0
WHERE `bookingId` = '9'
ERROR - 2018-11-27 18:13:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:13:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:14:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:14:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:18:59 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:18:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:19:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:19:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:19:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:19:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:20:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:20:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:21:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:21:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:21:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:21:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:22:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:22:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:23:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:23:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:24:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:24:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:25:24 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:25:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:25:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:25:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:26:50 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:26:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:28:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:28:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:29:03 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:30:53 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:30:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:31:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:31:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:33:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:33:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:33:26 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:33:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:35:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:35:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:35:13 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:35:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:35:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:35:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:35:32 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:35:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:36:23 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:36:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:36:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 18:36:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:36:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:36:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:36:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:37:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:37:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:37:16 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:37:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:38:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 18:38:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:38:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:38:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:38:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:39:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:39:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:39:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 18:39:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-11-27 18:58:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 18:59:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:00:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:18:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-11-27 19:18:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:18:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:19:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:19:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:23:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:23:10 --> 404 Page Not Found: Admin/customer_list
ERROR - 2018-11-27 19:23:46 --> Severity: Notice --> Undefined variable: students /var/www/travel_app/application/views/admin/list_customers.php 33
ERROR - 2018-11-27 19:23:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/list_customers.php 33
ERROR - 2018-11-27 19:24:18 --> Severity: Notice --> Undefined variable: customer /var/www/travel_app/application/views/admin/list_customers.php 33
ERROR - 2018-11-27 19:24:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/list_customers.php 33
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_no /var/www/travel_app/application/views/admin/list_customers.php 36
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_date /var/www/travel_app/application/views/admin/list_customers.php 37
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: name /var/www/travel_app/application/views/admin/list_customers.php 38
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: dob /var/www/travel_app/application/views/admin/list_customers.php 39
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: mobile /var/www/travel_app/application/views/admin/list_customers.php 40
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: father_name /var/www/travel_app/application/views/admin/list_customers.php 41
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: address /var/www/travel_app/application/views/admin/list_customers.php 42
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: post /var/www/travel_app/application/views/admin/list_customers.php 43
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: pin_code /var/www/travel_app/application/views/admin/list_customers.php 44
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: email /var/www/travel_app/application/views/admin/list_customers.php 45
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 47
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 49
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_no /var/www/travel_app/application/views/admin/list_customers.php 36
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_date /var/www/travel_app/application/views/admin/list_customers.php 37
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: name /var/www/travel_app/application/views/admin/list_customers.php 38
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: dob /var/www/travel_app/application/views/admin/list_customers.php 39
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: mobile /var/www/travel_app/application/views/admin/list_customers.php 40
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: father_name /var/www/travel_app/application/views/admin/list_customers.php 41
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: address /var/www/travel_app/application/views/admin/list_customers.php 42
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: post /var/www/travel_app/application/views/admin/list_customers.php 43
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: pin_code /var/www/travel_app/application/views/admin/list_customers.php 44
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: email /var/www/travel_app/application/views/admin/list_customers.php 45
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 47
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 49
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_no /var/www/travel_app/application/views/admin/list_customers.php 36
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_date /var/www/travel_app/application/views/admin/list_customers.php 37
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: name /var/www/travel_app/application/views/admin/list_customers.php 38
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: dob /var/www/travel_app/application/views/admin/list_customers.php 39
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: mobile /var/www/travel_app/application/views/admin/list_customers.php 40
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: father_name /var/www/travel_app/application/views/admin/list_customers.php 41
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: address /var/www/travel_app/application/views/admin/list_customers.php 42
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: post /var/www/travel_app/application/views/admin/list_customers.php 43
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: pin_code /var/www/travel_app/application/views/admin/list_customers.php 44
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: email /var/www/travel_app/application/views/admin/list_customers.php 45
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 47
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 49
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_no /var/www/travel_app/application/views/admin/list_customers.php 36
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_date /var/www/travel_app/application/views/admin/list_customers.php 37
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: name /var/www/travel_app/application/views/admin/list_customers.php 38
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: dob /var/www/travel_app/application/views/admin/list_customers.php 39
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: mobile /var/www/travel_app/application/views/admin/list_customers.php 40
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: father_name /var/www/travel_app/application/views/admin/list_customers.php 41
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: address /var/www/travel_app/application/views/admin/list_customers.php 42
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: post /var/www/travel_app/application/views/admin/list_customers.php 43
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: pin_code /var/www/travel_app/application/views/admin/list_customers.php 44
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: email /var/www/travel_app/application/views/admin/list_customers.php 45
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 47
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 49
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_no /var/www/travel_app/application/views/admin/list_customers.php 36
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: adm_date /var/www/travel_app/application/views/admin/list_customers.php 37
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: name /var/www/travel_app/application/views/admin/list_customers.php 38
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: dob /var/www/travel_app/application/views/admin/list_customers.php 39
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: mobile /var/www/travel_app/application/views/admin/list_customers.php 40
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: father_name /var/www/travel_app/application/views/admin/list_customers.php 41
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: address /var/www/travel_app/application/views/admin/list_customers.php 42
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: post /var/www/travel_app/application/views/admin/list_customers.php 43
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: pin_code /var/www/travel_app/application/views/admin/list_customers.php 44
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: email /var/www/travel_app/application/views/admin/list_customers.php 45
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 47
ERROR - 2018-11-27 19:24:35 --> Severity: Notice --> Undefined index: id /var/www/travel_app/application/views/admin/list_customers.php 49
ERROR - 2018-11-27 19:26:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:30:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:33:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:34:05 --> 404 Page Not Found: User/student_details
ERROR - 2018-11-27 19:34:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:35:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:35:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:35:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:39:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:43:26 --> 404 Page Not Found: User/student_details
ERROR - 2018-11-27 19:44:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:47:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 19:49:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-11-27 21:07:22 --> 404 Page Not Found: Admin/list_customer
