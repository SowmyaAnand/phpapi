<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-15 09:42:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 10:52:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-15 11:25:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 11:30:58 --> 404 Page Not Found: Admin/add_customer_admin
ERROR - 2018-12-15 12:00:09 --> 404 Page Not Found: Admin/add_customer_admin
ERROR - 2018-12-15 12:00:13 --> 404 Page Not Found: Admin/add_customer_admin
ERROR - 2018-12-15 12:01:17 --> 404 Page Not Found: Admin/add_customer_admin
ERROR - 2018-12-15 12:03:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 91
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-15 12:38:42 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-15 12:42:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 12:44:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-15 12:44:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-15 12:44:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-15 12:44:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 12:44:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 12:44:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-15 12:44:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-15 12:44:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-15 12:49:25 --> Query error: Unknown column 'usercompany' in 'field list' - Invalid query: INSERT INTO `travel_booking` (`company`, `passengerName`, `travelFrom`, `travelTo`, `departureDateTime`, `arrivalDateTime`, `flightNo`, `pnr`, `priceCash`, `priceCredit`, `tax`, `bookingDate`, `usercompany`, `paymentType`, `airline`, `airline_cost`, `service_charge`, `companyId`, `createdBy`) VALUES ('RTwoCompany', 'RTwoCompanyPassenger', '26', '63', '2018-12-15 18:47', '2018-12-16 12:47', 'RTwof1', '20', '6500', '4500', '1000', '2018-12-15', '', 2, '1', '2000', '1500', '102', '2')
ERROR - 2018-12-15 12:52:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 13:07:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 13:10:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 13:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-15 13:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-15 13:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-15 13:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 13:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 13:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-15 13:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-15 13:15:36 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-15 13:15:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 13:16:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 13:17:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 13:17:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-15 13:17:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-15 13:17:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-15 13:17:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 13:17:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 13:17:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-15 13:17:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-15 13:17:47 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-15 13:22:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-15 13:22:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-15 13:22:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-15 13:22:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 13:22:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 13:22:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-15 13:22:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-15 13:22:24 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-15 14:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-15 14:16:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 14:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-15 14:31:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 14:31:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 14:33:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-15 14:33:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-15 14:33:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-15 14:33:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 14:33:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 14:33:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-15 14:33:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-15 14:33:12 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-15 15:00:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:00:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:00:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 15:00:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:00:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:00:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:02:37 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:02:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:02:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:02:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:03:20 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:03:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:03:25 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:03:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:03:34 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:03:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:03:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:03:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:05:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:05:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:05:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:05:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:05:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:05:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:10:41 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:10:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:10:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:10:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:10:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:10:55 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:10:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:11:06 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:11:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:11:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:11:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:16:17 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-15 15:16:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:16:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:18:10 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:18:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:18:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:18:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:18:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:18:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:18:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:18:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:19:12 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:19:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:20:52 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:20:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:21:02 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:21:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:22:35 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-15 15:22:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:22:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:28:48 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-15 15:28:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 15:28:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:28:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:29:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:29:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:32:05 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:32:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:32:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:32:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:32:09 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:32:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:32:18 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:32:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:33:16 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/views/admin/credit_payment.php 135
ERROR - 2018-12-15 15:33:17 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:33:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:33:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:33:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 15:33:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:33:43 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:33:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:33:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:33:47 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 15:33:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 15:40:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 15:56:32 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-15 15:56:32 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-15 15:56:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) where exp.`expenseDate` >= '2018-12-15' and exp.`expenseDate` <='2018-12-15' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-15 15:56:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 15:56:39 --> 404 Page Not Found: Booking/trial-balance
ERROR - 2018-12-15 15:56:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 15:56:46 --> 404 Page Not Found: Booking/balance-sheet
ERROR - 2018-12-15 15:56:52 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-15 15:56:52 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 117
ERROR - 2018-12-15 15:56:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT SUM(exp.debit-ROUND(exp.debit*(et.depreciation/100),2)) as fAsset FROM `expense` as exp left join expense_type as et on(et.exp_type_id = exp.expenseType) where exp.`expenseDate` >= '2018-12-15' and exp.`expenseDate` <='2018-12-15' and et.status in (1) and exp.companyId in ()
ERROR - 2018-12-15 15:58:04 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-15 15:58:04 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 288
ERROR - 2018-12-15 15:58:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and tb.`bookingDate` >= '2018-12-15' and tb.`bookingDate` <='2018-12-15'' at line 1 - Invalid query: SELECT (tb.priceCash+tb.creditPaid) as totTicket, tc.companyName as company  FROM `travel_booking` as tb left join travel_company as tc on(tc.companyId = tb.companyId) WHERE tb.`companyId` in () and tb.`bookingDate` >= '2018-12-15' and tb.`bookingDate` <='2018-12-15'
ERROR - 2018-12-15 15:58:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 15:59:39 --> Severity: Notice --> Undefined variable: comp /var/www/travel_app/application/models/User_model.php 220
ERROR - 2018-12-15 15:59:39 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/travel_app/application/models/Booking_model.php 288
ERROR - 2018-12-15 15:59:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') and tb.`bookingDate` >= '2018-12-15' and tb.`bookingDate` <='2018-12-15'' at line 1 - Invalid query: SELECT (tb.priceCash+tb.creditPaid) as totTicket, tc.companyName as company  FROM `travel_booking` as tb left join travel_company as tc on(tc.companyId = tb.companyId) WHERE tb.`companyId` in () and tb.`bookingDate` >= '2018-12-15' and tb.`bookingDate` <='2018-12-15'
ERROR - 2018-12-15 16:00:08 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-15 16:00:08 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 190
ERROR - 2018-12-15 16:00:08 --> Severity: Notice --> Undefined variable: tot_income /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-15 16:00:08 --> Severity: Notice --> Undefined variable: expense /var/www/travel_app/application/views/user/trial_balance.php 191
ERROR - 2018-12-15 16:47:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 16:49:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 16:49:46 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 16:49:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 16:49:56 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 16:49:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 16:51:27 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 16:51:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 16:51:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 16:51:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 16:51:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 16:51:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 16:52:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 16:52:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 16:52:36 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 16:52:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 16:52:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 16:52:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:04:14 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:04:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:04:22 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:04:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:10:40 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:10:57 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:10:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:10:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:11:19 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:11:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:11:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:11:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:11:38 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:11:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:12:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-15 17:12:07 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:12:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:12:48 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:12:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:12:49 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:12:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:12:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:12:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:14:58 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:14:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:16:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-15 17:16:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-15 17:16:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-15 17:16:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 17:16:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-15 17:16:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-15 17:16:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-15 17:16:34 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-15 17:16:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:18:00 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:18:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:18:08 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:18:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:18:28 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:18:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:18:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:18:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:18:33 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:18:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:19:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:19:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:19:31 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:19:44 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:24:29 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:24:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:24:30 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:24:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:24:39 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:24:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:25:35 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:25:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-12-15 17:25:45 --> 404 Page Not Found: Assets/lib
ERROR - 2018-12-15 17:25:45 --> 404 Page Not Found: Assets/css
