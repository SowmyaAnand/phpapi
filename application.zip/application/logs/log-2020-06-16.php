<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-16 11:08:20 --> Severity: Notice --> Undefined variable: total_questions C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 21
ERROR - 2020-06-16 11:08:20 --> Severity: Notice --> Undefined variable: total_polls C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 50
ERROR - 2020-06-16 11:08:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-16 11:08:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-16 11:08:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-16 11:08:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-16 11:08:50 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-16 11:09:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-16 11:09:47 --> Severity: Notice --> Undefined variable: total_questions C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 21
ERROR - 2020-06-16 11:09:47 --> Severity: Notice --> Undefined variable: total_polls C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 50
ERROR - 2020-06-16 11:09:47 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-16 11:10:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-16 11:10:32 --> 404 Page Not Found: Assets/img
