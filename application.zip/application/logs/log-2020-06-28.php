<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-28 00:26:34 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:26:37 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:26:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:26:52 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:26:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:35:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:35:57 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:36:24 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:36:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:37:55 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:37:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:38:10 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:38:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:47:09 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:47:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:47:28 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-28 00:47:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:47:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 00:50:30 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 98
ERROR - 2020-06-28 00:50:31 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 98
ERROR - 2020-06-28 00:50:31 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 98
ERROR - 2020-06-28 00:50:31 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:04:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:05:42 --> Severity: Warning --> Illegal string offset 'option' C:\xampp\htdocs\assignment\application\controllers\Admin.php 98
ERROR - 2020-06-28 01:06:19 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:06:33 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:28:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:28:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\edit_question.php 43
ERROR - 2020-06-28 01:28:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:29:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:29:37 --> Severity: Notice --> Undefined index: qId C:\xampp\htdocs\assignment\application\models\Admin_model.php 101
ERROR - 2020-06-28 01:29:37 --> Severity: Notice --> Undefined index: qId C:\xampp\htdocs\assignment\application\controllers\Admin.php 148
ERROR - 2020-06-28 01:29:37 --> Query error: Column 'qId' cannot be null - Invalid query: INSERT INTO `options` (`options`, `qId`) VALUES ('xcvxv', NULL)
ERROR - 2020-06-28 01:31:46 --> Severity: Notice --> Undefined index: qId C:\xampp\htdocs\assignment\application\models\Admin_model.php 101
ERROR - 2020-06-28 01:31:46 --> Severity: Notice --> Undefined index: qId C:\xampp\htdocs\assignment\application\controllers\Admin.php 148
ERROR - 2020-06-28 01:31:46 --> Query error: Column 'qId' cannot be null - Invalid query: INSERT INTO `options` (`options`, `qId`) VALUES ('xcvxv', NULL)
ERROR - 2020-06-28 01:32:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:32:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:32:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:32:56 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:33:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:33:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:33:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:33:31 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:33:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:34:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:37:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:37:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:37:50 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:38:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:38:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:38:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:38:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:39:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:46:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:47:02 --> Query error: Table 'ipoll.admin' doesn't exist - Invalid query: SELECT *
FROM `admin`
WHERE `id` = '1'
ERROR - 2020-06-28 01:47:42 --> Query error: Table 'ipoll.admin' doesn't exist - Invalid query: SELECT *
FROM `admin`
WHERE `id` = '1'
ERROR - 2020-06-28 01:47:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:48:14 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:48:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:48:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:48:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:48:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:48:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:50:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 01:50:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 02:00:57 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 02:01:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 02:01:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:06:41 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:06:48 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:07:00 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:07:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:07:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:07:21 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:07:25 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:07:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:08:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:08:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 17:08:32 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 19:12:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-28 19:12:09 --> 404 Page Not Found: Assets/img
