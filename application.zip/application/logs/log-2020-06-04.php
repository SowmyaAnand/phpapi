<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-04 00:44:33 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-04 00:45:15 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-04 00:45:34 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-04 01:25:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\assignment\application\controllers\Welcome.php 48
ERROR - 2020-06-04 01:32:35 --> Query error: Unknown column 'options' in 'field list' - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('1', '18-65')
ERROR - 2020-06-04 01:40:11 --> Query error: Column 'options' cannot be null - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('2', NULL)
ERROR - 2020-06-04 01:44:11 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\assignment\application\models\First_model.php 14
ERROR - 2020-06-04 01:44:11 --> Query error: Column 'options' cannot be null - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('2', NULL)
ERROR - 2020-06-04 01:44:33 --> Severity: Notice --> Undefined index: option C:\xampp\htdocs\assignment\application\models\First_model.php 12
ERROR - 2020-06-04 01:44:33 --> Query error: Column 'options' cannot be null - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('1', NULL)
ERROR - 2020-06-04 01:45:08 --> Query error: Column 'options' cannot be null - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('2', NULL)
ERROR - 2020-06-04 01:51:35 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-04 01:52:29 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-04 01:52:43 --> 404 Page Not Found: Assets/lib
ERROR - 2020-06-04 01:53:42 --> Query error: Column 'options' cannot be null - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('10', NULL)
ERROR - 2020-06-04 01:54:11 --> Query error: Column 'options' cannot be null - Invalid query: INSERT INTO `testpoll` (`qId`, `options`) VALUES ('10', NULL)
