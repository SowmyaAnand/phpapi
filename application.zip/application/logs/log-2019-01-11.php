<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-11 11:14:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 11:16:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 11:21:08 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 11:23:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 11:23:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 11:24:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 11:26:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 11:26:25 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-11 11:26:25 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-11 11:26:52 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-11 11:26:52 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 220
ERROR - 2019-01-11 11:29:52 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 11:30:35 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 11:30:49 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 11:30:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 11:30:54 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 11:41:39 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 11:41:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 11:41:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 11:53:56 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 11:53:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 11:53:56 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 11:53:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 12:03:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 12:10:00 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:10:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 12:10:46 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 12:16:12 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:17:59 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:18:10 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:19:46 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 302
ERROR - 2019-01-11 12:19:51 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 302
ERROR - 2019-01-11 12:19:57 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:21:40 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/travel_app/application/views/user/customer_travel.php 302
ERROR - 2019-01-11 12:21:40 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:21:53 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:23:43 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:24:35 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:24:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 12:26:16 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:29:35 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 12:29:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 12:41:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 13:02:50 --> Severity: 8192 --> mysql_insert_id(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/travel_app/application/models/Daybook_model.php 107
ERROR - 2019-01-11 13:02:50 --> Severity: Warning --> mysql_insert_id(): Access denied for user ''@'localhost' (using password: NO) /var/www/travel_app/application/models/Daybook_model.php 107
ERROR - 2019-01-11 13:02:50 --> Severity: Warning --> mysql_insert_id(): A link to the server could not be established /var/www/travel_app/application/models/Daybook_model.php 107
ERROR - 2019-01-11 13:03:27 --> Severity: Warning --> mysqli_insert_id() expects exactly 1 parameter, 0 given /var/www/travel_app/application/models/Daybook_model.php 107
ERROR - 2019-01-11 13:07:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 13:09:23 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 13:59:12 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /var/www/travel_app/application/views/admin/income.php 71
ERROR - 2019-01-11 13:59:26 --> Query error: Table 'travel_app_db.income_types' doesn't exist - Invalid query: SELECT *
FROM `income_types`
ERROR - 2019-01-11 14:04:36 --> 404 Page Not Found: Daybook/edit_incometype
ERROR - 2019-01-11 14:12:17 --> 404 Page Not Found: Daybook/edit_incometype
ERROR - 2019-01-11 14:28:01 --> 404 Page Not Found: Daybook/edit_incometypes
ERROR - 2019-01-11 14:31:54 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 14:33:28 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/edit_income_types.php 197
ERROR - 2019-01-11 14:33:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/edit_income_types.php 197
ERROR - 2019-01-11 14:33:28 --> Severity: Notice --> Undefined variable: user_id /var/www/travel_app/application/views/admin/edit_income_types.php 317
ERROR - 2019-01-11 14:33:28 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/admin/edit_income_types.php 317
ERROR - 2019-01-11 14:36:38 --> 404 Page Not Found: Daybook/edit_incometype
ERROR - 2019-01-11 14:48:06 --> 404 Page Not Found: Daybook/edit_income_type
ERROR - 2019-01-11 14:59:33 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 14:59:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 15:00:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 15:14:02 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 15:14:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 15:14:02 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 15:14:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 15:20:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 15:23:59 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 15:23:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 15:28:39 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 15:28:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 15:32:37 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 15:32:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 15:33:03 --> Severity: Notice --> Undefined index: inc_type_id /var/www/travel_app/application/controllers/Daybook.php 530
ERROR - 2019-01-11 15:33:03 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `income_type` SET `id` = '1', `type` = 'check', `status` = '0', `depreciation` = '100'
WHERE `inc_type_id` IS NULL
ERROR - 2019-01-11 15:33:45 --> Severity: Notice --> Undefined index: inc_type_id /var/www/travel_app/application/controllers/Daybook.php 530
ERROR - 2019-01-11 15:33:45 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `income_type` SET `id` = '1', `type` = 'check', `status` = '0', `depreciation` = '100'
WHERE `inc_type_id` IS NULL
ERROR - 2019-01-11 15:33:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 15:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Daybook.php 538
ERROR - 2019-01-11 15:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Daybook.php 539
ERROR - 2019-01-11 15:33:50 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Daybook.php 540
ERROR - 2019-01-11 15:34:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Daybook.php 538
ERROR - 2019-01-11 15:34:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Daybook.php 539
ERROR - 2019-01-11 15:34:11 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Daybook.php 540
ERROR - 2019-01-11 15:36:01 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `income_type` SET `id` = '1', `type` = 'check', `status` = '0', `depreciation` = '100', `inc_type_id` = '1'
WHERE `inc_type_id` = '1'
ERROR - 2019-01-11 15:36:39 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `income_type` SET `id` = '1', `type` = 'check', `status` = '0', `depreciation` = '100', `inc_type_id` = '1'
WHERE `inc_type_id` = '1'
ERROR - 2019-01-11 15:38:04 --> Severity: Notice --> Undefined index: inc_type_id /var/www/travel_app/application/controllers/Daybook.php 529
ERROR - 2019-01-11 15:38:04 --> Severity: Notice --> Undefined index: inc_type_id /var/www/travel_app/application/controllers/Daybook.php 531
ERROR - 2019-01-11 15:38:04 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `income_type` SET `id` = NULL, `type` = 'check', `status` = '0', `depreciation` = '100'
WHERE `inc_type_id` IS NULL
ERROR - 2019-01-11 15:38:32 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `income_type` SET `id` = '1', `type` = 'check', `status` = '0', `depreciation` = '100', `inc_type_id` = '1'
WHERE `inc_type_id` = '1'
ERROR - 2019-01-11 15:39:11 --> Severity: Notice --> Undefined index: inc_type_id /var/www/travel_app/application/controllers/Daybook.php 530
ERROR - 2019-01-11 15:39:11 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `income_type` SET `id` = '1', `type` = 'check', `status` = '0', `depreciation` = '100'
WHERE `inc_type_id` IS NULL
ERROR - 2019-01-11 15:39:56 --> Severity: Notice --> Undefined index: inc_type_id /var/www/travel_app/application/controllers/Daybook.php 530
ERROR - 2019-01-11 15:39:56 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `income_type` SET `id` = '1', `type` = 'check', `status` = '0', `depreciation` = '100'
WHERE `inc_type_id` IS NULL
ERROR - 2019-01-11 15:41:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 15:44:47 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 15:44:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 15:44:47 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 15:44:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 16:14:22 --> Severity: Notice --> Undefined variable: inc_typ_id /var/www/travel_app/application/views/admin/edit_expense_types.php 20
ERROR - 2019-01-11 16:14:46 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 16:14:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 16:15:09 --> Severity: Notice --> Undefined index: inc_type_id /var/www/travel_app/application/controllers/Daybook.php 530
ERROR - 2019-01-11 16:15:09 --> Query error: Unknown column 'exp_type_id' in 'field list' - Invalid query: UPDATE `income_type` SET `exp_type_id` = '1', `type` = 'Advertisement', `status` = '1', `depreciation` = '75'
WHERE `inc_type_id` IS NULL
ERROR - 2019-01-11 16:58:13 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 16:58:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2019-01-11 16:58:20 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 17:01:15 --> Query error: Unknown column 'add_exp' in 'field list' - Invalid query: UPDATE `expense_type` SET `type` = 'Marketing', `depreciation` = '', `add_exp` = 'Add'
WHERE `type` = 'Marketing'
ERROR - 2019-01-11 17:01:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 17:01:57 --> Query error: Unknown column 'add_exp' in 'field list' - Invalid query: UPDATE `expense_type` SET `type` = 'Marketing', `depreciation` = '', `add_exp` = 'Add'
WHERE `type` = 'Marketing'
ERROR - 2019-01-11 17:03:07 --> Query error: Unknown column 'add_exp' in 'field list' - Invalid query: UPDATE `expense_type` SET `type` = 'Marketing', `depreciation` = '', `add_exp` = 'Add'
WHERE `type` = 'Marketing'
ERROR - 2019-01-11 17:04:44 --> Severity: Notice --> Undefined variable: add_exp_type /var/www/travel_app/application/controllers/Daybook.php 174
ERROR - 2019-01-11 17:15:08 --> Query error: Duplicate entry '82' for key 'exp_type_id' - Invalid query: UPDATE `expense_type` SET `exp_type_id` = '82', `type` = 'Marketing123', `status` = '1', `depreciation` = '75'
WHERE `exp_type_id` = '83'
AND `type` = 'Marketing123'
ERROR - 2019-01-11 17:27:09 --> Severity: Notice --> Undefined offset: 2 /var/www/travel_app/application/controllers/Report.php 120
ERROR - 2019-01-11 17:27:09 --> Severity: Notice --> Undefined offset: 1 /var/www/travel_app/application/controllers/Report.php 122
ERROR - 2019-01-11 19:02:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:02:48 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 19:02:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 19:02:48 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 19:02:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 19:04:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:18:25 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:18:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:20:39 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:20:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:20:50 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:20:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:21:05 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:21:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:21:19 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:21:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:21:53 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:21:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:22:01 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:22:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:22:03 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:24:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:26:53 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:26:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:27:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:30:05 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:30:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:30:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:30:41 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:30:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:34:50 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:34:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:34:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:35:13 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:35:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:35:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:35:24 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:41:47 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:41:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:41:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:42:12 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:42:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-01-11 19:42:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 19:44:02 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 19:44:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 20:21:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-01-11 20:24:27 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 20:24:36 --> 404 Page Not Found: Assets/lib
ERROR - 2019-01-11 20:29:23 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/travel_app/application/controllers/Banking.php 140
ERROR - 2019-01-11 20:29:46 --> Severity: Notice --> Undefined index: companyId /var/www/travel_app/application/controllers/Banking.php 154
ERROR - 2019-01-11 20:38:40 --> Severity: Notice --> Undefined variable: company_image /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 20:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 51
ERROR - 2019-01-11 20:38:40 --> Severity: Notice --> Undefined variable: company /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 20:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/profile.php 94
ERROR - 2019-01-11 21:27:19 --> 404 Page Not Found: Assets/lib
