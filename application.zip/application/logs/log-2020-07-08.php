<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-08 17:33:08 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:33:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:33:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:33:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:34:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:34:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:34:36 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:34:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:35:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-08 17:49:08 --> 404 Page Not Found: Assets/img
