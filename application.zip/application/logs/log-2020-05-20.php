<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-20 12:17:52 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-05-20 12:17:52 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-20 12:17:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-05-20 12:17:52 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-05-20 12:17:52 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-20 12:17:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-05-20 12:17:52 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-05-20 12:17:52 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-20 12:17:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-05-20 12:17:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-20 12:22:04 --> 404 Page Not Found: Polling/index
ERROR - 2020-05-20 12:22:41 --> 404 Page Not Found: Polling/index
ERROR - 2020-05-20 12:24:20 --> 404 Page Not Found: Assets/lib
ERROR - 2020-05-20 12:35:47 --> 404 Page Not Found: Assets/lib
ERROR - 2020-05-20 13:51:34 --> 404 Page Not Found: Images/randombanner.php
ERROR - 2020-05-20 13:52:35 --> 404 Page Not Found: Images/randombanner.php
ERROR - 2020-05-20 13:52:48 --> 404 Page Not Found: Assets/lib
ERROR - 2020-05-20 14:18:33 --> 404 Page Not Found: Assets/lib
ERROR - 2020-05-20 14:29:08 --> 404 Page Not Found: Assets/lib
