<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-06 12:57:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\ipoll\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-07-06 12:57:24 --> Unable to connect to the database
ERROR - 2020-07-06 13:41:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:20:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:20:14 --> Severity: Notice --> Undefined variable: companies C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 64
ERROR - 2020-07-06 14:20:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 64
ERROR - 2020-07-06 14:20:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 125
ERROR - 2020-07-06 14:20:14 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 105
ERROR - 2020-07-06 14:23:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:23:28 --> 404 Page Not Found: Welcome/total_polling_graph_admin
ERROR - 2020-07-06 14:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 105
ERROR - 2020-07-06 14:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 105
ERROR - 2020-07-06 14:28:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:28:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 105
ERROR - 2020-07-06 14:28:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:28:11 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-06 14:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 105
ERROR - 2020-07-06 14:30:13 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-06 14:30:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:32:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 106
ERROR - 2020-07-06 14:32:04 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-06 14:32:04 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:32:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 106
ERROR - 2020-07-06 14:32:26 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-06 14:32:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-06 14:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ipoll\application\views\admin\total_polling_graph.php 106
ERROR - 2020-07-06 14:33:23 --> 404 Page Not Found: Assets/lib
ERROR - 2020-07-06 14:33:23 --> 404 Page Not Found: Assets/img
