<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-09 00:28:25 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:38:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:38:38 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:38:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:39:49 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:39:53 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:39:58 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:40:03 --> 404 Page Not Found: Admin/edit_question
ERROR - 2020-06-09 00:59:05 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 19
ERROR - 2020-06-09 00:59:05 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-06-09 00:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 31
ERROR - 2020-06-09 00:59:05 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 63
ERROR - 2020-06-09 00:59:05 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-06-09 00:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 74
ERROR - 2020-06-09 00:59:05 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 105
ERROR - 2020-06-09 00:59:05 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-06-09 00:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\assignment\application\views\admin\dashboard.php 116
ERROR - 2020-06-09 00:59:05 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:59:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 00:59:24 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:02:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:02:17 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:10:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 328
ERROR - 2020-06-09 01:10:45 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:11:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\assignment\application\controllers\Welcome.php 312
ERROR - 2020-06-09 01:11:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:12:28 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-09 01:12:28 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-09 01:12:28 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-09 01:12:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:19:44 --> Query error: Table 'ipoll.polls' doesn't exist - Invalid query: SELECT *
FROM `polls`
ERROR - 2020-06-09 01:20:36 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-09 01:20:36 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-09 01:20:36 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-09 01:20:36 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-09 01:20:36 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-09 01:20:36 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:21:22 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-09 01:21:22 --> Severity: Notice --> Undefined variable: total_booking C:\xampp\htdocs\assignment\application\views\user\dashboard.php 16
ERROR - 2020-06-09 01:21:22 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-09 01:21:22 --> Severity: Notice --> Undefined variable: total_credit C:\xampp\htdocs\assignment\application\views\user\dashboard.php 31
ERROR - 2020-06-09 01:21:22 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\assignment\application\views\user\dashboard.php 46
ERROR - 2020-06-09 01:21:22 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:21:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-09 01:22:24 --> 404 Page Not Found: Assets/img
