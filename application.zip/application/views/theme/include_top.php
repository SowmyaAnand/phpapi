  <link href="<?php echo base_url();?>assets/img/favicon.png" rel="icon">
  <link href="<?php echo base_url();?>assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url();?>assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo base_url();?>assets/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/css/style-responsive.css" rel="stylesheet">
  
 <!--  <link href="<?php echo base_url();?>assets/lib/advanced-datatable/css/demo_page.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>assets/lib/advanced-datatable/css/demo_table.css" rel="stylesheet" />
  <link rel="stylesheet" href="<?php echo base_url();?>assets/lib/advanced-datatable/css/DT_bootstrap.css" />
 --> 
 <link href="<?php echo base_url();?>assets/css/dataTables.bootstrap.min.css">
 <link href="<?php echo base_url();?>assets/css/fixedHeader.bootstrap.min.css">
 <link href="<?php echo base_url();?>assets/css/responsive.bootstrap.min.css">

 <link href="<?php echo base_url();?>assets/css/custom_style.css" rel="stylesheet">
 
  <script src="<?php echo base_url();?>assets/lib/jquery/jquery.min.js"></script>