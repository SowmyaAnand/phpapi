<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-15 19:47:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-15 19:47:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-15 19:47:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-15 19:47:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-15 19:50:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-15 20:36:09 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-15 20:36:12 --> 404 Page Not Found: Assets/img
