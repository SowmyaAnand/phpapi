<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-19 10:10:55 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/travel_app/application/controllers/Report.php 182
ERROR - 2018-12-19 10:11:40 --> Severity: Notice --> Undefined variable: amount /var/www/travel_app/application/controllers/Report.php 176
ERROR - 2018-12-19 10:13:42 --> Severity: Notice --> Undefined variable: amount /var/www/travel_app/application/controllers/Report.php 176
ERROR - 2018-12-19 10:17:03 --> Severity: Notice --> Undefined variable: amount /var/www/travel_app/application/controllers/Report.php 176
ERROR - 2018-12-19 10:18:32 --> Severity: Notice --> Undefined variable: amount /var/www/travel_app/application/controllers/Report.php 176
ERROR - 2018-12-19 10:20:47 --> Severity: Notice --> Undefined variable: amount /var/www/travel_app/application/controllers/Report.php 173
ERROR - 2018-12-19 10:27:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-19 10:28:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-19 10:32:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-19 10:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-19 10:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 125
ERROR - 2018-12-19 10:36:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 125
ERROR - 2018-12-19 10:49:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 10:58:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 10:59:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Undefined index: usercompany /var/www/travel_app/application/controllers/Booking.php 92
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-19 11:00:04 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-19 11:18:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-19 11:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-19 11:24:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-19 11:24:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-19 11:24:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-19 11:24:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-19 11:24:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-19 11:24:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-19 11:24:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-19 11:24:51 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-19 11:26:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 56
ERROR - 2018-12-19 11:26:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 57
ERROR - 2018-12-19 11:26:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 58
ERROR - 2018-12-19 11:26:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-19 11:26:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 181
ERROR - 2018-12-19 11:26:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 256
ERROR - 2018-12-19 11:26:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 257
ERROR - 2018-12-19 11:26:07 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/views/user/ticket_details.php 258
ERROR - 2018-12-19 11:26:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-19 11:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-19 11:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 125
ERROR - 2018-12-19 11:31:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-19 11:32:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-19 11:32:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_cash_graph.php 125
ERROR - 2018-12-19 11:33:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_credit_graph.php 125
ERROR - 2018-12-19 11:33:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 12:02:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-19 12:48:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 12:57:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 13:12:58 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-19 13:12:58 --> Severity: Error --> Call to a member function create_links() on null /var/www/travel_app/application/views/admin/transaction_report.php 193
ERROR - 2018-12-19 13:13:35 --> Severity: Notice --> Array to string conversion /var/www/travel_app/application/views/admin/edit_income.php 122
ERROR - 2018-12-19 13:17:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/total_booking_graph.php 166
ERROR - 2018-12-19 13:25:52 --> Severity: Notice --> Trying to get property of non-object /var/www/travel_app/application/controllers/Welcome.php 364
ERROR - 2018-12-19 13:39:05 --> 404 Page Not Found: Banking/account_details
ERROR - 2018-12-19 13:41:50 --> Severity: Parsing Error --> syntax error, unexpected 'account_details' (T_STRING), expecting variable (T_VARIABLE) /var/www/travel_app/application/controllers/Banking.php 163
ERROR - 2018-12-19 14:34:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 14:38:10 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 170
ERROR - 2018-12-19 14:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 170
ERROR - 2018-12-19 14:39:13 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 170
ERROR - 2018-12-19 14:39:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 170
ERROR - 2018-12-19 14:39:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 14:42:46 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:43:09 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:45:23 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:45:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:46:42 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:46:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 14:46:59 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:47:51 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:47:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:48:55 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:48:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:49:27 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:49:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:50:27 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 180
ERROR - 2018-12-19 14:52:17 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 188
ERROR - 2018-12-19 14:52:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 188
ERROR - 2018-12-19 14:52:54 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 189
ERROR - 2018-12-19 14:52:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 189
ERROR - 2018-12-19 14:52:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 14:54:13 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 197
ERROR - 2018-12-19 14:54:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 197
ERROR - 2018-12-19 14:54:32 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 197
ERROR - 2018-12-19 14:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 197
ERROR - 2018-12-19 14:54:58 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 197
ERROR - 2018-12-19 14:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 197
ERROR - 2018-12-19 14:59:51 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 201
ERROR - 2018-12-19 14:59:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 201
ERROR - 2018-12-19 15:01:05 --> Severity: Notice --> Undefined variable: companies /var/www/travel_app/application/views/admin/account_details.php 201
ERROR - 2018-12-19 15:01:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/travel_app/application/views/admin/account_details.php 201
ERROR - 2018-12-19 15:48:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 15:49:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 15:51:04 --> Severity: Notice --> Undefined property: Banking::$banking_model /var/www/travel_app/application/controllers/Banking.php 190
ERROR - 2018-12-19 15:51:04 --> Severity: Error --> Call to a member function add_account_details() on null /var/www/travel_app/application/controllers/Banking.php 190
ERROR - 2018-12-19 15:54:24 --> Severity: Error --> Call to undefined method Admin_model::add_account_details() /var/www/travel_app/application/controllers/Banking.php 190
ERROR - 2018-12-19 15:57:00 --> Severity: Error --> Call to undefined method Admin_model::add_account_details() /var/www/travel_app/application/controllers/Banking.php 191
ERROR - 2018-12-19 15:57:28 --> Query error: Unknown column 'bank' in 'field list' - Invalid query: INSERT INTO `bank_details` (`bank`, `branch`, `bank_address`, `acc_no`, `fname`, `dob`, `mobile`, `address`, `state`, `usercompany`, `companyId`, `accountNmber`, `bankName`) VALUES ('SBT', '', '', '0123456789', '', '2018-12-19', '', '', '', '130', '130', '0123456789', 'SBT')
ERROR - 2018-12-19 17:02:47 --> Query error: Unknown column 'bank' in 'field list' - Invalid query: INSERT INTO `bank_details` (`bank`, `branch`, `bankAddress`, `accountNmber`, `usercompany`, `companyId`) VALUES ('SBT', 'palakkad', 'SBT Palakkad', '0123456789', '130', '130')
ERROR - 2018-12-19 17:03:26 --> Query error: Unknown column 'bank' in 'field list' - Invalid query: INSERT INTO `bank_details` (`bank`, `branch`, `bankAddress`, `accountNmber`, `usercompany`, `companyId`) VALUES ('SBT', 'palakkad', 'SBT Palakkad', '0123456789', '130', '130')
ERROR - 2018-12-19 17:03:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 17:04:30 --> Query error: Unknown column 'bankAddress' in 'field list' - Invalid query: INSERT INTO `bank_details` (`bankName`, `branch`, `bankAddress`, `accountNmber`, `usercompany`, `companyId`) VALUES ('SBT', 'palakkad', 'SBT Palakkad', '0123456789', '130', '130')
ERROR - 2018-12-19 17:05:06 --> Query error: Unknown column 'usercompany' in 'field list' - Invalid query: INSERT INTO `bank_details` (`bankName`, `branch`, `bankAddress`, `accountNmber`, `usercompany`, `companyId`) VALUES ('SBT', 'palakkad', 'SBT Palakkad', '0123456789', '130', '130')
ERROR - 2018-12-19 17:05:17 --> Query error: Unknown column 'usercompany' in 'field list' - Invalid query: INSERT INTO `bank_details` (`bankName`, `branch`, `bankAddress`, `accountNmber`, `usercompany`, `companyId`) VALUES ('SBT', 'palakkad', 'SBT Palakkad', '0123456789', '130', '130')
ERROR - 2018-12-19 17:38:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 17:42:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_zip.dll' - /usr/lib/php/20131226/php_zip.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Notice --> Uninitialized string offset: 0 /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:27 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 171
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Illegal string offset 'creditPaid' /var/www/travel_app/application/controllers/Report.php 160
ERROR - 2018-12-19 22:27:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/system/core/Exceptions.php:271) /var/www/travel_app/system/helpers/url_helper.php 564
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/controllers/Report.php 152
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/controllers/Report.php 153
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: bookingId /var/www/travel_app/application/controllers/Report.php 175
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/controllers/Report.php 152
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/controllers/Report.php 153
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: bookingId /var/www/travel_app/application/controllers/Report.php 175
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/controllers/Report.php 152
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/controllers/Report.php 153
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: bookingId /var/www/travel_app/application/controllers/Report.php 175
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: priceCredit /var/www/travel_app/application/controllers/Report.php 152
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: creditPaid /var/www/travel_app/application/controllers/Report.php 153
ERROR - 2018-12-19 22:28:55 --> Severity: Notice --> Undefined index: bookingId /var/www/travel_app/application/controllers/Report.php 164
ERROR - 2018-12-19 22:28:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/travel_app/system/core/Exceptions.php:271) /var/www/travel_app/system/helpers/url_helper.php 564
