<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-12 22:34:23 --> 404 Page Not Found: Api/activateItem
