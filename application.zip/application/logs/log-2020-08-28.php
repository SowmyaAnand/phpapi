<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-28 13:29:45 --> Severity: Notice --> Undefined variable: array_of_event /home/dailyest/public_html/dailyestore/application/controllers/Api.php 566
ERROR - 2020-08-28 19:15:22 --> 404 Page Not Found: Api/ite
